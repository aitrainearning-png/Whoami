export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      admin_announcements: {
        Row: {
          created_at: string
          created_by: string
          id: string
          is_active: boolean
          message: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          is_active?: boolean
          message: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          is_active?: boolean
          message?: string
        }
        Relationships: []
      }
      announcement_dismissals: {
        Row: {
          announcement_id: string
          dismissed_at: string
          id: string
          user_id: string
        }
        Insert: {
          announcement_id: string
          dismissed_at?: string
          id?: string
          user_id: string
        }
        Update: {
          announcement_id?: string
          dismissed_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcement_dismissals_announcement_id_fkey"
            columns: ["announcement_id"]
            isOneToOne: false
            referencedRelation: "admin_announcements"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          id: string
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          id?: string
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          id?: string
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string
          id: string
          image_url: string | null
          message: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name: string
          id?: string
          image_url?: string | null
          message: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string
          id?: string
          image_url?: string | null
          message?: string
          user_id?: string
        }
        Relationships: []
      }
      client_tasks: {
        Row: {
          approved_count: number
          category_id: string | null
          client_id: string
          created_at: string
          deadline: string
          id: string
          instructions: string
          max_workers: number
          proof_type: Database["public"]["Enums"]["proof_type"]
          rejected_count: number
          remaining_budget: number
          reward_per_user: number
          status: Database["public"]["Enums"]["task_status"]
          title: string
          total_budget: number
          updated_at: string
        }
        Insert: {
          approved_count?: number
          category_id?: string | null
          client_id: string
          created_at?: string
          deadline: string
          id?: string
          instructions: string
          max_workers: number
          proof_type?: Database["public"]["Enums"]["proof_type"]
          rejected_count?: number
          remaining_budget: number
          reward_per_user: number
          status?: Database["public"]["Enums"]["task_status"]
          title: string
          total_budget: number
          updated_at?: string
        }
        Update: {
          approved_count?: number
          category_id?: string | null
          client_id?: string
          created_at?: string
          deadline?: string
          id?: string
          instructions?: string
          max_workers?: number
          proof_type?: Database["public"]["Enums"]["proof_type"]
          rejected_count?: number
          remaining_budget?: number
          reward_per_user?: number
          status?: Database["public"]["Enums"]["task_status"]
          title?: string
          total_budget?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_tasks_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "task_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_tasks_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_transactions: {
        Row: {
          amount: number
          client_id: string
          created_at: string
          description: string | null
          id: string
          payment_proof_url: string | null
          processed_at: string | null
          processed_by: string | null
          reference_id: string | null
          status: Database["public"]["Enums"]["status_type"]
          type: Database["public"]["Enums"]["client_transaction_type"]
        }
        Insert: {
          amount: number
          client_id: string
          created_at?: string
          description?: string | null
          id?: string
          payment_proof_url?: string | null
          processed_at?: string | null
          processed_by?: string | null
          reference_id?: string | null
          status?: Database["public"]["Enums"]["status_type"]
          type: Database["public"]["Enums"]["client_transaction_type"]
        }
        Update: {
          amount?: number
          client_id?: string
          created_at?: string
          description?: string | null
          id?: string
          payment_proof_url?: string | null
          processed_at?: string | null
          processed_by?: string | null
          reference_id?: string | null
          status?: Database["public"]["Enums"]["status_type"]
          type?: Database["public"]["Enums"]["client_transaction_type"]
        }
        Relationships: [
          {
            foreignKeyName: "client_transactions_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_wallets: {
        Row: {
          balance: number
          client_id: string
          created_at: string
          id: string
          total_deposited: number
          total_spent: number
          updated_at: string
        }
        Insert: {
          balance?: number
          client_id: string
          created_at?: string
          id?: string
          total_deposited?: number
          total_spent?: number
          updated_at?: string
        }
        Update: {
          balance?: number
          client_id?: string
          created_at?: string
          id?: string
          total_deposited?: number
          total_spent?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_wallets_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: true
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          company_name: string | null
          created_at: string
          display_name: string | null
          email: string
          id: string
          status: Database["public"]["Enums"]["client_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          company_name?: string | null
          created_at?: string
          display_name?: string | null
          email: string
          id?: string
          status?: Database["public"]["Enums"]["client_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          company_name?: string | null
          created_at?: string
          display_name?: string | null
          email?: string
          id?: string
          status?: Database["public"]["Enums"]["client_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_challenges: {
        Row: {
          challenge_date: string
          completed_at: string | null
          created_at: string
          current_count: number
          game_id: string | null
          id: string
          is_completed: boolean
          reward: number
          target_count: number
          user_id: string
        }
        Insert: {
          challenge_date?: string
          completed_at?: string | null
          created_at?: string
          current_count?: number
          game_id?: string | null
          id?: string
          is_completed?: boolean
          reward?: number
          target_count?: number
          user_id: string
        }
        Update: {
          challenge_date?: string
          completed_at?: string | null
          created_at?: string
          current_count?: number
          game_id?: string | null
          id?: string
          is_completed?: boolean
          reward?: number
          target_count?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "daily_challenges_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      direct_messages: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          receiver_id: string
          sender_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          receiver_id: string
          sender_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      game_sessions: {
        Row: {
          completed_at: string | null
          energy_spent: number
          game_id: string
          id: string
          is_successful: boolean | null
          reward_earned: number | null
          score: number | null
          started_at: string
          time_taken_seconds: number | null
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          energy_spent: number
          game_id: string
          id?: string
          is_successful?: boolean | null
          reward_earned?: number | null
          score?: number | null
          started_at?: string
          time_taken_seconds?: number | null
          user_id: string
        }
        Update: {
          completed_at?: string | null
          energy_spent?: number
          game_id?: string
          id?: string
          is_successful?: boolean | null
          reward_earned?: number | null
          score?: number | null
          started_at?: string
          time_taken_seconds?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "game_sessions_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      games: {
        Row: {
          base_time_seconds: number
          created_at: string
          description: string | null
          difficulty_multiplier: number
          energy_cost: number
          id: string
          is_active: boolean
          max_reward: number
          min_reward: number
          name: string
        }
        Insert: {
          base_time_seconds?: number
          created_at?: string
          description?: string | null
          difficulty_multiplier?: number
          energy_cost?: number
          id: string
          is_active?: boolean
          max_reward?: number
          min_reward?: number
          name: string
        }
        Update: {
          base_time_seconds?: number
          created_at?: string
          description?: string | null
          difficulty_multiplier?: number
          energy_cost?: number
          id?: string
          is_active?: boolean
          max_reward?: number
          min_reward?: number
          name?: string
        }
        Relationships: []
      }
      premium_orders: {
        Row: {
          amount: number
          created_at: string
          id: string
          payment_proof_url: string | null
          payment_reference: string | null
          processed_at: string | null
          processed_by: string | null
          rejection_reason: string | null
          status: Database["public"]["Enums"]["status_type"]
          tier: Database["public"]["Enums"]["premium_tier"]
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          payment_proof_url?: string | null
          payment_reference?: string | null
          processed_at?: string | null
          processed_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["status_type"]
          tier: Database["public"]["Enums"]["premium_tier"]
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          payment_proof_url?: string | null
          payment_reference?: string | null
          processed_at?: string | null
          processed_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["status_type"]
          tier?: Database["public"]["Enums"]["premium_tier"]
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          balance: number
          created_at: string
          display_name: string | null
          email: string | null
          energy: number
          energy_updated_at: string
          first_withdrawal_done: boolean
          games_played: number
          id: string
          last_active_at: string | null
          last_withdrawal_at: string | null
          max_energy: number
          playtime_reset_at: string
          playtime_seconds: number
          premium_expires_at: string | null
          premium_tier: Database["public"]["Enums"]["premium_tier"] | null
          referral_code: string
          referral_count: number
          referral_earnings: number
          referred_by: string | null
          total_earned: number
          updated_at: string
          user_id: string
          withdrawals_unlocked: boolean
        }
        Insert: {
          avatar_url?: string | null
          balance?: number
          created_at?: string
          display_name?: string | null
          email?: string | null
          energy?: number
          energy_updated_at?: string
          first_withdrawal_done?: boolean
          games_played?: number
          id?: string
          last_active_at?: string | null
          last_withdrawal_at?: string | null
          max_energy?: number
          playtime_reset_at?: string
          playtime_seconds?: number
          premium_expires_at?: string | null
          premium_tier?: Database["public"]["Enums"]["premium_tier"] | null
          referral_code: string
          referral_count?: number
          referral_earnings?: number
          referred_by?: string | null
          total_earned?: number
          updated_at?: string
          user_id: string
          withdrawals_unlocked?: boolean
        }
        Update: {
          avatar_url?: string | null
          balance?: number
          created_at?: string
          display_name?: string | null
          email?: string | null
          energy?: number
          energy_updated_at?: string
          first_withdrawal_done?: boolean
          games_played?: number
          id?: string
          last_active_at?: string | null
          last_withdrawal_at?: string | null
          max_energy?: number
          playtime_reset_at?: string
          playtime_seconds?: number
          premium_expires_at?: string | null
          premium_tier?: Database["public"]["Enums"]["premium_tier"] | null
          referral_code?: string
          referral_count?: number
          referral_earnings?: number
          referred_by?: string | null
          total_earned?: number
          updated_at?: string
          user_id?: string
          withdrawals_unlocked?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "profiles_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      task_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
        }
        Relationships: []
      }
      task_submissions: {
        Row: {
          created_at: string
          id: string
          proof_content: string
          proof_image_url: string | null
          rejection_reason: string | null
          reviewed_at: string | null
          reward_amount: number | null
          status: Database["public"]["Enums"]["submission_status"]
          task_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          proof_content: string
          proof_image_url?: string | null
          rejection_reason?: string | null
          reviewed_at?: string | null
          reward_amount?: number | null
          status?: Database["public"]["Enums"]["submission_status"]
          task_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          proof_content?: string
          proof_image_url?: string | null
          rejection_reason?: string | null
          reviewed_at?: string | null
          reward_amount?: number | null
          status?: Database["public"]["Enums"]["submission_status"]
          task_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_submissions_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "client_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      tier_settings: {
        Row: {
          created_at: string
          duration_days: number
          earning_rate: number
          id: string
          tier: Database["public"]["Enums"]["premium_tier"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          duration_days?: number
          earning_rate?: number
          id?: string
          tier: Database["public"]["Enums"]["premium_tier"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          duration_days?: number
          earning_rate?: number
          id?: string
          tier?: Database["public"]["Enums"]["premium_tier"]
          updated_at?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          game_id: string | null
          id: string
          payment_details: string | null
          payment_method: string | null
          payment_proof_url: string | null
          processed_at: string | null
          processed_by: string | null
          reference_id: string | null
          status: Database["public"]["Enums"]["status_type"]
          type: Database["public"]["Enums"]["transaction_type"]
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description?: string | null
          game_id?: string | null
          id?: string
          payment_details?: string | null
          payment_method?: string | null
          payment_proof_url?: string | null
          processed_at?: string | null
          processed_by?: string | null
          reference_id?: string | null
          status?: Database["public"]["Enums"]["status_type"]
          type: Database["public"]["Enums"]["transaction_type"]
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          game_id?: string | null
          id?: string
          payment_details?: string | null
          payment_method?: string | null
          payment_proof_url?: string | null
          processed_at?: string | null
          processed_by?: string | null
          reference_id?: string | null
          status?: Database["public"]["Enums"]["status_type"]
          type?: Database["public"]["Enums"]["transaction_type"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      user_bans: {
        Row: {
          ban_type: string
          banned_by: string
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          reason: string
          user_id: string
        }
        Insert: {
          ban_type: string
          banned_by: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason: string
          user_id: string
        }
        Update: {
          ban_type?: string
          banned_by?: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_energy: {
        Args: {
          current_energy: number
          energy_updated_at: string
          max_energy: number
          premium_tier?: Database["public"]["Enums"]["premium_tier"]
        }
        Returns: number
      }
      can_premium_user_withdraw: {
        Args: { user_profile_id: string }
        Returns: boolean
      }
      count_referrals_with_premium: {
        Args: { user_profile_id: string }
        Returns: number
      }
      generate_referral_code: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_client: { Args: { _user_id: string }; Returns: boolean }
      is_user_banned: {
        Args: { check_user_id: string }
        Returns: {
          ban_type: string
          expires_at: string
          is_banned: boolean
          reason: string
        }[]
      }
      validate_referral_code: { Args: { code: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      client_status: "pending" | "approved" | "suspended"
      client_transaction_type: "deposit" | "task_spend" | "refund"
      premium_tier: "basic" | "advance" | "pro" | "free"
      proof_type: "image" | "text" | "link"
      status_type: "pending" | "approved" | "rejected" | "completed"
      submission_status: "pending" | "approved" | "rejected"
      task_status: "draft" | "active" | "paused" | "completed"
      transaction_type:
        | "earning"
        | "withdrawal"
        | "referral_commission"
        | "bonus"
        | "deposit"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      client_status: ["pending", "approved", "suspended"],
      client_transaction_type: ["deposit", "task_spend", "refund"],
      premium_tier: ["basic", "advance", "pro", "free"],
      proof_type: ["image", "text", "link"],
      status_type: ["pending", "approved", "rejected", "completed"],
      submission_status: ["pending", "approved", "rejected"],
      task_status: ["draft", "active", "paused", "completed"],
      transaction_type: [
        "earning",
        "withdrawal",
        "referral_commission",
        "bonus",
        "deposit",
      ],
    },
  },
} as const
