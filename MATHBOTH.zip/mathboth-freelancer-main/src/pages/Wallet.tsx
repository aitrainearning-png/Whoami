import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Coins, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Loader2,
  Users,
  AlertTriangle
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";

type TransactionStatus = "pending" | "approved" | "rejected" | "completed";
type TransactionType = "earning" | "withdrawal" | "referral_commission" | "bonus" | "deposit";

const getStatusIcon = (status: TransactionStatus) => {
  switch (status) {
    case "pending":
      return <Clock className="w-4 h-4 text-gold" />;
    case "approved":
    case "completed":
      return <CheckCircle2 className="w-4 h-4 text-success" />;
    case "rejected":
      return <XCircle className="w-4 h-4 text-destructive" />;
  }
};

const getStatusLabel = (status: TransactionStatus) => {
  switch (status) {
    case "pending":
      return "Pending";
    case "approved":
    case "completed":
      return "Approved";
    case "rejected":
      return "Rejected";
  }
};

const formatDate = (dateStr: string) => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return `Today, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`;
  if (diffDays === 1) return 'Yesterday';
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

export default function Wallet() {
  const { user } = useAuth();
  const { data: profile, isLoading: profileLoading } = useProfile();
  const queryClient = useQueryClient();
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [showUnlockMessage, setShowUnlockMessage] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [depositAmount, setDepositAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [paymentDetails, setPaymentDetails] = useState("");
  const [depositReference, setDepositReference] = useState("");

  // Check withdrawal eligibility for premium users
  const { data: canWithdraw } = useQuery({
    queryKey: ["can-withdraw", profile?.id],
    queryFn: async () => {
      if (!profile?.id) return true;
      // Non-premium users can always withdraw (standard rules apply)
      if (!profile.premium_tier) return true;
      // Already unlocked
      if (profile.withdrawals_unlocked) return true;
      
      // Check if user has 1+ referrals with paid plans
      const { data, error } = await supabase.rpc("count_referrals_with_premium", {
        user_profile_id: profile.id
      });
      
      if (error) {
        console.error("Error checking withdrawal eligibility:", error);
        return false;
      }
      
      return (data || 0) >= 1;
    },
    enabled: !!profile?.id,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ["transactions", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Subscribe to real-time updates for transactions (wallet history)
  useEffect(() => {
    if (!user) return;

    const transactionsChannel = supabase
      .channel(`transactions-realtime-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "transactions",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ["transactions", user.id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(transactionsChannel);
    };
  }, [user, queryClient]);

  const withdrawMutation = useMutation({
    mutationFn: async ({ amount, method, details }: { amount: number; method: string; details: string }) => {
      if (!user) throw new Error("Not authenticated");
      
      const { error } = await supabase.from("transactions").insert({
        user_id: user.id,
        type: "withdrawal" as TransactionType,
        amount: amount,
        status: "pending" as TransactionStatus,
        description: "Withdrawal request",
        payment_method: method,
        payment_details: details,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions", user?.id] });
      setIsWithdrawOpen(false);
      setWithdrawAmount("");
      setPaymentMethod("");
      setPaymentDetails("");
      toast.success("Withdrawal request submitted!");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to submit withdrawal");
    },
  });

  const depositMutation = useMutation({
    mutationFn: async ({ amount, reference }: { amount: number; reference: string }) => {
      if (!user) throw new Error("Not authenticated");
      
      const { error } = await supabase.from("transactions").insert({
        user_id: user.id,
        type: "deposit" as TransactionType,
        amount: amount,
        status: "pending" as TransactionStatus,
        description: "Cash-in request",
        payment_method: "GCash",
        payment_details: reference,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions", user?.id] });
      setIsDepositOpen(false);
      setDepositAmount("");
      setDepositReference("");
      toast.success("Cash-in request submitted! Waiting for admin approval.");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to submit cash-in request");
    },
  });

  // State for free user message
  const [showFreeUserMessage, setShowFreeUserMessage] = useState(false);

  // Handle withdrawal button click - check eligibility first
  const handleWithdrawClick = () => {
    const isPremium = !!profile?.premium_tier;
    const balance = profile?.balance || 0;
    const minWithdrawAmount = 150;
    
    // Free users cannot withdraw - must purchase premium first
    if (!isPremium && balance >= minWithdrawAmount) {
      setShowFreeUserMessage(true);
      return;
    }
    
    // For premium users attempting first withdrawal at ₱200+
    const minPremiumWithdraw = 200;
    if (isPremium && balance >= minPremiumWithdraw && !canWithdraw && !profile?.withdrawals_unlocked) {
      // Show the one-time unlock message
      setShowUnlockMessage(true);
      return;
    }
    
    setIsWithdrawOpen(true);
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    // Minimum withdrawal is ₱150 for ALL users
    const minAmount = 150;
    
    // Premium users must have at least ₱200 for first withdrawal (unlock rule)
    const isPremium = !!profile?.premium_tier;
    const effectiveMinAmount = isPremium && !profile?.first_withdrawal_done ? 200 : minAmount;
    
    if (isNaN(amount) || amount < effectiveMinAmount) {
      toast.error(`Minimum withdrawal is ₱${effectiveMinAmount}`);
      return;
    }
    
    if (amount > (profile?.balance || 0)) {
      toast.error("Insufficient balance");
      return;
    }

    if (!paymentMethod || !paymentDetails) {
      toast.error("Please fill in all payment details");
      return;
    }

    // Final server-side check for premium withdrawal eligibility
    if (isPremium && !canWithdraw) {
      toast.error("You must unlock withdrawals first by inviting 1 user who purchases a plan.");
      return;
    }

    withdrawMutation.mutate({ amount, method: paymentMethod, details: paymentDetails });
  };

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    
    if (isNaN(amount) || amount < 50) {
      toast.error("Minimum cash-in is ₱50");
      return;
    }

    if (!depositReference.trim()) {
      toast.error("Please enter your GCash reference number");
      return;
    }

    depositMutation.mutate({ amount, reference: depositReference });
  };

  const pendingWithdrawals = transactions
    ?.filter(tx => tx.type === 'withdrawal' && tx.status === 'pending')
    .reduce((sum, tx) => sum + Number(tx.amount), 0) || 0;

  const pendingDeposits = transactions
    ?.filter(tx => tx.type === 'deposit' && tx.status === 'pending')
    .reduce((sum, tx) => sum + Number(tx.amount), 0) || 0;

  // Minimum withdrawal is ₱150 for ALL users
  const minWithdrawal = 150;

  if (profileLoading) {
    return (
      <div className="min-h-screen">
        <header className="bg-gradient-header pt-safe px-4 pb-8 rounded-b-3xl">
          <Skeleton className="h-8 w-24 bg-white/20 mt-6" />
          <div className="mt-6 bg-card/95 rounded-2xl p-5">
            <Skeleton className="h-4 w-32 mb-2" />
            <Skeleton className="h-10 w-40" />
          </div>
        </header>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-8 rounded-b-3xl">
        <div className="pt-6">
          <h1 className="text-2xl font-bold text-primary-foreground">Wallet</h1>
          <p className="text-primary-foreground/80 text-sm mt-1">
            Manage your earnings
          </p>
        </div>

        {/* Balance Card */}
        <div className="mt-6 bg-card/95 backdrop-blur-sm rounded-2xl p-5 shadow-soft">
          <div className="flex items-center gap-2 mb-2">
            <Coins className="w-5 h-5 text-gold" />
            <span className="text-sm font-medium text-muted-foreground">Available Balance</span>
          </div>
          <p className="text-4xl font-bold text-foreground">₱{(profile?.balance || 0).toFixed(2)}</p>
          
          {pendingWithdrawals > 0 && (
            <p className="text-sm text-muted-foreground mt-2">
              ₱{pendingWithdrawals.toFixed(2)} pending withdrawal
            </p>
          )}
          {pendingDeposits > 0 && (
            <p className="text-sm text-success mt-1">
              ₱{pendingDeposits.toFixed(2)} pending cash-in
            </p>
          )}

          <div className="grid grid-cols-2 gap-3 mt-4">
            <Button 
              onClick={() => setIsDepositOpen(true)}
              variant="outline"
              className="h-12 border-success text-success hover:bg-success/10"
            >
              <ArrowDownLeft className="w-5 h-5 mr-2" />
              Cash In
            </Button>
            <Button 
              onClick={handleWithdrawClick}
              className="h-12 bg-gradient-primary hover:opacity-90"
            >
              <ArrowUpRight className="w-5 h-5 mr-2" />
              Withdraw
            </Button>
          </div>

          {/* Unlock Message Alert Dialog */}
          <AlertDialog open={showUnlockMessage} onOpenChange={setShowUnlockMessage}>
            <AlertDialogContent className="max-w-md">
              <AlertDialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gold/10">
                    <Users className="w-6 h-6 text-gold" />
                  </div>
                  <AlertDialogTitle className="text-lg">Unlock Withdrawals</AlertDialogTitle>
                </div>
                <AlertDialogDescription className="text-base leading-relaxed">
                  You must invite at least <span className="font-semibold text-foreground">1 user</span> who <span className="font-semibold text-foreground">purchases any plan</span> to unlock unlimited withdrawals.
                  <br /><br />
                  <span className="text-muted-foreground text-sm">This is a one-time requirement.</span>
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogAction className="bg-gradient-primary">
                I Understand
              </AlertDialogAction>
            </AlertDialogContent>
          </AlertDialog>

          {/* Free User Withdrawal Block Message */}
          <AlertDialog open={showFreeUserMessage} onOpenChange={setShowFreeUserMessage}>
            <AlertDialogContent className="max-w-md">
              <AlertDialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10">
                    <Coins className="w-6 h-6 text-primary" />
                  </div>
                  <AlertDialogTitle className="text-lg">Premium Required</AlertDialogTitle>
                </div>
                <AlertDialogDescription className="text-base leading-relaxed">
                  Please purchase at least the <span className="font-semibold text-foreground">Basic Premium plan</span> to enable withdrawal.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogAction className="bg-gradient-primary">
                I Understand
              </AlertDialogAction>
            </AlertDialogContent>
          </AlertDialog>

          <Dialog open={isWithdrawOpen} onOpenChange={setIsWithdrawOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Request Withdrawal</DialogTitle>
                <DialogDescription>
                  Minimum withdrawal: ₱{minWithdrawal}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (₱)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder={`Min ₱${minWithdrawal}`}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Withdrawal Method</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "GCash", label: "GCash" },
                      { value: "Maya", label: "Maya" },
                      { value: "Bank Transfer", label: "Bank" },
                    ].map((method) => (
                      <button
                        key={method.value}
                        type="button"
                        onClick={() => setPaymentMethod(method.value)}
                        className={cn(
                          "h-10 rounded-lg border text-sm font-medium transition-colors",
                          paymentMethod === method.value
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-input bg-background text-muted-foreground hover:bg-accent"
                        )}
                      >
                        {method.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="details">Account Number/Details</Label>
                  <Input
                    id="details"
                    placeholder="Your account number"
                    value={paymentDetails}
                    onChange={(e) => setPaymentDetails(e.target.value)}
                  />
                </div>
                <Button 
                  onClick={handleWithdraw}
                  disabled={withdrawMutation.isPending}
                  className="w-full h-12 bg-gradient-primary"
                >
                  {withdrawMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    "Submit Request"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Cash-in Dialog */}
          <Dialog open={isDepositOpen} onOpenChange={setIsDepositOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Cash In</DialogTitle>
                <DialogDescription>
                  Send payment via GCash and enter the reference number
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="deposit-amount">Amount (₱)</Label>
                  <Input
                    id="deposit-amount"
                    type="number"
                    placeholder="Min ₱50"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reference">GCash Reference Number</Label>
                  <Input
                    id="reference"
                    placeholder="Enter reference number"
                    value={depositReference}
                    onChange={(e) => setDepositReference(e.target.value)}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Send your payment to our GCash number, then enter the reference number above. Your balance will be updated once approved.
                </p>
                <Button 
                  onClick={handleDeposit}
                  disabled={depositMutation.isPending}
                  className="w-full h-12 bg-success hover:bg-success/90"
                >
                  {depositMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    "Submit Cash-in Request"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Premium Withdrawal Status - Only show if premium and not unlocked */}
      {profile?.premium_tier && !profile?.withdrawals_unlocked && !canWithdraw && (
        <div className="px-4 pt-4">
          <Card className="border-gold/20 bg-gold/5">
            <CardContent className="p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Withdrawal Locked</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Invite 1 user who purchases any plan to unlock withdrawals.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Transactions */}
      <div className="px-4 py-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">Transaction History</h2>

        {transactionsLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
        ) : transactions?.length === 0 ? (
          <Card className="border-0 shadow-soft">
            <CardContent className="p-8 text-center">
              <Coins className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No transactions yet</p>
              <p className="text-sm text-muted-foreground">Play games to start earning!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {transactions?.map((tx) => (
              <Card key={tx.id} className="border-0 shadow-soft">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "flex items-center justify-center w-10 h-10 rounded-xl",
                      tx.type === "earning" || tx.type === "referral_commission" || tx.type === "bonus" || tx.type === "deposit"
                        ? "bg-success/10" 
                        : "bg-primary/10"
                    )}>
                      {tx.type === "withdrawal" ? (
                        <ArrowUpRight className="w-5 h-5 text-primary" />
                      ) : (
                        <ArrowDownLeft className="w-5 h-5 text-success" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground text-sm truncate">
                        {tx.description || tx.type}
                      </p>
                      <p className="text-xs text-muted-foreground">{formatDate(tx.created_at)}</p>
                    </div>

                    <div className="text-right">
                      <p className={cn(
                        "font-semibold",
                        tx.type !== "withdrawal" ? "text-success" : "text-foreground"
                      )}>
                        {tx.type === "withdrawal" ? "-" : "+"}₱{Number(tx.amount).toFixed(2)}
                      </p>
                      <div className="flex items-center gap-1 justify-end mt-0.5">
                        {getStatusIcon(tx.status as TransactionStatus)}
                        <span className="text-xs text-muted-foreground">
                          {getStatusLabel(tx.status as TransactionStatus)}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
