import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Eye, EyeOff, Mail, Lock, Loader2, Ban, Clock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import mathbotLogo from "@/assets/mathbot-logo.png";

const loginSchema = z.object({
  email: z.string().trim().email("Invalid email address").max(255),
  password: z.string().min(6, "Password must be at least 6 characters").max(100),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const navigate = useNavigate();
  const { signIn, banInfo } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginForm) => {
    setIsLoading(true);
    const { error } = await signIn(data.email, data.password);
    setIsLoading(false);

    if (error) {
      toast.error(error.message || "Failed to sign in");
      return;
    }

    toast.success("Welcome back!");
    navigate("/");
  };

  // Show ban screen
  if (banInfo) {
    const isTemporary = banInfo.ban_type === "temporary";
    const expiresDate = banInfo.expires_at ? new Date(banInfo.expires_at) : null;

    return (
      <div className="min-h-screen bg-[hsl(0,0%,93%)] flex items-center justify-center p-4">
        <div className="w-full max-w-sm bg-white rounded-3xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-destructive/10 flex items-center justify-center">
            <Ban className="w-8 h-8 text-destructive" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">
            {isTemporary ? "Account Temporarily Blocked" : "Account Permanently Banned"}
          </h2>
          <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-4 mb-4">
            <p className="text-sm font-medium text-foreground mb-1">Reason:</p>
            <p className="text-sm text-muted-foreground">{banInfo.reason}</p>
          </div>
          {isTemporary && expiresDate && (
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-4">
              <Clock className="w-4 h-4" />
              <span>Expires: {expiresDate.toLocaleString()}</span>
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            {isTemporary
              ? "Your account will be automatically unblocked after the specified time."
              : "This ban is permanent. If you believe this is a mistake, contact support."}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(0,0%,93%)] flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-xl px-8 py-10">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <img
            src={mathbotLogo}
            alt="Mathbot Logo"
            className="w-32 h-32 object-contain rounded-full drop-shadow-md"
          />
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold text-center text-[hsl(160,70%,38%)]">
          Mathbot
        </h1>
        <p className="text-center text-muted-foreground text-sm mt-1 mb-8">
          Earn real pesos daily
        </p>

        {/* Form */}
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          {/* Email */}
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/60" />
            <input
              type="email"
              placeholder="Email Address"
              autoComplete="email"
              className="w-full h-14 pl-12 pr-4 rounded-2xl border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-[hsl(160,70%,38%)]/30 focus:border-[hsl(160,70%,38%)]"
              {...form.register("email")}
            />
            {form.formState.errors.email && (
              <p className="text-xs text-destructive mt-1 pl-2">{form.formState.errors.email.message}</p>
            )}
          </div>

          {/* Password */}
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/60" />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              autoComplete="current-password"
              className="w-full h-14 pl-12 pr-12 rounded-2xl border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-[hsl(160,70%,38%)]/30 focus:border-[hsl(160,70%,38%)]"
              {...form.register("password")}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground/60 hover:text-foreground"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
            {form.formState.errors.password && (
              <p className="text-xs text-destructive mt-1 pl-2">{form.formState.errors.password.message}</p>
            )}
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-14 rounded-full bg-gradient-to-r from-[hsl(160,60%,45%)] to-[hsl(170,55%,50%)] text-white font-bold text-base shadow-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center mt-2"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              "Login & Earn"
            )}
          </button>
        </form>

        {/* Info text */}
        <p className="text-center text-muted-foreground text-xs mt-5 leading-relaxed">
          Instant withdrawal • GCash & Maya supported<br />• No hidden fees
        </p>

        {/* Forgot password */}
        <div className="mt-3 text-center">
          <Link to="/recover-password" className="text-xs text-muted-foreground hover:text-[hsl(160,70%,38%)] hover:underline">
            Forgot Password?
          </Link>
        </div>

        {/* Create account */}
        <div className="mt-4 text-center">
          <Link to="/signup" className="text-[hsl(160,70%,38%)] font-semibold text-sm hover:underline">
            Create Free Account
          </Link>
        </div>
      </div>
    </div>
  );
}
