import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Crown, Zap, Clock, Shield, Check, Loader2, Download, AlertCircle, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { getPremiumBenefits } from "@/hooks/useGameSession";
import gcashQrBasic from "@/assets/gcash-qr.png";
import gcashQrAdvance from "@/assets/gcash-qr-advance.png";
import gcashQrPro from "@/assets/gcash-qr-pro.png";

type PremiumTier = "basic" | "advance" | "pro";

interface PremiumPlan {
  id: PremiumTier;
  name: string;
  price: number;
  features: string[];
  tagline: string;
  maxEnergy: number;
  regenRate: number;
  energyDiscount: number;
  rewardBonus: number;
}

// Free tier info (not purchasable, for display only)
const freeTier = {
  name: "🏀 Free User",
  price: 0,
  features: [
    "Earn ₱0.65 per successful action",
    "Unlimited playtime everyday",
  ],
  tagline: "Best for trying the app before upgrading.",
};

const plans: PremiumPlan[] = [
  {
    id: "basic",
    name: "🟢 Basic Premium",
    price: 99,
    ...getPremiumBenefits("basic"),
    features: [
      "Earn ₱1.40 per successful action",
      "Unlimited time",
    ],
    tagline: "Good for casual players who want nonstop play.",
  },
  {
    id: "advance",
    name: "🔵 Advance Premium",
    price: 199,
    ...getPremiumBenefits("advance"),
    features: [
      "Earn ₱1.60 per successful action",
      "Unlimited time",
    ],
    tagline: "Best value for active users.",
  },
  {
    id: "pro",
    name: "🟣 Pro Premium",
    price: 299,
    ...getPremiumBenefits("pro"),
    features: [
      "Earn ₱2.00 per successful action",
      "Unlimited time",
    ],
    tagline: "For serious users who want maximum earning power.",
  },
];

export default function Premium() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();
  const [selectedPlan, setSelectedPlan] = useState<PremiumPlan | null>(null);
  const [paymentReference, setPaymentReference] = useState("");

  // Fetch user's premium orders to show pending/approved status
  const { data: userOrders } = useQuery({
    queryKey: ["premium-orders", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("premium_orders")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Subscribe to real-time updates for premium orders and profile
  useEffect(() => {
    if (!user) return;

    const ordersChannel = supabase
      .channel(`premium-orders-realtime-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "premium_orders",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ["premium-orders", user.id] });
          queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
          queryClient.invalidateQueries({ queryKey: ["transactions", user.id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(ordersChannel);
    };
  }, [user, queryClient]);

  const submitOrderMutation = useMutation({
    mutationFn: async ({ tier, amount, reference }: { tier: PremiumTier; amount: number; reference: string }) => {
      if (!user) throw new Error("Not authenticated");
      
      const { error } = await supabase.from("premium_orders").insert({
        user_id: user.id,
        tier,
        amount,
        payment_reference: reference,
        status: "pending",
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["premium-orders", user?.id] });
      setSelectedPlan(null);
      setPaymentReference("");
      toast.success("Premium order submitted! We'll review it shortly.");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to submit order");
    },
  });

  const hasPendingOrder = userOrders?.some(o => o.status === "pending");

  const handleSubmitOrder = () => {
    if (!selectedPlan) return;
    if (hasPendingOrder) {
      toast.error("You already have a pending order. Please wait for it to be processed.");
      return;
    }
    if (!paymentReference.trim()) {
      toast.error("Please enter your payment reference");
      return;
    }

    submitOrderMutation.mutate({
      tier: selectedPlan.id,
      amount: selectedPlan.price,
      reference: paymentReference,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-8">
        <div className="pt-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Premium Plans</h1>
            <p className="text-primary-foreground/80 text-sm">Boost your earnings</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-4">
        {/* Show pending or approved orders */}
        {userOrders && userOrders.length > 0 && (
          <div className="space-y-2">
            {userOrders.slice(0, 3).map((order) => (
              <Card 
                key={order.id} 
                className={cn(
                  "border-0 shadow-soft",
                  order.status === "pending" && "bg-gold/5",
                  order.status === "approved" && "bg-success/5",
                  order.status === "rejected" && "bg-destructive/5"
                )}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    {order.status === "pending" && <Clock className="w-6 h-6 text-gold" />}
                    {order.status === "approved" && <CheckCircle2 className="w-6 h-6 text-success" />}
                    {order.status === "rejected" && <AlertCircle className="w-6 h-6 text-destructive" />}
                    <div className="flex-1">
                      <p className="font-semibold text-foreground">
                        {order.tier.charAt(0).toUpperCase() + order.tier.slice(1)} Premium - ₱{order.amount}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {order.status === "pending" && "Awaiting approval"}
                        {order.status === "approved" && "Order approved - Plan active!"}
                        {order.status === "rejected" && (
                          <span className="text-destructive">
                            Rejected: {order.rejection_reason || "Order rejected"}
                          </span>
                        )}
                      </p>
                    </div>
                    <span className={cn(
                      "text-xs font-medium px-2 py-1 rounded-full",
                      order.status === "pending" && "bg-gold/20 text-gold",
                      order.status === "approved" && "bg-success/20 text-success",
                      order.status === "rejected" && "bg-destructive/20 text-destructive"
                    )}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {profile?.premium_tier && (
          <Card className="border-0 shadow-soft bg-gold/5 border-gold/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Crown className="w-8 h-8 text-gold" />
                <div>
                  <p className="font-semibold text-foreground">
                    You're on {profile.premium_tier.charAt(0).toUpperCase() + profile.premium_tier.slice(1)} Premium
                  </p>
                  <p className="text-sm text-muted-foreground">Enjoy your premium benefits!</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Free Tier Card - Show only if user is not premium */}
        {!profile?.premium_tier && (
          <Card className="border-0 shadow-soft bg-muted/30">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-muted-foreground">
                  {freeTier.name}
                </CardTitle>
                <div className="text-right">
                  <span className="text-xl font-bold text-muted-foreground">₱{freeTier.price}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <ul className="space-y-2">
                {freeTier.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
              <p className="text-xs text-muted-foreground italic">{freeTier.tagline}</p>
            </CardContent>
          </Card>
        )}

        {plans.map((plan) => {
          const isCurrentPlan = profile?.premium_tier === plan.id;
          
          return (
            <Card 
              key={plan.id}
              className={cn(
                "border-0 shadow-soft overflow-hidden transition-all",
                plan.id === "pro" && "ring-2 ring-gold",
                isCurrentPlan && "opacity-60"
              )}
            >
              {plan.id === "pro" && (
                <div className="bg-gradient-gold text-gold-foreground text-center py-1 text-xs font-semibold">
                  MOST POPULAR
                </div>
              )}
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Crown className={cn(
                      "w-5 h-5",
                      plan.id === "pro" ? "text-gold" : 
                      plan.id === "advance" ? "text-primary" : "text-muted-foreground"
                    )} />
                    {plan.name}
                  </CardTitle>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-foreground">₱{plan.price}</span>
                    <p className="text-xs text-muted-foreground">one-time</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-success mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                <p className="text-xs text-muted-foreground italic">{plan.tagline}</p>

                <Button 
                  onClick={() => setSelectedPlan(plan)}
                  disabled={isCurrentPlan || hasPendingOrder}
                  className={cn(
                    "w-full h-11",
                    plan.id === "pro" ? "bg-gradient-gold text-gold-foreground" : "bg-gradient-primary"
                  )}
                >
                  {isCurrentPlan ? "Current Plan" : hasPendingOrder ? "Pending Order Exists" : "Buy this plan"}
                </Button>
              </CardContent>
            </Card>
          );
        })}

        <div className="space-y-2 text-center px-4">
          <p className="text-xs text-muted-foreground">
            After payment, submit your reference number. Premium will be activated within 24 hours.
          </p>
          <p className="text-xs text-muted-foreground font-medium">
            Minimum withdrawal: ₱100 for all users
          </p>
          <p className="text-xs text-muted-foreground italic">
            Note: Earnings depend on successful actions and user activity. Unlimited playtime does NOT guarantee income.
          </p>
        </div>
      </div>

      {/* Payment Dialog */}
      <Dialog open={!!selectedPlan} onOpenChange={() => setSelectedPlan(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Complete Payment</DialogTitle>
            <DialogDescription>
              Pay ₱{selectedPlan?.price} to activate {selectedPlan?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="bg-muted/50 rounded-xl p-4 text-center">
              <p className="text-sm text-muted-foreground mb-3">Scan QR code to pay via GCash:</p>
              <img 
                src={selectedPlan?.id === "pro" ? gcashQrPro : selectedPlan?.id === "advance" ? gcashQrAdvance : gcashQrBasic} 
                alt="GCash QR Code" 
                className="w-48 h-48 mx-auto rounded-lg"
              />
              <p className="text-sm text-muted-foreground mt-3">
                Amount: <span className="font-bold text-foreground">₱{selectedPlan?.price}</span>
              </p>
              <a
                href={selectedPlan?.id === "pro" ? gcashQrPro : selectedPlan?.id === "advance" ? gcashQrAdvance : gcashQrBasic}
                download={`gcash-qr-${selectedPlan?.id}.png`}
                className="inline-flex items-center gap-2 mt-3 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download QR Code
              </a>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reference">Payment Reference Number</Label>
              <Input
                id="reference"
                placeholder="Enter your reference number"
                value={paymentReference}
                onChange={(e) => setPaymentReference(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Enter the reference number from your payment confirmation
              </p>
            </div>

            <Button 
              onClick={handleSubmitOrder}
              disabled={submitOrderMutation.isPending}
              className="w-full h-12 bg-gradient-primary"
            >
              {submitOrderMutation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                "Submit Payment"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
