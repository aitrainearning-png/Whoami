import { useNavigate } from "react-router-dom";
import { Crown, Settings, LogOut, ChevronRight, Shield } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ProfileHeader } from "@/components/profile/ProfileHeader";
import { AccountStats } from "@/components/profile/AccountStats";
import { ReferralSection } from "@/components/profile/ReferralSection";
import heroRobotBanner from "@/assets/hero-robot-banner.png";

export default function Profile() {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { data: profile, isLoading } = useProfile();
  const queryClient = useQueryClient();

  const { data: isAdmin = false } = useQuery({
    queryKey: ["is-admin", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user!.id)
        .eq("role", "admin")
        .maybeSingle();

      if (error) return false;
      return !!data;
    },
  });

  const handleUpgrade = () => {
    navigate("/premium");
  };

  const handleLogout = async () => {
    await signOut();
    navigate("/login");
    toast.success("Logged out successfully");
  };

  const handleAvatarUpdate = () => {
    // Refresh profile data
    queryClient.invalidateQueries({ queryKey: ["profile", user?.id] });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <header className="bg-gradient-header pt-safe px-4 pb-6 rounded-b-2xl">
          <div className="pt-6">
            <Skeleton className="h-7 w-20 bg-white/20" />
          </div>
          <div className="mt-4">
            <Skeleton className="h-20 w-full rounded-xl" />
          </div>
        </header>
        <div className="px-4 py-4 space-y-4">
          <Skeleton className="h-12 w-full rounded-xl" />
          <div className="grid grid-cols-2 gap-3">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Compact Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6 rounded-b-2xl relative overflow-hidden">
        <img
          src={heroRobotBanner}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 w-full h-full object-cover opacity-60 pointer-events-none"
        />
        <div className="pt-6 mb-4">
          <h1 className="text-xl font-bold text-primary-foreground">Profile</h1>
        </div>

        {/* Profile Card */}
        <ProfileHeader
          profile={profile}
          email={user?.email}
          isLoading={isLoading}
          onAvatarUpdate={handleAvatarUpdate}
        />
      </header>

      {/* Content */}
      <div className="px-4 py-4 space-y-4">
        {/* Admin Panel (only visible to admins) */}
        {isAdmin && (
          <Button
            onClick={() => navigate("/admin")}
            variant="secondary"
            className="w-full h-12 rounded-xl shadow-soft justify-between"
          >
            <span className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Admin Panel
            </span>
            <ChevronRight className="w-5 h-5" />
          </Button>
        )}

        {/* Slim Premium Upgrade Button */}
        {!profile?.premium_tier && (
          <Button
            onClick={handleUpgrade}
            className="w-full h-12 bg-gradient-gold text-gold-foreground hover:opacity-90 rounded-xl shadow-soft"
          >
            <Crown className="w-5 h-5 mr-2" />
            Upgrade to Premium
          </Button>
        )}

        {/* Account Stats */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            Account
          </h3>
          <AccountStats profile={profile} />
        </div>

        {/* Referral Section */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            Referral Program
          </h3>
          <ReferralSection profile={profile} />
        </div>

        {/* Settings Menu */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            Settings
          </h3>
          <Card className="border-0 shadow-soft overflow-hidden">
            <button className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors">
              <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center">
                <Settings className="w-4 h-4 text-muted-foreground" />
              </div>
              <span className="flex-1 text-left text-sm font-medium text-foreground">
                Account Settings
              </span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>

            <div className="h-px bg-border mx-3" />

            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors"
            >
              <div className="w-9 h-9 rounded-lg bg-destructive/10 flex items-center justify-center">
                <LogOut className="w-4 h-4 text-destructive" />
              </div>
              <span className="flex-1 text-left text-sm font-medium text-destructive">
                Log Out
              </span>
            </button>
          </Card>
        </div>
      </div>
    </div>
  );
}
