import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { useChatEnabled } from "@/hooks/useChatEnabled";
import { supabase } from "@/integrations/supabase/client";
import { ChatHeader } from "@/components/community/ChatHeader";
import { ChatMessage } from "@/components/community/ChatMessage";
import { ChatInput } from "@/components/community/ChatInput";

interface ChatMessageData {
  id: string;
  user_id: string;
  display_name: string;
  message: string;
  created_at: string;
  avatar_url: string | null;
  image_url: string | null;
}

// Simple profanity filter
const profanityList = ["badword1", "badword2"];
const filterProfanity = (text: string) => {
  let filtered = text;
  profanityList.forEach((word) => {
    const regex = new RegExp(word, "gi");
    filtered = filtered.replace(regex, "***");
  });
  return filtered;
};

export default function Community() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const { chatEnabled } = useChatEnabled();
  const queryClient = useQueryClient();
  const [isAdmin, setIsAdmin] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const lastSentRef = useRef<number>(0);

  // Check if user is admin
  useEffect(() => {
    async function checkAdmin() {
      if (!user) {
        setIsAdmin(false);
        return;
      }

      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      setIsAdmin(!!data);
    }
    checkAdmin();
  }, [user]);

  // Fetch messages
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["chat-messages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("*")
        .order("created_at", { ascending: true })
        .limit(100);

      if (error) throw error;
      return data as ChatMessageData[];
    },
  });

  // Send message mutation
  const sendMessage = useMutation({
    mutationFn: async ({ text, imageUrl }: { text: string; imageUrl?: string }) => {
      if (!user || !profile) throw new Error("Not authenticated");

      const { error } = await supabase.from("chat_messages").insert({
        user_id: user.id,
        display_name: profile.display_name || user.email?.split("@")[0] || "Anonymous",
        message: filterProfanity(text),
        avatar_url: profile.avatar_url || null,
        image_url: imageUrl || null,
      });

      if (error) throw error;
    },
    onError: (error: any) => {
      if (error.message?.includes("row-level security") || error.code === "42501") {
        toast.error("Only admins can send links in messages");
      } else {
        toast.error("Failed to send message");
      }
    },
  });

  // Delete message mutation (admin only)
  const deleteMessage = useMutation({
    mutationFn: async (messageId: string) => {
      const { error } = await supabase.from("chat_messages").delete().eq("id", messageId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chat-messages"] });
      toast.success("Message deleted");
    },
    onError: () => {
      toast.error("Failed to delete message");
    },
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel("chat-messages")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
        },
        (payload) => {
          queryClient.setQueryData(["chat-messages"], (old: ChatMessageData[] = []) => {
            const newMessage = payload.new as ChatMessageData;
            if (old.some((m) => m.id === newMessage.id)) return old;
            return [...old, newMessage];
          });
        }
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "chat_messages",
        },
        (payload) => {
          queryClient.setQueryData(["chat-messages"], (old: ChatMessageData[] = []) => {
            return old.filter((m) => m.id !== (payload.old as any).id);
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (text: string, imageUrl?: string) => {
    sendMessage.mutate({ text, imageUrl });
  };

  return (
    <div className="flex flex-col h-[100dvh] bg-background">
      {/* Header */}
      <ChatHeader />

      {/* Messages Area - Takes remaining space */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto px-4 py-4"
      >
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex gap-3">
                <Skeleton className="w-8 h-8 rounded-full shrink-0" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-12 w-48" />
                </div>
              </div>
            ))}
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <Users className="w-12 h-12 text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No messages yet</p>
            <p className="text-sm text-muted-foreground">Be the first to say hello!</p>
          </div>
        ) : (
          <div className="space-y-4 pb-4">
            {messages.map((msg) => (
              <ChatMessage
                key={msg.id}
                message={msg}
                isOwn={msg.user_id === user?.id}
                isAdmin={isAdmin}
                onDelete={(id) => deleteMessage.mutate(id)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Fixed Input Bar - Above bottom nav */}
      <div className="shrink-0 border-t border-border bg-card px-4 py-3 pb-[calc(env(safe-area-inset-bottom)+80px)]">
        <div className="max-w-lg mx-auto">
          <ChatInput
            onSend={handleSend}
            isSending={sendMessage.isPending}
            lastSentTime={lastSentRef}
            disabled={!chatEnabled && !isAdmin}
            disabledMessage="Community Chat was temporary turn off by Developer"
            isAdmin={isAdmin}
          />
        </div>
      </div>
    </div>
  );
}
