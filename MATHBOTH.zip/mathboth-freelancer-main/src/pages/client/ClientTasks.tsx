import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { Plus, Play, Pause, Eye } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

export default function ClientTasks() {
  const { client } = useClientAuth();
  const queryClient = useQueryClient();

  const { data: tasks, isLoading } = useQuery({
    queryKey: ["client-tasks", client?.id],
    queryFn: async () => {
      if (!client) return [];

      const { data } = await supabase
        .from("client_tasks")
        .select(`
          *,
          task_categories(name)
        `)
        .eq("client_id", client.id)
        .order("created_at", { ascending: false });

      return data || [];
    },
    enabled: !!client,
  });

  const toggleTaskStatus = useMutation({
    mutationFn: async ({ taskId, newStatus }: { taskId: string; newStatus: "draft" | "active" | "paused" | "completed" }) => {
      const { error } = await supabase
        .from("client_tasks")
        .update({ status: newStatus })
        .eq("id", taskId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-tasks"] });
      toast.success("Task status updated");
    },
    onError: () => {
      toast.error("Failed to update task status");
    },
  });

  const getStatusBadge = (status: string) => {
    const styles = {
      draft: "bg-gray-500/20 text-gray-600",
      active: "bg-green-500/20 text-green-600",
      paused: "bg-yellow-500/20 text-yellow-600",
      completed: "bg-blue-500/20 text-blue-600",
    };
    return <Badge className={styles[status as keyof typeof styles]}>{status}</Badge>;
  };

  const filterTasks = (status: string) => {
    if (status === "all") return tasks;
    return tasks?.filter((t) => t.status === status);
  };

  const TaskCard = ({ task }: { task: any }) => (
    <Card key={task.id}>
      <CardContent className="pt-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold">{task.title}</h3>
              {getStatusBadge(task.status)}
            </div>
            <p className="text-sm text-muted-foreground">
              {task.task_categories?.name || "Uncategorized"}
            </p>
          </div>
          <p className="text-lg font-bold text-primary">₱{Number(task.reward_per_user).toFixed(2)}</p>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <div>
            <span className="text-muted-foreground">Budget:</span>{" "}
            <span className="font-medium">
              ₱{Number(task.remaining_budget).toFixed(2)} / ₱{Number(task.total_budget).toFixed(2)}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Workers:</span>{" "}
            <span className="font-medium">
              {task.approved_count} / {task.max_workers}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Deadline:</span>{" "}
            <span className="font-medium">
              {format(new Date(task.deadline), "MMM d, yyyy")}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Submissions:</span>{" "}
            <span className="font-medium text-green-600">{task.approved_count} ✓</span>{" "}
            <span className="font-medium text-red-600">{task.rejected_count} ✗</span>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          {task.status === "active" && (
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                toggleTaskStatus.mutate({ taskId: task.id, newStatus: "paused" })
              }
            >
              <Pause className="mr-1 h-4 w-4" />
              Pause
            </Button>
          )}
          {task.status === "paused" && (
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                toggleTaskStatus.mutate({ taskId: task.id, newStatus: "active" })
              }
            >
              <Play className="mr-1 h-4 w-4" />
              Resume
            </Button>
          )}
          <Link to={`/client/tasks/${task.id}`}>
            <Button size="sm" variant="outline">
              <Eye className="mr-1 h-4 w-4" />
              View
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <ClientLayout>
      <div className="container p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">My Tasks</h1>
          <Link to="/client/tasks/create">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Task
            </Button>
          </Link>
        </div>

        <Tabs defaultValue="all">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="paused">Paused</TabsTrigger>
            <TabsTrigger value="completed">Done</TabsTrigger>
          </TabsList>

          {["all", "active", "paused", "completed"].map((status) => (
            <TabsContent key={status} value={status} className="space-y-4 mt-4">
              {isLoading ? (
                <p className="text-center text-muted-foreground py-8">Loading...</p>
              ) : filterTasks(status)?.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No tasks found</p>
              ) : (
                filterTasks(status)?.map((task) => <TaskCard key={task.id} task={task} />)
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </ClientLayout>
  );
}
