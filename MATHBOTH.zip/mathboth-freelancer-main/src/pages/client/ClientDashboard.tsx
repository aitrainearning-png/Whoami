import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Wallet, ListTodo, ClipboardCheck, Plus, AlertCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export default function ClientDashboard() {
  const { client, wallet } = useClientAuth();

  const { data: taskStats } = useQuery({
    queryKey: ["client-task-stats", client?.id],
    queryFn: async () => {
      if (!client) return null;

      const { data: tasks } = await supabase
        .from("client_tasks")
        .select("status, approved_count, rejected_count")
        .eq("client_id", client.id);

      const active = tasks?.filter((t) => t.status === "active").length || 0;
      const paused = tasks?.filter((t) => t.status === "paused").length || 0;
      const completed = tasks?.filter((t) => t.status === "completed").length || 0;
      const totalApproved = tasks?.reduce((sum, t) => sum + (t.approved_count || 0), 0) || 0;
      const totalRejected = tasks?.reduce((sum, t) => sum + (t.rejected_count || 0), 0) || 0;

      return { active, paused, completed, totalApproved, totalRejected, total: tasks?.length || 0 };
    },
    enabled: !!client,
  });

  const { data: pendingSubmissions } = useQuery({
    queryKey: ["client-pending-submissions", client?.id],
    queryFn: async () => {
      if (!client) return 0;

      const { data: tasks } = await supabase
        .from("client_tasks")
        .select("id")
        .eq("client_id", client.id);

      if (!tasks?.length) return 0;

      const taskIds = tasks.map((t) => t.id);
      const { count } = await supabase
        .from("task_submissions")
        .select("*", { count: "exact", head: true })
        .in("task_id", taskIds)
        .eq("status", "pending");

      return count || 0;
    },
    enabled: !!client,
  });

  if (client?.status === "pending") {
    return (
      <ClientLayout>
        <div className="container p-4">
          <Card className="border-yellow-500/50 bg-yellow-500/10">
            <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
              <AlertCircle className="h-16 w-16 text-yellow-500" />
              <h2 className="text-xl font-semibold">Account Pending Approval</h2>
              <p className="text-muted-foreground max-w-md">
                Your client account is currently being reviewed by our admin team.
                You'll receive access to all features once your account is approved.
              </p>
            </CardContent>
          </Card>
        </div>
      </ClientLayout>
    );
  }

  if (client?.status === "suspended") {
    return (
      <ClientLayout>
        <div className="container p-4">
          <Card className="border-destructive/50 bg-destructive/10">
            <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
              <AlertCircle className="h-16 w-16 text-destructive" />
              <h2 className="text-xl font-semibold">Account Suspended</h2>
              <p className="text-muted-foreground max-w-md">
                Your client account has been suspended. Please contact support for assistance.
              </p>
            </CardContent>
          </Card>
        </div>
      </ClientLayout>
    );
  }

  return (
    <ClientLayout>
      <div className="container p-4 space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-2xl font-bold">
            Welcome, {client?.display_name || client?.email?.split("@")[0]}
          </h1>
          <p className="text-muted-foreground">Manage your tasks and workers</p>
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Wallet Balance</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₱{wallet?.balance?.toFixed(2) || "0.00"}</div>
              <Link to="/client/wallet">
                <Button variant="link" className="p-0 h-auto text-sm">
                  View Wallet →
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Active Tasks</CardTitle>
              <ListTodo className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taskStats?.active || 0}</div>
              <p className="text-xs text-muted-foreground">
                {taskStats?.paused || 0} paused, {taskStats?.completed || 0} completed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
              <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pendingSubmissions || 0}</div>
              <Link to="/client/submissions">
                <Button variant="link" className="p-0 h-auto text-sm">
                  Review Submissions →
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Link to="/client/tasks/create">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create New Task
              </Button>
            </Link>
            <Link to="/client/wallet">
              <Button variant="outline">
                <Wallet className="mr-2 h-4 w-4" />
                Deposit Funds
              </Button>
            </Link>
            <Link to="/client/submissions">
              <Button variant="outline">
                <ClipboardCheck className="mr-2 h-4 w-4" />
                Review Submissions
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Stats Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Submission Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="rounded-lg bg-green-500/10 p-4">
                <div className="text-2xl font-bold text-green-600">
                  {taskStats?.totalApproved || 0}
                </div>
                <div className="text-sm text-muted-foreground">Approved</div>
              </div>
              <div className="rounded-lg bg-red-500/10 p-4">
                <div className="text-2xl font-bold text-red-600">
                  {taskStats?.totalRejected || 0}
                </div>
                <div className="text-sm text-muted-foreground">Rejected</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </ClientLayout>
  );
}
