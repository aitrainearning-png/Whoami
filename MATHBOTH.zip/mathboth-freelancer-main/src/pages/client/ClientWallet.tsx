import { useState } from "react";
import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Wallet, Plus, ArrowDownCircle, ArrowUpCircle, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

export default function ClientWallet() {
  const { client, wallet, refreshWallet } = useClientAuth();
  const [depositAmount, setDepositAmount] = useState("");
  const [paymentProof, setPaymentProof] = useState("");
  const [isDepositing, setIsDepositing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: transactions, refetch: refetchTransactions } = useQuery({
    queryKey: ["client-transactions", client?.id],
    queryFn: async () => {
      if (!client) return [];

      const { data } = await supabase
        .from("client_transactions")
        .select("*")
        .eq("client_id", client.id)
        .order("created_at", { ascending: false })
        .limit(50);

      return data || [];
    },
    enabled: !!client,
  });

  const handleDeposit = async () => {
    if (!client || !depositAmount) return;

    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    setIsDepositing(true);
    const { error } = await supabase.from("client_transactions").insert({
      client_id: client.id,
      type: "deposit",
      amount,
      status: "pending",
      description: "Deposit request",
      payment_proof_url: paymentProof || null,
    });

    setIsDepositing(false);

    if (error) {
      toast.error("Failed to submit deposit request");
    } else {
      toast.success("Deposit request submitted for approval");
      setDepositAmount("");
      setPaymentProof("");
      setDialogOpen(false);
      refetchTransactions();
    }
  };

  const getTransactionIcon = (type: string, status: string) => {
    if (type === "deposit") {
      return <ArrowDownCircle className="h-5 w-5 text-green-500" />;
    }
    if (type === "task_spend") {
      return <ArrowUpCircle className="h-5 w-5 text-red-500" />;
    }
    return <Clock className="h-5 w-5 text-muted-foreground" />;
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: "bg-yellow-500/20 text-yellow-600",
      approved: "bg-green-500/20 text-green-600",
      rejected: "bg-red-500/20 text-red-600",
      completed: "bg-blue-500/20 text-blue-600",
    };
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${styles[status as keyof typeof styles] || ""}`}>
        {status}
      </span>
    );
  };

  return (
    <ClientLayout>
      <div className="container p-4 space-y-6">
        {/* Wallet Overview */}
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Available Balance</p>
                <p className="text-4xl font-bold">₱{wallet?.balance?.toFixed(2) || "0.00"}</p>
              </div>
              <Wallet className="h-12 w-12 text-primary/50" />
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Total Deposited</p>
                <p className="font-semibold">₱{wallet?.total_deposited?.toFixed(2) || "0.00"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Total Spent</p>
                <p className="font-semibold">₱{wallet?.total_spent?.toFixed(2) || "0.00"}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deposit Button */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full">
              <Plus className="mr-2 h-4 w-4" />
              Deposit Funds
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Deposit Funds</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Amount (₱)</Label>
                <Input
                  type="number"
                  min="1"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Payment Proof URL (optional)</Label>
                <Input
                  type="url"
                  placeholder="https://..."
                  value={paymentProof}
                  onChange={(e) => setPaymentProof(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Upload your payment screenshot to a cloud service and paste the link here
                </p>
              </div>
              <div className="rounded-lg bg-muted p-3 text-sm">
                <p className="font-medium">Payment Instructions:</p>
                <p className="text-muted-foreground mt-1">
                  1. Send payment to our GCash: 09XX XXX XXXX
                </p>
                <p className="text-muted-foreground">
                  2. Submit this form with the amount
                </p>
                <p className="text-muted-foreground">
                  3. Wait for admin approval (usually within 24 hours)
                </p>
              </div>
              <Button
                onClick={handleDeposit}
                disabled={isDepositing || !depositAmount}
                className="w-full"
              >
                {isDepositing ? "Submitting..." : "Submit Deposit Request"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
          </CardHeader>
          <CardContent>
            {transactions?.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No transactions yet</p>
            ) : (
              <div className="space-y-3">
                {transactions?.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between rounded-lg border p-3"
                  >
                    <div className="flex items-center gap-3">
                      {getTransactionIcon(tx.type, tx.status)}
                      <div>
                        <p className="font-medium capitalize">{tx.type.replace("_", " ")}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(tx.created_at), "MMM d, yyyy h:mm a")}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={`font-semibold ${
                          tx.type === "deposit" ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        {tx.type === "deposit" ? "+" : "-"}₱{Number(tx.amount).toFixed(2)}
                      </p>
                      {getStatusBadge(tx.status)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ClientLayout>
  );
}
