import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { DollarSign, CheckCircle, XCircle, Wallet, ListTodo, Users } from "lucide-react";

export default function ClientAnalytics() {
  const { client, wallet } = useClientAuth();

  const { data: stats } = useQuery({
    queryKey: ["client-analytics", client?.id],
    queryFn: async () => {
      if (!client) return null;

      // Get all tasks
      const { data: tasks } = await supabase
        .from("client_tasks")
        .select("*")
        .eq("client_id", client.id);

      // Get all transactions
      const { data: transactions } = await supabase
        .from("client_transactions")
        .select("*")
        .eq("client_id", client.id)
        .eq("status", "completed");

      const totalSpent = transactions
        ?.filter((t) => t.type === "task_spend")
        .reduce((sum, t) => sum + Number(t.amount), 0) || 0;

      const totalDeposited = transactions
        ?.filter((t) => t.type === "deposit")
        .reduce((sum, t) => sum + Number(t.amount), 0) || 0;

      const totalApproved = tasks?.reduce((sum, t) => sum + (t.approved_count || 0), 0) || 0;
      const totalRejected = tasks?.reduce((sum, t) => sum + (t.rejected_count || 0), 0) || 0;
      const activeTasks = tasks?.filter((t) => t.status === "active").length || 0;
      const completedTasks = tasks?.filter((t) => t.status === "completed").length || 0;

      return {
        totalSpent,
        totalDeposited,
        totalApproved,
        totalRejected,
        totalTasks: tasks?.length || 0,
        activeTasks,
        completedTasks,
        approvalRate: totalApproved + totalRejected > 0 
          ? ((totalApproved / (totalApproved + totalRejected)) * 100).toFixed(1)
          : "0",
      };
    },
    enabled: !!client,
  });

  const StatCard = ({
    title,
    value,
    icon: Icon,
    description,
    className,
  }: {
    title: string;
    value: string | number;
    icon: any;
    description?: string;
    className?: string;
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-4 w-4 ${className || "text-muted-foreground"}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
      </CardContent>
    </Card>
  );

  return (
    <ClientLayout>
      <div className="container p-4 space-y-6">
        <h1 className="text-2xl font-bold">Analytics</h1>

        {/* Financial Stats */}
        <div>
          <h2 className="text-lg font-semibold mb-3">Financial Overview</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <StatCard
              title="Current Balance"
              value={`₱${wallet?.balance?.toFixed(2) || "0.00"}`}
              icon={Wallet}
              className="text-primary"
            />
            <StatCard
              title="Total Deposited"
              value={`₱${stats?.totalDeposited?.toFixed(2) || "0.00"}`}
              icon={DollarSign}
              className="text-green-500"
            />
            <StatCard
              title="Total Spent"
              value={`₱${stats?.totalSpent?.toFixed(2) || "0.00"}`}
              icon={DollarSign}
              className="text-red-500"
            />
          </div>
        </div>

        {/* Task Stats */}
        <div>
          <h2 className="text-lg font-semibold mb-3">Task Overview</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <StatCard
              title="Total Tasks"
              value={stats?.totalTasks || 0}
              icon={ListTodo}
              description={`${stats?.activeTasks || 0} active, ${stats?.completedTasks || 0} completed`}
            />
            <StatCard
              title="Approved Submissions"
              value={stats?.totalApproved || 0}
              icon={CheckCircle}
              className="text-green-500"
            />
            <StatCard
              title="Rejected Submissions"
              value={stats?.totalRejected || 0}
              icon={XCircle}
              className="text-red-500"
            />
          </div>
        </div>

        {/* Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="text-center p-4 rounded-lg bg-muted">
                <div className="text-4xl font-bold text-primary">
                  {stats?.approvalRate || 0}%
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Approval Rate
                </div>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted">
                <div className="text-4xl font-bold text-primary">
                  {(stats?.totalApproved || 0) + (stats?.totalRejected || 0)}
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Total Submissions Reviewed
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Average reward per task:</span>
              <span className="font-medium">
                ₱{stats?.totalTasks && stats.totalSpent 
                  ? (stats.totalSpent / stats.totalTasks).toFixed(2) 
                  : "0.00"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Average workers per task:</span>
              <span className="font-medium">
                {stats?.totalTasks && stats.totalApproved 
                  ? (stats.totalApproved / stats.totalTasks).toFixed(1) 
                  : "0"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cost per approved submission:</span>
              <span className="font-medium">
                ₱{stats?.totalApproved && stats.totalSpent 
                  ? (stats.totalSpent / stats.totalApproved).toFixed(2) 
                  : "0.00"}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </ClientLayout>
  );
}
