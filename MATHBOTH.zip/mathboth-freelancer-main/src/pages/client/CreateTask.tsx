import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, AlertCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function CreateTask() {
  const navigate = useNavigate();
  const { client, wallet, refreshWallet } = useClientAuth();

  const [title, setTitle] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [instructions, setInstructions] = useState("");
  const [rewardPerUser, setRewardPerUser] = useState("");
  const [maxWorkers, setMaxWorkers] = useState("");
  const [deadline, setDeadline] = useState("");
  const [proofType, setProofType] = useState<"text" | "image" | "link">("text");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: categories } = useQuery({
    queryKey: ["task-categories"],
    queryFn: async () => {
      const { data } = await supabase
        .from("task_categories")
        .select("*")
        .eq("is_active", true)
        .order("name");
      return data || [];
    },
  });

  const totalBudget =
    parseFloat(rewardPerUser || "0") * parseInt(maxWorkers || "0");
  const hasInsufficientBalance = totalBudget > (wallet?.balance || 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!client || !wallet) return;

    if (!title.trim() || !instructions.trim() || !rewardPerUser || !maxWorkers || !deadline) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (totalBudget <= 0) {
      toast.error("Invalid budget calculation");
      return;
    }

    if (hasInsufficientBalance) {
      toast.error("Insufficient wallet balance");
      return;
    }

    setIsSubmitting(true);

    // Create the task
    const { data: task, error: taskError } = await supabase
      .from("client_tasks")
      .insert({
        client_id: client.id,
        title: title.trim(),
        category_id: categoryId || null,
        instructions: instructions.trim(),
        reward_per_user: parseFloat(rewardPerUser),
        max_workers: parseInt(maxWorkers),
        total_budget: totalBudget,
        remaining_budget: totalBudget,
        deadline: new Date(deadline).toISOString(),
        proof_type: proofType,
        status: "active",
      })
      .select()
      .single();

    if (taskError) {
      setIsSubmitting(false);
      toast.error("Failed to create task");
      return;
    }

    // Deduct from wallet
    const { error: walletError } = await supabase
      .from("client_wallets")
      .update({
        balance: wallet.balance - totalBudget,
      })
      .eq("id", wallet.id);

    if (walletError) {
      // Rollback task creation if wallet update fails
      await supabase.from("client_tasks").delete().eq("id", task.id);
      setIsSubmitting(false);
      toast.error("Failed to process payment");
      return;
    }

    // Record transaction
    await supabase.from("client_transactions").insert({
      client_id: client.id,
      type: "task_spend",
      amount: totalBudget,
      status: "completed",
      description: `Task created: ${title}`,
      reference_id: task.id,
    });

    refreshWallet();
    setIsSubmitting(false);
    toast.success("Task created successfully!");
    navigate("/client/tasks");
  };

  return (
    <ClientLayout>
      <div className="container p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">Create New Task</h1>
        </div>

        <Card>
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Task Title *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  maxLength={100}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={categoryId} onValueChange={setCategoryId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories?.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="instructions">Task Instructions *</Label>
                <Textarea
                  id="instructions"
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reward">Reward per User (₱) *</Label>
                  <Input
                    id="reward"
                    type="number"
                    min="1"
                    step="0.01"
                    value={rewardPerUser}
                    onChange={(e) => setRewardPerUser(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="workers">Max Workers *</Label>
                  <Input
                    id="workers"
                    type="number"
                    min="1"
                    value={maxWorkers}
                    onChange={(e) => setMaxWorkers(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="deadline">Deadline *</Label>
                <Input
                  id="deadline"
                  type="datetime-local"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  min={new Date().toISOString().slice(0, 16)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Required Proof Type *</Label>
                <Select value={proofType} onValueChange={(v) => setProofType(v as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text">Text Description</SelectItem>
                    <SelectItem value="image">Screenshot / Image</SelectItem>
                    <SelectItem value="link">URL / Link</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Budget Summary */}
              <Card className={hasInsufficientBalance ? "border-destructive" : ""}>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-muted-foreground">Total Budget:</span>
                    <span className="text-xl font-bold">
                      ₱{totalBudget.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Your Balance:</span>
                    <span className={hasInsufficientBalance ? "text-destructive" : ""}>
                      ₱{wallet?.balance?.toFixed(2) || "0.00"}
                    </span>
                  </div>
                  {hasInsufficientBalance && (
                    <div className="mt-2 flex items-center gap-2 text-sm text-destructive">
                      <AlertCircle className="h-4 w-4" />
                      Insufficient balance. Please deposit more funds.
                    </div>
                  )}
                </CardContent>
              </Card>

              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting || hasInsufficientBalance}
              >
                {isSubmitting ? "Creating..." : "Create Task"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </ClientLayout>
  );
}
