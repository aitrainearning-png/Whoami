import { useParams, useNavigate } from "react-router-dom";
import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, Pause, Check, X } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

export default function TaskDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { client, refreshWallet } = useClientAuth();
  const queryClient = useQueryClient();

  const { data: task, isLoading } = useQuery({
    queryKey: ["client-task", id],
    queryFn: async () => {
      const { data } = await supabase
        .from("client_tasks")
        .select(`
          *,
          task_categories(name)
        `)
        .eq("id", id)
        .single();

      return data;
    },
    enabled: !!id,
  });

  const { data: submissions } = useQuery({
    queryKey: ["task-submissions", id],
    queryFn: async () => {
      const { data } = await supabase
        .from("task_submissions")
        .select("*")
        .eq("task_id", id)
        .order("created_at", { ascending: false });

      return data || [];
    },
    enabled: !!id,
  });

  const toggleStatus = useMutation({
    mutationFn: async (newStatus: "draft" | "active" | "paused" | "completed") => {
      const { error } = await supabase
        .from("client_tasks")
        .update({ status: newStatus })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-task", id] });
      toast.success("Task status updated");
    },
  });

  const approveSubmission = useMutation({
    mutationFn: async (submission: any) => {
      const rewardAmount = task?.reward_per_user;

      await supabase
        .from("task_submissions")
        .update({
          status: "approved",
          reward_amount: rewardAmount,
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", submission.id);

      await supabase
        .from("client_tasks")
        .update({
          approved_count: (task?.approved_count || 0) + 1,
          remaining_budget: (task?.remaining_budget || 0) - rewardAmount,
        })
        .eq("id", id);

      // Credit user
      const { data: userProfile } = await supabase
        .from("profiles")
        .select("balance")
        .eq("user_id", submission.user_id)
        .single();

      if (userProfile) {
        await supabase
          .from("profiles")
          .update({ balance: userProfile.balance + rewardAmount })
          .eq("user_id", submission.user_id);

        await supabase.from("transactions").insert({
          user_id: submission.user_id,
          type: "earning",
          amount: rewardAmount,
          status: "completed",
          description: `Task reward: ${task?.title}`,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-task", id] });
      queryClient.invalidateQueries({ queryKey: ["task-submissions", id] });
      refreshWallet();
      toast.success("Submission approved!");
    },
  });

  const rejectSubmission = useMutation({
    mutationFn: async (submissionId: string) => {
      await supabase
        .from("task_submissions")
        .update({
          status: "rejected",
          rejection_reason: "Rejected by client",
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", submissionId);

      await supabase
        .from("client_tasks")
        .update({
          rejected_count: (task?.rejected_count || 0) + 1,
        })
        .eq("id", id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-task", id] });
      queryClient.invalidateQueries({ queryKey: ["task-submissions", id] });
      toast.success("Submission rejected");
    },
  });

  if (isLoading) {
    return (
      <ClientLayout>
        <div className="container p-4">Loading...</div>
      </ClientLayout>
    );
  }

  if (!task) {
    return (
      <ClientLayout>
        <div className="container p-4">Task not found</div>
      </ClientLayout>
    );
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      draft: "bg-gray-500/20 text-gray-600",
      active: "bg-green-500/20 text-green-600",
      paused: "bg-yellow-500/20 text-yellow-600",
      completed: "bg-blue-500/20 text-blue-600",
      pending: "bg-yellow-500/20 text-yellow-600",
      approved: "bg-green-500/20 text-green-600",
      rejected: "bg-red-500/20 text-red-600",
    };
    return <Badge className={styles[status as keyof typeof styles]}>{status}</Badge>;
  };

  return (
    <ClientLayout>
      <div className="container p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold flex-1">{task.title}</h1>
          {getStatusBadge(task.status)}
        </div>

        {/* Task Details */}
        <Card>
          <CardHeader>
            <CardTitle>Task Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <span className="text-sm text-muted-foreground">Category:</span>
              <p>{task.task_categories?.name || "Uncategorized"}</p>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">Instructions:</span>
              <p className="whitespace-pre-wrap">{task.instructions}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-sm text-muted-foreground">Reward per User:</span>
                <p className="font-semibold">₱{Number(task.reward_per_user).toFixed(2)}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Max Workers:</span>
                <p className="font-semibold">{task.max_workers}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Budget:</span>
                <p className="font-semibold">
                  ₱{Number(task.remaining_budget).toFixed(2)} / ₱{Number(task.total_budget).toFixed(2)}
                </p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Deadline:</span>
                <p className="font-semibold">{format(new Date(task.deadline), "MMM d, yyyy h:mm a")}</p>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              {task.status === "active" && (
                <Button
                  variant="outline"
                  onClick={() => toggleStatus.mutate("paused")}
                >
                  <Pause className="mr-2 h-4 w-4" />
                  Pause Task
                </Button>
              )}
              {task.status === "paused" && (
                <Button
                  variant="outline"
                  onClick={() => toggleStatus.mutate("active")}
                >
                  <Play className="mr-2 h-4 w-4" />
                  Resume Task
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Submissions */}
        <Card>
          <CardHeader>
            <CardTitle>
              Submissions ({submissions?.length || 0})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {submissions?.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">
                No submissions yet
              </p>
            ) : (
              <div className="space-y-3">
                {submissions?.map((sub) => (
                  <div key={sub.id} className="rounded-lg border p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(sub.created_at), "MMM d, yyyy h:mm a")}
                      </div>
                      {getStatusBadge(sub.status)}
                    </div>
                    <p className="text-sm break-words">{sub.proof_content}</p>
                    {sub.proof_image_url && (
                      <a
                        href={sub.proof_image_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary hover:underline"
                      >
                        View Image
                      </a>
                    )}
                    {sub.status === "pending" && (
                      <div className="mt-2 flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => approveSubmission.mutate(sub)}
                        >
                          <Check className="mr-1 h-4 w-4" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => rejectSubmission.mutate(sub.id)}
                        >
                          <X className="mr-1 h-4 w-4" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ClientLayout>
  );
}
