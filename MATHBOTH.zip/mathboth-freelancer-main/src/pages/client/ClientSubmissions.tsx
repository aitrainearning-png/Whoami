import { useState } from "react";
import { useClientAuth } from "@/contexts/ClientAuthContext";
import { ClientLayout } from "@/components/client/ClientLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Check, X, ExternalLink, Image } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

export default function ClientSubmissions() {
  const { client, wallet, refreshWallet } = useClientAuth();
  const queryClient = useQueryClient();
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);

  const { data: submissions, isLoading } = useQuery({
    queryKey: ["client-submissions", client?.id],
    queryFn: async () => {
      if (!client) return [];

      // First get all task IDs for this client
      const { data: tasks } = await supabase
        .from("client_tasks")
        .select("id, title, reward_per_user")
        .eq("client_id", client.id);

      if (!tasks?.length) return [];

      const taskIds = tasks.map((t) => t.id);
      const taskMap = Object.fromEntries(tasks.map((t) => [t.id, t]));

      const { data } = await supabase
        .from("task_submissions")
        .select("*")
        .in("task_id", taskIds)
        .order("created_at", { ascending: false });

      return (data || []).map((sub) => ({
        ...sub,
        task: taskMap[sub.task_id],
      }));
    },
    enabled: !!client,
  });

  const approveSubmission = useMutation({
    mutationFn: async (submission: any) => {
      const rewardAmount = submission.task.reward_per_user;

      // Update submission
      const { error: subError } = await supabase
        .from("task_submissions")
        .update({
          status: "approved",
          reward_amount: rewardAmount,
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", submission.id);

      if (subError) throw subError;

      // Update task stats
      const { error: taskError } = await supabase
        .from("client_tasks")
        .update({
          approved_count: submission.task.approved_count + 1,
          remaining_budget: submission.task.remaining_budget - rewardAmount,
        })
        .eq("id", submission.task_id);

      if (taskError) throw taskError;

      // Credit user balance
      const { data: userProfile } = await supabase
        .from("profiles")
        .select("balance")
        .eq("user_id", submission.user_id)
        .single();

      if (userProfile) {
        await supabase
          .from("profiles")
          .update({ balance: userProfile.balance + rewardAmount })
          .eq("user_id", submission.user_id);

        // Create transaction for user
        await supabase.from("transactions").insert({
          user_id: submission.user_id,
          type: "earning",
          amount: rewardAmount,
          status: "completed",
          description: `Task reward: ${submission.task.title}`,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-submissions"] });
      queryClient.invalidateQueries({ queryKey: ["client-tasks"] });
      refreshWallet();
      toast.success("Submission approved and reward sent!");
    },
    onError: () => {
      toast.error("Failed to approve submission");
    },
  });

  const rejectSubmission = useMutation({
    mutationFn: async ({ submission, reason }: { submission: any; reason: string }) => {
      const { error } = await supabase
        .from("task_submissions")
        .update({
          status: "rejected",
          rejection_reason: reason,
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", submission.id);

      if (error) throw error;

      // Update task stats
      await supabase
        .from("client_tasks")
        .update({
          rejected_count: submission.task.rejected_count + 1,
        })
        .eq("id", submission.task_id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-submissions"] });
      queryClient.invalidateQueries({ queryKey: ["client-tasks"] });
      setRejectDialogOpen(false);
      setRejectionReason("");
      setSelectedSubmission(null);
      toast.success("Submission rejected");
    },
    onError: () => {
      toast.error("Failed to reject submission");
    },
  });

  const filterSubmissions = (status: string) => {
    if (status === "all") return submissions;
    return submissions?.filter((s) => s.status === status);
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: "bg-yellow-500/20 text-yellow-600",
      approved: "bg-green-500/20 text-green-600",
      rejected: "bg-red-500/20 text-red-600",
    };
    return <Badge className={styles[status as keyof typeof styles]}>{status}</Badge>;
  };

  const handleReject = () => {
    if (selectedSubmission && rejectionReason.trim()) {
      rejectSubmission.mutate({
        submission: selectedSubmission,
        reason: rejectionReason.trim(),
      });
    }
  };

  const SubmissionCard = ({ submission }: { submission: any }) => (
    <Card>
      <CardContent className="pt-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <h3 className="font-semibold">{submission.task?.title}</h3>
            <p className="text-sm text-muted-foreground">
              {format(new Date(submission.created_at), "MMM d, yyyy h:mm a")}
            </p>
          </div>
          {getStatusBadge(submission.status)}
        </div>

        <div className="mt-3 p-3 rounded-lg bg-muted">
          <Label className="text-xs text-muted-foreground">Proof Submitted:</Label>
          <p className="mt-1 text-sm break-words">{submission.proof_content}</p>
          {submission.proof_image_url && (
            <a
              href={submission.proof_image_url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center gap-1 text-sm text-primary hover:underline"
            >
              <Image className="h-4 w-4" />
              View Image
            </a>
          )}
        </div>

        {submission.status === "rejected" && submission.rejection_reason && (
          <div className="mt-2 p-2 rounded bg-destructive/10 text-sm">
            <span className="text-destructive font-medium">Rejection reason: </span>
            {submission.rejection_reason}
          </div>
        )}

        {submission.status === "pending" && (
          <div className="mt-4 flex gap-2">
            <Button
              size="sm"
              onClick={() => approveSubmission.mutate(submission)}
              disabled={approveSubmission.isPending}
            >
              <Check className="mr-1 h-4 w-4" />
              Approve
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => {
                setSelectedSubmission(submission);
                setRejectDialogOpen(true);
              }}
            >
              <X className="mr-1 h-4 w-4" />
              Reject
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <ClientLayout>
      <div className="container p-4 space-y-4">
        <h1 className="text-2xl font-bold">Submissions</h1>

        <Tabs defaultValue="pending">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending">
              Pending ({submissions?.filter((s) => s.status === "pending").length || 0})
            </TabsTrigger>
            <TabsTrigger value="approved">Approved</TabsTrigger>
            <TabsTrigger value="rejected">Rejected</TabsTrigger>
            <TabsTrigger value="all">All</TabsTrigger>
          </TabsList>

          {["pending", "approved", "rejected", "all"].map((status) => (
            <TabsContent key={status} value={status} className="space-y-4 mt-4">
              {isLoading ? (
                <p className="text-center text-muted-foreground py-8">Loading...</p>
              ) : filterSubmissions(status)?.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No submissions found</p>
              ) : (
                filterSubmissions(status)?.map((sub) => (
                  <SubmissionCard key={sub.id} submission={sub} />
                ))
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* Rejection Dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Submission</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Reason for Rejection *</Label>
              <Textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Explain why this submission is being rejected..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={!rejectionReason.trim() || rejectSubmission.isPending}
            >
              Reject Submission
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ClientLayout>
  );
}
