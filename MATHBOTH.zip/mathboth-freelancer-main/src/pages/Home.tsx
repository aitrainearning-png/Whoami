import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { Skeleton } from "@/components/ui/skeleton";
import { WelcomeHeader } from "@/components/home/WelcomeHeader";
import { QuickActionGrid } from "@/components/home/QuickActionGrid";
import { WalletOverview } from "@/components/home/WalletOverview";
import { ActivitySnapshot } from "@/components/home/ActivitySnapshot";
import { DailyChallengeCard } from "@/components/home/DailyChallengeCard";

export default function Home() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile, isLoading } = useProfile();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background px-4 pt-6 space-y-5">
        <Skeleton className="h-20 w-full rounded-2xl" />
        <Skeleton className="h-36 w-full rounded-2xl" />
        <div className="grid grid-cols-2 gap-3">
          <Skeleton className="h-20 w-full rounded-2xl" />
          <Skeleton className="h-20 w-full rounded-2xl" />
        </div>
        <Skeleton className="h-28 w-full rounded-2xl" />
      </div>
    );
  }

  const isPremium = !!profile?.premium_tier;
  const displayName = profile?.display_name || user?.email?.split("@")[0] || "User";

  return (
    <div className="min-h-screen bg-background">
      {/* Compact greeting */}
      <WelcomeHeader
        displayName={displayName}
        premiumTier={profile?.premium_tier || null}
        premiumExpiresAt={profile?.premium_expires_at || null}
      />

      {/* Body */}
      <div className="px-4 space-y-4 pb-6">
        {/* Wallet card */}
        <WalletOverview
          balance={profile?.balance || 0}
          totalEarned={profile?.total_earned || 0}
          onWithdraw={() => navigate("/wallet")}
          onDeposit={() => navigate("/premium")}
        />

        {/* Quick actions */}
        <QuickActionGrid />

        {/* Stats row */}
        <ActivitySnapshot
          gamesPlayed={profile?.games_played || 0}
          referrals={profile?.referral_count || 0}
          energy={profile?.energy || 0}
          maxEnergy={profile?.max_energy || 100}
        />

        {/* Daily challenge */}
        <div>
          <h2 className="text-base font-semibold text-foreground mb-2">Daily Challenge</h2>
          <DailyChallengeCard
            title="Quick Math Sprint"
            description="Complete 5 Quick Math games"
            progress={0}
            target={5}
            reward={2.5}
            timeRemaining="23h 59m left"
            isCompleted={false}
            onStart={() => navigate("/games")}
          />
        </div>
      </div>
    </div>
  );
}
