import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Users, 
  Wallet, 
  Crown, 
  LogOut,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Briefcase
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ChatControlSection } from "@/components/admin/ChatControlSection";
import { AnnouncementSection } from "@/components/admin/AnnouncementSection";
import { ActiveUsersSection } from "@/components/admin/ActiveUsersSection";
import { NewSignupsSection } from "@/components/admin/NewSignupsSection";
import { ClientManagementSection } from "@/components/admin/ClientManagementSection";
import { DepositManagementSection } from "@/components/admin/DepositManagementSection";
import { ConversationListSection } from "@/components/admin/ConversationListSection";
import { UserSearchSection } from "@/components/admin/UserSearchSection";

export default function Admin() {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const queryClient = useQueryClient();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [selectedTiers, setSelectedTiers] = useState<Record<string, string>>({});

  // Check if user is admin
  useEffect(() => {
    async function checkAdmin() {
      if (!user) {
        setIsAdmin(false);
        return;
      }

      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      setIsAdmin(!!data);
    }
    checkAdmin();
  }, [user]);

  // Fetch pending withdrawals
  const { data: withdrawals, isLoading: withdrawalsLoading } = useQuery({
    queryKey: ["admin", "withdrawals"],
    queryFn: async () => {
      const { data: txs, error } = await supabase
        .from("transactions")
        .select("*")
        .eq("type", "withdrawal")
        .eq("status", "pending")
        .order("created_at", { ascending: true });

      if (error) throw error;
      if (!txs || txs.length === 0) return [];

      const userIds = [...new Set(txs.map(t => t.user_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, display_name, email")
        .in("user_id", userIds);

      const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);

      return txs.map(tx => ({
        ...tx,
        profile: profileMap.get(tx.user_id) || null,
      }));
    },
    enabled: isAdmin === true,
  });

  // Fetch pending premium orders
  const { data: premiumOrders, isLoading: ordersLoading } = useQuery({
    queryKey: ["admin", "premium-orders"],
    queryFn: async () => {
      const { data: orders, error } = await supabase
        .from("premium_orders")
        .select("*")
        .eq("status", "pending")
        .order("created_at", { ascending: true });

      if (error) throw error;
      if (!orders || orders.length === 0) return [];

      // Fetch profiles for all user_ids
      const userIds = [...new Set(orders.map(o => o.user_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, display_name, email")
        .in("user_id", userIds);

      const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);

      return orders.map(order => ({
        ...order,
        profile: profileMap.get(order.user_id) || null,
      }));
    },
    enabled: isAdmin === true,
  });

  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: ["admin", "stats"],
    queryFn: async () => {
      const [usersCount, pendingWithdrawals, pendingDeposits, pendingPremium, clientsCount, pendingClients] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("transactions").select("id", { count: "exact", head: true }).eq("type", "withdrawal").eq("status", "pending"),
        supabase.from("transactions").select("id", { count: "exact", head: true }).eq("type", "deposit").eq("status", "pending"),
        supabase.from("premium_orders").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("clients").select("id", { count: "exact", head: true }),
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("status", "pending"),
      ]);

      return {
        totalUsers: usersCount.count || 0,
        pendingWithdrawals: pendingWithdrawals.count || 0,
        pendingDeposits: pendingDeposits.count || 0,
        pendingPremium: pendingPremium.count || 0,
        totalClients: clientsCount.count || 0,
        pendingClients: pendingClients.count || 0,
      };
    },
    enabled: isAdmin === true,
  });

  // Approve/Reject withdrawal
  const withdrawalMutation = useMutation({
    mutationFn: async ({ id, action, userId, amount }: { id: string; action: "approve" | "reject"; userId: string; amount: number }) => {
      const status = action === "approve" ? "approved" : "rejected";
      
      const { error: txError } = await supabase
        .from("transactions")
        .update({ 
          status, 
          processed_at: new Date().toISOString(),
          processed_by: user?.id 
        })
        .eq("id", id);

      if (txError) throw txError;

      // If approved, deduct from user balance
      if (action === "approve") {
        const { data: profile } = await supabase
          .from("profiles")
          .select("balance")
          .eq("user_id", userId)
          .single();
        
        if (profile) {
          await supabase
            .from("profiles")
            .update({ 
              balance: Math.max(0, profile.balance - amount),
              first_withdrawal_done: true,
              last_withdrawal_at: new Date().toISOString()
            })
            .eq("user_id", userId);
        }
      }
    },
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey: ["admin", "withdrawals"] });
      const previous = queryClient.getQueryData(["admin", "withdrawals"]);
      queryClient.setQueryData(["admin", "withdrawals"], (old: any[]) =>
        old?.filter((tx: any) => tx.id !== id) || []
      );
      return { previous };
    },
    onSuccess: (_, { action }) => {
      queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
      toast.success(`Withdrawal ${action === "approve" ? "approved" : "rejected"}!`);
    },
    onError: (error, _, context) => {
      queryClient.setQueryData(["admin", "withdrawals"], context?.previous);
      toast.error(error.message);
    },
  });

  // Approve/Reject premium order
  const premiumMutation = useMutation({
    mutationFn: async ({ id, action, userId, tier, amount, rejectionReason }: { id: string; action: "approve" | "reject"; userId: string; tier: string; amount: number; rejectionReason?: string }) => {
      const status = action === "approve" ? "approved" : "rejected";
      
      const updateData: any = { 
        status, 
        processed_at: new Date().toISOString(),
        processed_by: user?.id 
      };
      if (action === "reject" && rejectionReason) {
        updateData.rejection_reason = rejectionReason;
      }

      const { error: orderError } = await supabase
        .from("premium_orders")
        .update(updateData)
        .eq("id", id);

      if (orderError) throw orderError;

      // If approved, update user's premium tier and create transaction record
      if (action === "approve") {
        // Fetch tier settings to get duration_days
        const { data: tierSettings, error: tierError } = await supabase
          .from("tier_settings")
          .select("duration_days")
          .eq("tier", tier as "basic" | "advance" | "pro")
          .single();

        if (tierError) {
          console.error("Failed to fetch tier settings:", tierError);
          throw new Error("Failed to fetch tier settings");
        }

        // Calculate expiration date based on duration_days
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + (tierSettings?.duration_days || 30));

        // Update user's premium tier with calculated expiration (keep existing balance)
        const { error: profileError } = await supabase
          .from("profiles")
          .update({ 
            premium_tier: tier as "basic" | "advance" | "pro",
            premium_expires_at: expiresAt.toISOString(),
          })
          .eq("user_id", userId);

        if (profileError) {
          console.error("Failed to reset balance:", profileError);
          throw new Error("Failed to update user profile and reset balance");
        }

        // Create a bonus transaction for the premium purchase to show in wallet history
        const tierName = tier.charAt(0).toUpperCase() + tier.slice(1);
        await supabase
          .from("transactions")
          .insert({
            user_id: userId,
            type: "bonus",
            amount: amount,
            status: "completed",
            description: `${tierName} Premium Plan Activated (${tierSettings?.duration_days || 30} days)`,
          });
      }
    },
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey: ["admin", "premium-orders"] });
      const previous = queryClient.getQueryData(["admin", "premium-orders"]);
      queryClient.setQueryData(["admin", "premium-orders"], (old: any[]) =>
        old?.filter((order: any) => order.id !== id) || []
      );
      return { previous };
    },
    onSuccess: (_, { action }) => {
      queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success(`Premium order ${action === "approve" ? "approved" : "rejected"}!`);
    },
    onError: (error, _, context) => {
      queryClient.setQueryData(["admin", "premium-orders"], context?.previous);
      toast.error(error.message);
    },
  });

  const handleLogout = async () => {
    await signOut();
    navigate("/login");
  };

  // Loading state
  if (isAdmin === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  // Not admin
  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-soft">
          <CardContent className="p-8 text-center">
            <AlertTriangle className="w-16 h-16 mx-auto text-destructive mb-4" />
            <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
            <p className="text-muted-foreground mb-6">
              You don't have permission to access the admin panel.
            </p>
            <Button onClick={() => navigate("/")} className="w-full">
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Admin Panel</h1>
            <p className="text-primary-foreground/80 text-sm">Manage MathBot</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            className="text-primary-foreground hover:bg-white/10"
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </header>

      {/* Stats */}
      <div className="px-4 -mt-4">
        <div className="grid grid-cols-4 gap-2">
          <Card className="border-0 shadow-soft">
            <CardContent className="p-3 text-center">
              <Users className="w-5 h-5 mx-auto text-primary mb-1" />
              <p className="text-xl font-bold">{stats?.totalUsers || 0}</p>
              <p className="text-xs text-muted-foreground">Users</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-soft">
            <CardContent className="p-3 text-center">
              <Briefcase className="w-5 h-5 mx-auto text-blue-500 mb-1" />
              <p className="text-xl font-bold">{stats?.totalClients || 0}</p>
              <p className="text-xs text-muted-foreground">Clients</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-soft">
            <CardContent className="p-3 text-center">
              <Wallet className="w-5 h-5 mx-auto text-gold mb-1" />
              <p className="text-xl font-bold">{stats?.pendingWithdrawals || 0}</p>
              <p className="text-xs text-muted-foreground">Withdraw</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-soft">
            <CardContent className="p-3 text-center">
              <Crown className="w-5 h-5 mx-auto text-accent mb-1" />
              <p className="text-xl font-bold">{stats?.pendingPremium || 0}</p>
              <p className="text-xs text-muted-foreground">Premium</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* User Search */}
      <div className="px-4 py-2">
        <UserSearchSection />
      </div>

      {/* Active Users Today */}
      <div className="px-4 py-2">
        <ActiveUsersSection />
      </div>

      {/* New Signups Today */}
      <div className="px-4 py-2">
        <NewSignupsSection />
      </div>

      {/* Chat Control */}
      <div className="px-4 py-2">
        <ChatControlSection />
      </div>

      {/* Announcement Section */}
      <div className="px-4 py-2">
        <AnnouncementSection />
      </div>

      {/* Conversations */}
      <div className="px-4 py-2">
        <ConversationListSection />
      </div>

      {/* Tabs */}
      <div className="px-4 py-4">
        <Tabs defaultValue="deposits">
          <TabsList className="w-full grid grid-cols-4">
            <TabsTrigger value="deposits">Deposits</TabsTrigger>
            <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
            <TabsTrigger value="premium">Premium</TabsTrigger>
            <TabsTrigger value="clients">Clients</TabsTrigger>
          </TabsList>

          <TabsContent value="deposits" className="mt-4">
            <DepositManagementSection />
          </TabsContent>

          <TabsContent value="withdrawals" className="mt-4 space-y-3">
            {withdrawalsLoading ? (
              <>
                <Skeleton className="h-24 w-full rounded-xl" />
                <Skeleton className="h-24 w-full rounded-xl" />
              </>
            ) : withdrawals?.length === 0 ? (
              <Card className="border-0 shadow-soft">
                <CardContent className="p-8 text-center">
                  <CheckCircle2 className="w-12 h-12 mx-auto text-success mb-3" />
                  <p className="text-muted-foreground">No pending withdrawals</p>
                </CardContent>
              </Card>
            ) : (
              withdrawals?.map((tx: any) => (
                <Card key={tx.id} className="border-0 shadow-soft">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-semibold text-foreground">
                          {tx.profile?.display_name || tx.profile?.email || 'Unknown'}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {tx.payment_method}: {tx.payment_details}
                        </p>
                      </div>
                      <p className="text-xl font-bold text-foreground">₱{Number(tx.amount).toFixed(2)}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => withdrawalMutation.mutate({ 
                          id: tx.id, 
                          action: "reject",
                          userId: tx.user_id,
                          amount: Number(tx.amount)
                        })}
                        disabled={withdrawalMutation.isPending}
                        className="flex-1 border-destructive text-destructive hover:bg-destructive/10"
                      >
                        <XCircle className="w-4 h-4 mr-1" />
                        Reject
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => withdrawalMutation.mutate({ 
                          id: tx.id, 
                          action: "approve",
                          userId: tx.user_id,
                          amount: Number(tx.amount)
                        })}
                        disabled={withdrawalMutation.isPending}
                        className="flex-1 bg-success hover:bg-success/90"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-1" />
                        Approve
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="premium" className="mt-4 space-y-3">
            {ordersLoading ? (
              <>
                <Skeleton className="h-24 w-full rounded-xl" />
                <Skeleton className="h-24 w-full rounded-xl" />
              </>
            ) : premiumOrders?.length === 0 ? (
              <Card className="border-0 shadow-soft">
                <CardContent className="p-8 text-center">
                  <CheckCircle2 className="w-12 h-12 mx-auto text-success mb-3" />
                  <p className="text-muted-foreground">No pending premium orders</p>
                </CardContent>
              </Card>
            ) : (
              premiumOrders?.map((order: any) => {
                const effectiveTier = selectedTiers[order.id] || order.tier;
                return (
                  <Card key={order.id} className="border-0 shadow-soft">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="font-semibold text-foreground">
                            {order.profile?.display_name || order.profile?.email || 'Unknown'}
                          </p>
                          <p className="text-xs text-muted-foreground">{order.profile?.email}</p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Crown className="w-4 h-4 text-gold" />
                            <span className="capitalize">Requested: {order.tier}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Ref: {order.payment_reference || "N/A"}
                          </p>
                        </div>
                        <p className="text-xl font-bold text-foreground">₱{Number(order.amount).toFixed(2)}</p>
                      </div>
                      <div className="mb-3">
                        <label className="text-xs font-medium text-muted-foreground mb-1 block">Assign Tier</label>
                        <Select
                          value={effectiveTier}
                          onValueChange={(val) => setSelectedTiers(prev => ({ ...prev, [order.id]: val }))}
                        >
                          <SelectTrigger className="h-9">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="basic">Basic</SelectItem>
                            <SelectItem value="advance">Advance</SelectItem>
                            <SelectItem value="pro">Pro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => premiumMutation.mutate({ 
                            id: order.id, 
                            action: "reject",
                            userId: order.user_id,
                            tier: effectiveTier,
                            amount: Number(order.amount),
                            rejectionReason: "Not properly paying a plan"
                          })}
                          disabled={premiumMutation.isPending}
                          className="flex-1 border-destructive text-destructive hover:bg-destructive/10"
                        >
                          <XCircle className="w-4 h-4 mr-1" />
                          Reject
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => premiumMutation.mutate({ 
                            id: order.id, 
                            action: "approve",
                            userId: order.user_id,
                            tier: effectiveTier,
                            amount: Number(order.amount)
                          })}
                          disabled={premiumMutation.isPending}
                          className="flex-1 bg-success hover:bg-success/90"
                        >
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Approve as {effectiveTier.charAt(0).toUpperCase() + effectiveTier.slice(1)}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </TabsContent>

          <TabsContent value="clients" className="mt-4">
            <ClientManagementSection />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
