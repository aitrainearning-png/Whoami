import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Coins, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

// Sound utility using Web Audio API
function playSound(type: "tick" | "coin" | "win" | "lose" | "bet") {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    switch (type) {
      case "tick":
        osc.frequency.value = 800;
        gain.gain.value = 0.1;
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
        break;
      case "bet":
        osc.frequency.value = 500;
        gain.gain.value = 0.15;
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
        break;
      case "coin":
        osc.type = "triangle";
        osc.frequency.value = 1200;
        gain.gain.value = 0.2;
        osc.start();
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
        osc.stop(ctx.currentTime + 0.5);
        break;
      case "win":
        osc.type = "sine";
        osc.frequency.value = 523;
        gain.gain.value = 0.2;
        osc.start();
        setTimeout(() => {
          const o2 = ctx.createOscillator();
          const g2 = ctx.createGain();
          o2.connect(g2);
          g2.connect(ctx.destination);
          o2.type = "sine";
          o2.frequency.value = 659;
          g2.gain.value = 0.2;
          o2.start();
          setTimeout(() => {
            const o3 = ctx.createOscillator();
            const g3 = ctx.createGain();
            o3.connect(g3);
            g3.connect(ctx.destination);
            o3.type = "sine";
            o3.frequency.value = 784;
            g3.gain.value = 0.2;
            o3.start();
            o3.stop(ctx.currentTime + 0.3);
          }, 150);
          o2.stop(ctx.currentTime + 0.15);
        }, 150);
        osc.stop(ctx.currentTime + 0.15);
        break;
      case "lose":
        osc.type = "sawtooth";
        osc.frequency.value = 200;
        gain.gain.value = 0.15;
        osc.start();
        osc.frequency.linearRampToValueAtTime(100, ctx.currentTime + 0.4);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
        osc.stop(ctx.currentTime + 0.5);
        break;
    }
  } catch {
    // Audio not supported
  }
}

const MIN_BET = 5;
const BET_PRESETS = [5, 10, 40, 50, 100, 200, 500];

export default function CoinToss() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();

  const [betAmount, setBetAmount] = useState<string>("5");
  const [choice, setChoice] = useState<"odd" | "even" | null>(null);
  const [gameState, setGameState] = useState<"betting" | "countdown" | "flipping" | "result">("betting");
  const [timeLeft, setTimeLeft] = useState(3);
  const [result, setResult] = useState<{ number: number; isOdd: boolean; won: boolean } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastTickRef = useRef(3);

  const balance = profile?.balance ?? 0;
  const betNum = parseFloat(betAmount) || 0;
  const canBet = choice !== null && betNum >= MIN_BET && betNum <= balance;

  // Countdown timer
  useEffect(() => {
    if (gameState !== "countdown") return;

    lastTickRef.current = 3;
    setTimeLeft(3);

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        const next = prev - 1;
        if (next !== lastTickRef.current) {
          lastTickRef.current = next;
          if (next > 0 && next <= 5) playSound("tick");
        }
        if (next <= 0) {
          clearInterval(timerRef.current!);
          executeToss();
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState]);

  const executeToss = useCallback(async () => {
    setGameState("flipping");
    playSound("coin");

    // 60% win / 40% loss
    const rand = Math.random();
    const playerWins = rand < 0.6;

    // Generate a number that matches the outcome
    let coinNumber: number;
    if (playerWins) {
      // User wins: number matches their choice
      if (choice === "odd") {
        coinNumber = Math.floor(Math.random() * 50) * 2 + 1; // odd 1-99
      } else {
        coinNumber = Math.floor(Math.random() * 50) * 2; // even 0-98
        if (coinNumber === 0) coinNumber = 2;
      }
    } else {
      // User loses: number is opposite
      if (choice === "odd") {
        coinNumber = Math.floor(Math.random() * 50) * 2; // even
        if (coinNumber === 0) coinNumber = 2;
      } else {
        coinNumber = Math.floor(Math.random() * 50) * 2 + 1; // odd
      }
    }

    const isOdd = coinNumber % 2 !== 0;

    // Delay for animation
    await new Promise((r) => setTimeout(r, 1500));

    const won = playerWins;
    setResult({ number: coinNumber, isOdd, won });
    setGameState("result");

    if (won) {
      playSound("win");
    } else {
      playSound("lose");
    }

    // Process in database
    await processResult(won);
  }, [choice, betAmount]);

  const processResult = async (won: boolean) => {
    if (!user || isProcessing) return;
    setIsProcessing(true);

    try {
      const amount = parseFloat(betAmount);

      if (won) {
        // Credit winnings (double the bet)
        const winnings = amount; // net gain = bet amount (they keep their bet + win same amount)
        const { error } = await supabase
          .from("profiles")
          .update({ balance: balance + winnings })
          .eq("user_id", user.id);

        if (error) throw error;

        // Record transaction
        await supabase.from("transactions").insert({
          user_id: user.id,
          type: "earning",
          amount: winnings,
          status: "completed",
          description: `Coin Toss win - doubled ₱${amount.toFixed(2)}`,
        });

        toast.success(`You won ₱${winnings.toFixed(2)}!`);
      } else {
        // Deduct bet
        const { error } = await supabase
          .from("profiles")
          .update({ balance: balance - amount })
          .eq("user_id", user.id);

        if (error) throw error;

        // Record transaction
        await supabase.from("transactions").insert({
          user_id: user.id,
          type: "earning",
          amount: -amount,
          status: "completed",
          description: `Coin Toss loss - ₱${amount.toFixed(2)}`,
        });
      }

      queryClient.invalidateQueries({ queryKey: ["profile"] });
    } catch (err) {
      console.error("Failed to process result:", err);
      toast.error("Failed to process result");
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePlaceBet = () => {
    if (!canBet) return;
    playSound("bet");
    setGameState("countdown");
  };

  const handlePlayAgain = () => {
    setGameState("betting");
    setChoice(null);
    setResult(null);
    setTimeLeft(3);
  };

  const handleExit = () => navigate("/games");

  const adjustBet = (delta: number) => {
    const current = parseFloat(betAmount) || 0;
    const next = Math.max(MIN_BET, Math.min(balance, current + delta));
    setBetAmount(String(next));
    playSound("tick");
  };

  // Not enough balance
  if (balance < MIN_BET && gameState === "betting") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="border-0 shadow-soft max-w-sm w-full">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h2 className="text-lg font-bold text-foreground mb-2">Insufficient Balance</h2>
            <p className="text-muted-foreground mb-4">
              Minimum bet is ₱{MIN_BET.toFixed(2)}. Your balance: ₱{balance.toFixed(2)}
            </p>
            <Button onClick={handleExit} className="w-full">Go Back</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-4 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={handleExit} className="text-primary-foreground hover:bg-white/10">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">🪙 Toss a Coin</h1>
            <p className="text-primary-foreground/80 text-sm">Odd or Even • Double your bet!</p>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2">
          <Coins className="w-4 h-4 text-primary-foreground" />
          <span className="text-primary-foreground font-semibold">Balance: ₱{balance.toFixed(2)}</span>
        </div>
      </header>

      <div className="px-4 py-6 space-y-5">
        {/* BETTING PHASE */}
        {gameState === "betting" && (
          <>
            {/* Choose Odd or Even */}
            <Card className="border-0 shadow-soft">
              <CardContent className="p-5">
                <h3 className="font-semibold text-foreground mb-3 text-center">Pick your side</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant={choice === "odd" ? "default" : "outline"}
                    className={cn("h-16 text-lg font-bold", choice === "odd" && "bg-primary ring-2 ring-primary")}
                    onClick={() => { setChoice("odd"); playSound("tick"); }}
                  >
                    🔵 ODD
                  </Button>
                  <Button
                    variant={choice === "even" ? "default" : "outline"}
                    className={cn("h-16 text-lg font-bold", choice === "even" && "bg-primary ring-2 ring-primary")}
                    onClick={() => { setChoice("even"); playSound("tick"); }}
                  >
                    🔴 EVEN
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Bet Amount */}
            <Card className="border-0 shadow-soft">
              <CardContent className="p-5">
                <h3 className="font-semibold text-foreground mb-3">Bet Amount (min ₱{MIN_BET})</h3>
                <div className="flex items-center gap-2 mb-3">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-14 w-14 text-xl font-bold shrink-0"
                    onClick={() => adjustBet(-5)}
                    disabled={betNum <= MIN_BET}
                  >
                    −
                  </Button>
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min={MIN_BET}
                    max={balance}
                    className="text-center text-xl font-bold h-14"
                    placeholder="Enter bet"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-14 w-14 text-xl font-bold shrink-0"
                    onClick={() => adjustBet(5)}
                    disabled={betNum >= balance}
                  >
                    +
                  </Button>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {BET_PRESETS.filter(b => b <= balance).slice(0, 4).map((amt) => (
                    <Button
                      key={amt}
                      variant="outline"
                      size="sm"
                      onClick={() => { setBetAmount(String(amt)); playSound("tick"); }}
                      className={cn("text-xs font-medium", betNum === amt && "border-primary bg-primary/10")}
                    >
                      ₱{amt}
                    </Button>
                  ))}
                </div>
                {BET_PRESETS.filter(b => b <= balance).length > 4 && (
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {BET_PRESETS.filter(b => b <= balance).slice(4).map((amt) => (
                      <Button
                        key={amt}
                        variant="outline"
                        size="sm"
                        onClick={() => { setBetAmount(String(amt)); playSound("tick"); }}
                        className={cn("text-xs font-medium", betNum === amt && "border-primary bg-primary/10")}
                      >
                        ₱{amt}
                      </Button>
                    ))}
                  </div>
                )}
                {balance >= MIN_BET && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full mt-2 text-xs text-muted-foreground"
                    onClick={() => { setBetAmount(String(Math.floor(balance))); playSound("tick"); }}
                  >
                    All In (₱{Math.floor(balance).toFixed(2)})
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Potential Win */}
            {canBet && (
              <div className="bg-success/10 border border-success/20 rounded-xl p-4 text-center">
                <p className="text-sm text-muted-foreground">If you win:</p>
                <p className="text-2xl font-bold text-success">+₱{betNum.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground">60% chance to win</p>
              </div>
            )}

            {/* Place Bet Button */}
            <Button
              onClick={handlePlaceBet}
              disabled={!canBet}
              className="w-full h-14 text-lg font-bold bg-gradient-primary hover:opacity-90"
            >
              {!choice ? "Pick Odd or Even" : betNum < MIN_BET ? `Min bet ₱${MIN_BET}` : betNum > balance ? "Insufficient balance" : `Place Bet ₱${betNum.toFixed(2)}`}
            </Button>
          </>
        )}

        {/* COUNTDOWN PHASE */}
        {gameState === "countdown" && (
          <Card className="border-0 shadow-soft">
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground mb-2">You chose <strong className="text-foreground">{choice?.toUpperCase()}</strong></p>
              <p className="text-muted-foreground mb-1">Betting <strong className="text-foreground">₱{betNum.toFixed(2)}</strong></p>
              <div className="my-8">
                <div className={cn(
                  "text-7xl font-bold tabular-nums transition-all",
                  timeLeft <= 3 ? "text-destructive animate-pulse" : timeLeft <= 5 ? "text-gold" : "text-primary"
                )}>
                  {timeLeft}
                </div>
                <p className="text-sm text-muted-foreground mt-2">Tossing coin in...</p>
              </div>
              {/* Timer bar */}
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full transition-all duration-1000 ease-linear rounded-full",
                    timeLeft <= 3 ? "bg-destructive" : timeLeft <= 5 ? "bg-gold" : "bg-primary"
                  )}
                  style={{ width: `${(timeLeft / 3) * 100}%` }}
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* FLIPPING PHASE */}
        {gameState === "flipping" && (
          <Card className="border-0 shadow-soft">
            <CardContent className="p-12 text-center">
              <div className="text-8xl animate-spin mb-4">🪙</div>
              <p className="text-lg font-semibold text-muted-foreground">Flipping...</p>
            </CardContent>
          </Card>
        )}

        {/* RESULT PHASE */}
        {gameState === "result" && result && (
          <div className="space-y-4 animate-fade-in">
            <Card className={cn(
              "border-0 shadow-soft",
              result.won ? "ring-2 ring-success" : "ring-2 ring-destructive"
            )}>
              <CardContent className="p-8 text-center">
                <div className={cn(
                  "w-24 h-24 mx-auto mb-4 rounded-full flex items-center justify-center text-4xl font-bold",
                  result.won ? "bg-success/10" : "bg-destructive/10"
                )}>
                  {result.number}
                </div>

                <p className="text-lg mb-1">
                  The number is <strong className={result.isOdd ? "text-blue-500" : "text-red-500"}>
                    {result.isOdd ? "ODD" : "EVEN"}
                  </strong>
                </p>

                <h2 className={cn(
                  "text-3xl font-bold mb-2",
                  result.won ? "text-success" : "text-destructive"
                )}>
                  {result.won ? "🎉 YOU WIN!" : "😔 YOU LOSE"}
                </h2>

                <p className={cn(
                  "text-2xl font-bold",
                  result.won ? "text-success" : "text-destructive"
                )}>
                  {result.won ? `+₱${betNum.toFixed(2)}` : `-₱${betNum.toFixed(2)}`}
                </p>
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button variant="outline" onClick={handleExit} className="flex-1">Exit</Button>
              <Button onClick={handlePlayAgain} className="flex-1 bg-gradient-primary hover:opacity-90">
                Play Again
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
