import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Zap, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GameTimer } from "@/components/games/GameTimer";
import { GameResult } from "@/components/games/GameResult";
import { cn } from "@/lib/utils";
import { useStartGameSession, useCompleteGameSession, getRewardWithBonus, getEffectiveEnergyCost } from "@/hooks/useGameSession";
import { useProfile, calculateCurrentEnergy } from "@/hooks/useProfile";

const GAME_ID = "quick-math";
const BASE_ENERGY_COST = 10;

interface Problem {
  question: string;
  answer: number;
  options: number[];
}

function generateProblem(difficulty: number): Problem {
  const operations = ['+', '-', '×'];
  const operation = operations[Math.floor(Math.random() * operations.length)];
  
  let a: number, b: number, answer: number;
  const maxNum = 10 + difficulty * 5;
  
  switch (operation) {
    case '+':
      a = Math.floor(Math.random() * maxNum) + 1;
      b = Math.floor(Math.random() * maxNum) + 1;
      answer = a + b;
      break;
    case '-':
      a = Math.floor(Math.random() * maxNum) + 10;
      b = Math.floor(Math.random() * Math.min(a, maxNum)) + 1;
      answer = a - b;
      break;
    case '×':
      a = Math.floor(Math.random() * 12) + 1;
      b = Math.floor(Math.random() * 12) + 1;
      answer = a * b;
      break;
    default:
      a = 1; b = 1; answer = 2;
  }
  
  // Generate wrong options
  const options = new Set<number>([answer]);
  while (options.size < 4) {
    const offset = Math.floor(Math.random() * 10) - 5;
    const wrongAnswer = answer + offset;
    if (wrongAnswer > 0 && wrongAnswer !== answer) {
      options.add(wrongAnswer);
    }
  }
  
  return {
    question: `${a} ${operation} ${b} = ?`,
    answer,
    options: Array.from(options).sort(() => Math.random() - 0.5),
  };
}

export default function QuickMath() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const startSession = useStartGameSession();
  const completeSession = useCompleteGameSession();
  const startTimeRef = useRef<Date>(new Date());
  const hasCompletedRef = useRef(false);
  const sessionIdRef = useRef<string>("");
  
  const [gameState, setGameState] = useState<'init' | 'playing' | 'ended'>('init');
  const [problem, setProblem] = useState<Problem>(() => generateProblem(1));
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [difficulty, setDifficulty] = useState(1);
  const [isSuccess, setIsSuccess] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  
  const GAME_DURATION = 30;
  const REQUIRED_SCORE = 5;

  const effectiveEnergyCost = getEffectiveEnergyCost(BASE_ENERGY_COST, profile?.premium_tier || null);
  const currentEnergy = profile ? calculateCurrentEnergy(profile) : 0;
  const hasEnoughEnergy = currentEnergy >= effectiveEnergyCost;

  // Initialize game session on mount
  useEffect(() => {
    const initGame = async () => {
      if (!profile) return;
      
      try {
        const result = await startSession.mutateAsync({
          gameId: GAME_ID,
          energyCost: BASE_ENERGY_COST,
        });

        if (!result.canPlay) {
          setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
          return;
        }

        sessionIdRef.current = result.sessionId;
        startTimeRef.current = new Date();
        setGameState('playing');
      } catch (error) {
        setInitError("Failed to start game. Please try again.");
      }
    };

    if (profile && gameState === 'init' && !initError) {
      initGame();
    }
  }, [profile, gameState, initError]);

  // Calculate reward with premium bonus
  const calculateReward = useCallback((finalScore: number, success: boolean) => {
    if (!success) return 0;
    const baseReward = Math.min(0.10 + (finalScore * 0.04), 0.50);
    return baseReward; // Server will apply premium bonus
  }, []);

  const handleGameEnd = useCallback((finalScore: number, success: boolean) => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    
    const endTime = new Date();
    const timeTaken = Math.floor((endTime.getTime() - startTimeRef.current.getTime()) / 1000);
    const baseReward = calculateReward(finalScore, success);
    
    setIsSuccess(success);
    setGameState('ended');
    
    // Save to database and credit balance via edge function
    completeSession.mutate({
      sessionId: sessionIdRef.current,
      gameId: GAME_ID,
      score: finalScore,
      isSuccessful: success,
      baseReward,
      timeTakenSeconds: timeTaken,
    });
  }, [completeSession, calculateReward]);

  const handleTimeUp = useCallback(() => {
    handleGameEnd(score, score >= REQUIRED_SCORE);
  }, [score, handleGameEnd]);

  const handleAnswer = (answer: number) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answer);
    const correct = answer === problem.answer;
    setIsCorrect(correct);
    
    if (correct) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      setScore(prev => prev + 1);
      
      // Increase difficulty every 3 correct answers
      if (newStreak % 3 === 0) {
        setDifficulty(prev => Math.min(prev + 1, 5));
      }
    } else {
      setStreak(0);
    }
    
    // Move to next problem after brief delay
    setTimeout(() => {
      setSelectedAnswer(null);
      setIsCorrect(null);
      setProblem(generateProblem(difficulty));
    }, 500);
  };

  const handlePlayAgain = async () => {
    // Start new session
    try {
      const result = await startSession.mutateAsync({
        gameId: GAME_ID,
        energyCost: BASE_ENERGY_COST,
      });

      if (!result.canPlay) {
        setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
        return;
      }

      sessionIdRef.current = result.sessionId;
      startTimeRef.current = new Date();
      hasCompletedRef.current = false;
      setGameState('playing');
      setScore(0);
      setStreak(0);
      setDifficulty(1);
      setProblem(generateProblem(1));
      setSelectedAnswer(null);
      setIsCorrect(null);
      setIsSuccess(false);
    } catch {
      setInitError("Failed to start game. Please try again.");
    }
  };

  const handleExit = () => {
    navigate('/games');
  };

  // Calculate display reward with premium bonus
  const reward = getRewardWithBonus(calculateReward(score, isSuccess), profile?.premium_tier || null);

  // Show loading/error state
  if (gameState === 'init') {
    if (initError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <Card className="border-0 shadow-soft max-w-sm w-full">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-lg font-bold text-foreground mb-2">Cannot Play</h2>
              <p className="text-muted-foreground mb-4">{initError}</p>
              <Button onClick={handleExit} className="w-full">
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Starting game...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">Quick Math</h1>
            <p className="text-primary-foreground/80 text-sm">Solve {REQUIRED_SCORE} problems to win</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        {/* Timer & Stats */}
        <GameTimer 
          duration={GAME_DURATION} 
          onTimeUp={handleTimeUp}
          isRunning={gameState === 'playing'}
        />

        {/* Stats Bar */}
        <div className="flex items-center justify-between bg-card rounded-xl p-4 shadow-soft">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Score</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{streak}</p>
            <p className="text-xs text-muted-foreground">Streak</p>
          </div>
          <div className="text-center flex items-center gap-1">
            <Zap className="w-4 h-4 text-energy" fill="currentColor" />
            <p className="text-sm font-medium text-muted-foreground">{effectiveEnergyCost}</p>
          </div>
        </div>

        {/* Problem Card */}
        <Card className="border-0 shadow-soft">
          <CardContent className="p-8">
            <p className="text-4xl font-bold text-center text-foreground mb-8">
              {problem.question}
            </p>

            <div className="grid grid-cols-2 gap-3">
              {problem.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleAnswer(option)}
                  disabled={selectedAnswer !== null}
                  className={cn(
                    "h-16 text-xl font-bold transition-all",
                    selectedAnswer === option && isCorrect && "bg-success text-success-foreground border-success",
                    selectedAnswer === option && !isCorrect && "bg-destructive text-destructive-foreground border-destructive",
                    selectedAnswer !== null && option === problem.answer && !isCorrect && "ring-2 ring-success"
                  )}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Progress indicator */}
        <div className="flex justify-center gap-2">
          {Array.from({ length: REQUIRED_SCORE }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-3 h-3 rounded-full transition-colors",
                i < score ? "bg-success" : "bg-muted"
              )}
            />
          ))}
        </div>
      </div>

      {/* Result Modal */}
      {gameState === 'ended' && (
        <GameResult
          isSuccess={isSuccess}
          score={score}
          reward={reward}
          onPlayAgain={handlePlayAgain}
          onExit={handleExit}
        />
      )}
    </div>
  );
}
