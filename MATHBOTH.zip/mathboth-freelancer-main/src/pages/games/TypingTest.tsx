import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Zap, AlertCircle, Keyboard, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { GameTimer } from "@/components/games/GameTimer";
import { GameResult } from "@/components/games/GameResult";
import { cn } from "@/lib/utils";
import { useStartGameSession, useCompleteGameSession, getRewardWithBonus, getEffectiveEnergyCost } from "@/hooks/useGameSession";
import { useProfile, calculateCurrentEnergy } from "@/hooks/useProfile";

const GAME_ID = "typing-test";
const BASE_ENERGY_COST = 10;
const WORD_TIME = 10; // 10 seconds per word
const TOTAL_WORDS = 5; // Number of words to complete

// Easy 3-5 letter words
const EASY_WORDS = [
  "cat", "dog", "sun", "pen", "car", "book", "bird", "fish",
  "tree", "moon", "star", "ball", "box", "cup", "hat", "key",
  "door", "hand", "eye", "ear", "nose", "leg", "arm", "lip",
  "bag", "map", "bed", "fan", "ice", "jam", "kid", "log",
  "net", "nut", "oil", "pan", "pot", "rat", "rug", "toy",
  "van", "wax", "zip", "ant", "bat", "bee", "cow", "fox",
  "hen", "owl", "pig", "ram", "bus", "cap", "egg", "fig",
  "gem", "ink", "jar", "kite", "lamp", "milk", "nail", "oat"
];

function getRandomWord(usedWords: Set<string>): string {
  const available = EASY_WORDS.filter(w => !usedWords.has(w));
  if (available.length === 0) {
    return EASY_WORDS[Math.floor(Math.random() * EASY_WORDS.length)];
  }
  return available[Math.floor(Math.random() * available.length)];
}

export default function TypingTest() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const startSession = useStartGameSession();
  const completeSession = useCompleteGameSession();
  const startTimeRef = useRef<Date>(new Date());
  const hasCompletedRef = useRef(false);
  const sessionIdRef = useRef<string>("");
  const inputRef = useRef<HTMLInputElement>(null);
  
  const [gameState, setGameState] = useState<'init' | 'ready' | 'playing' | 'ended'>('init');
  const [currentWord, setCurrentWord] = useState("");
  const [usedWords, setUsedWords] = useState<Set<string>>(new Set());
  const [userInput, setUserInput] = useState("");
  const [score, setScore] = useState(0);
  const [wordIndex, setWordIndex] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | 'timeout' | null>(null);
  const [timerKey, setTimerKey] = useState(0);
  const [isSuccess, setIsSuccess] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);

  const effectiveEnergyCost = getEffectiveEnergyCost(BASE_ENERGY_COST, profile?.premium_tier || null);
  const currentEnergy = profile ? calculateCurrentEnergy(profile) : 0;

  // Initialize game session on mount
  useEffect(() => {
    const initGame = async () => {
      if (!profile) return;
      
      try {
        const result = await startSession.mutateAsync({
          gameId: GAME_ID,
          energyCost: BASE_ENERGY_COST,
        });

        if (!result.canPlay) {
          setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
          return;
        }

        sessionIdRef.current = result.sessionId;
        setGameState('ready');
      } catch (error) {
        setInitError("Failed to start game. Please try again.");
      }
    };

    if (profile && gameState === 'init' && !initError) {
      initGame();
    }
  }, [profile, gameState, initError]);

  // Start the game
  const handleStart = () => {
    const word = getRandomWord(usedWords);
    setCurrentWord(word);
    setUsedWords(new Set([word]));
    setWordIndex(1);
    startTimeRef.current = new Date();
    setGameState('playing');
    setTimerKey(prev => prev + 1);
    
    // Focus input
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  // Calculate reward
  const calculateReward = useCallback((finalScore: number, success: boolean) => {
    if (!success) return 0;
    const baseReward = Math.min(0.10 + (finalScore * 0.04), 0.50);
    return baseReward;
  }, []);

  // End the game
  const handleGameEnd = useCallback((finalScore: number, success: boolean) => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    
    const endTime = new Date();
    const timeTaken = Math.floor((endTime.getTime() - startTimeRef.current.getTime()) / 1000);
    const baseReward = calculateReward(finalScore, success);
    
    setIsSuccess(success);
    setGameState('ended');
    
    completeSession.mutate({
      sessionId: sessionIdRef.current,
      gameId: GAME_ID,
      score: finalScore,
      isSuccessful: success,
      baseReward,
      timeTakenSeconds: timeTaken,
    });
  }, [completeSession, calculateReward]);

  // Move to next word or end game
  const nextWord = useCallback((wasCorrect: boolean) => {
    const newScore = wasCorrect ? score + 1 : score;
    
    if (wordIndex >= TOTAL_WORDS) {
      // Game complete
      handleGameEnd(newScore, newScore >= 3); // Need at least 3 correct to win
    } else {
      // Next word
      const newUsed = new Set(usedWords);
      const word = getRandomWord(newUsed);
      newUsed.add(word);
      
      setScore(newScore);
      setCurrentWord(word);
      setUsedWords(newUsed);
      setWordIndex(prev => prev + 1);
      setUserInput("");
      setFeedback(null);
      setTimerKey(prev => prev + 1);
      
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [score, wordIndex, usedWords, handleGameEnd]);

  // Handle time up for current word
  const handleTimeUp = useCallback(() => {
    if (gameState !== 'playing') return;
    
    setFeedback('timeout');
    setTimeout(() => nextWord(false), 1000);
  }, [gameState, nextWord]);

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setUserInput(value);
    
    // Check if word matches (case-insensitive)
    if (value.toLowerCase().trim() === currentWord.toLowerCase()) {
      setFeedback('correct');
      setTimeout(() => nextWord(true), 500);
    }
  };

  // Handle submit (Enter key)
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (userInput.toLowerCase().trim() === currentWord.toLowerCase()) {
      setFeedback('correct');
      setTimeout(() => nextWord(true), 500);
    } else {
      setFeedback('wrong');
      setUserInput("");
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  };

  // Play again
  const handlePlayAgain = async () => {
    try {
      const result = await startSession.mutateAsync({
        gameId: GAME_ID,
        energyCost: BASE_ENERGY_COST,
      });

      if (!result.canPlay) {
        setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
        return;
      }

      sessionIdRef.current = result.sessionId;
      hasCompletedRef.current = false;
      setGameState('ready');
      setScore(0);
      setWordIndex(0);
      setCurrentWord("");
      setUsedWords(new Set());
      setUserInput("");
      setFeedback(null);
      setIsSuccess(false);
    } catch {
      setInitError("Failed to start game. Please try again.");
    }
  };

  const handleExit = () => {
    navigate('/games');
  };

  // Calculate display reward with premium bonus
  const reward = getRewardWithBonus(calculateReward(score, isSuccess), profile?.premium_tier || null);

  // Loading/error state
  if (gameState === 'init') {
    if (initError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <Card className="border-0 shadow-soft max-w-sm w-full">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-lg font-bold text-foreground mb-2">Cannot Play</h2>
              <p className="text-muted-foreground mb-4">{initError}</p>
              <Button onClick={handleExit} className="w-full">
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Loading game...</p>
        </div>
      </div>
    );
  }

  // Ready state - show start button
  if (gameState === 'ready') {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-gradient-header pt-safe px-4 pb-6">
          <div className="pt-4 flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleExit}
              className="text-primary-foreground hover:bg-white/10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-primary-foreground">One-Word Typing</h1>
              <p className="text-primary-foreground/80 text-sm">Type {TOTAL_WORDS} words correctly</p>
            </div>
          </div>
        </header>

        <div className="px-4 py-8 flex flex-col items-center justify-center">
          <Card className="border-0 shadow-soft w-full max-w-sm">
            <CardContent className="p-8 text-center">
              <Keyboard className="w-16 h-16 text-primary mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-foreground mb-2">Ready to Type?</h2>
              <p className="text-muted-foreground mb-6">
                Type each word as fast as you can before time runs out!
              </p>
              
              <ul className="text-left text-sm text-muted-foreground mb-6 space-y-2">
                <li>⏱️ {WORD_TIME} seconds per word</li>
                <li>🎯 {TOTAL_WORDS} words to complete</li>
                <li>✅ Need at least 3 correct to win</li>
                <li>📝 Case doesn't matter</li>
              </ul>

              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-4">
                <Zap className="w-4 h-4 text-energy" fill="currentColor" />
                <span>{effectiveEnergyCost} energy</span>
              </div>
              
              <Button 
                onClick={handleStart} 
                className="w-full bg-gradient-primary hover:opacity-90 h-12 text-lg"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Game
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">One-Word Typing</h1>
            <p className="text-primary-foreground/80 text-sm">Word {wordIndex} of {TOTAL_WORDS}</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        {/* Timer */}
        <GameTimer 
          key={timerKey}
          duration={WORD_TIME} 
          onTimeUp={handleTimeUp}
          isRunning={gameState === 'playing' && feedback !== 'correct' && feedback !== 'timeout'}
        />

        {/* Stats Bar */}
        <div className="flex items-center justify-between bg-card rounded-xl p-4 shadow-soft">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Correct</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{wordIndex}/{TOTAL_WORDS}</p>
            <p className="text-xs text-muted-foreground">Progress</p>
          </div>
          <div className="text-center flex items-center gap-1">
            <Zap className="w-4 h-4 text-energy" fill="currentColor" />
            <p className="text-sm font-medium text-muted-foreground">{effectiveEnergyCost}</p>
          </div>
        </div>

        {/* Word Display */}
        <Card className="border-0 shadow-soft">
          <CardContent className="p-8">
            <div className={cn(
              "text-5xl md:text-6xl font-bold text-center mb-8 transition-colors tracking-wider",
              feedback === 'correct' && "text-success",
              feedback === 'wrong' && "text-destructive animate-shake",
              feedback === 'timeout' && "text-warning",
              !feedback && "text-foreground"
            )}>
              {currentWord.toUpperCase()}
            </div>

            {/* Feedback message */}
            {feedback && (
              <div className={cn(
                "text-center mb-6 text-lg font-semibold animate-fade-in",
                feedback === 'correct' && "text-success",
                feedback === 'wrong' && "text-destructive",
                feedback === 'timeout' && "text-warning"
              )}>
                {feedback === 'correct' && "✓ Correct!"}
                {feedback === 'wrong' && "✗ Try again!"}
                {feedback === 'timeout' && "⏰ Time's up!"}
              </div>
            )}

            {/* Input */}
            <form onSubmit={handleSubmit}>
              <Input
                ref={inputRef}
                type="text"
                value={userInput}
                onChange={handleInputChange}
                placeholder="Type the word here..."
                disabled={feedback === 'correct' || feedback === 'timeout'}
                autoComplete="off"
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck="false"
                className={cn(
                  "text-center text-2xl h-14 font-medium transition-colors",
                  feedback === 'correct' && "border-success bg-success/10",
                  feedback === 'wrong' && "border-destructive bg-destructive/10"
                )}
              />
            </form>
          </CardContent>
        </Card>

        {/* Progress dots */}
        <div className="flex justify-center gap-2">
          {Array.from({ length: TOTAL_WORDS }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-3 h-3 rounded-full transition-colors",
                i < wordIndex - 1 ? (i < score ? "bg-success" : "bg-destructive") :
                i === wordIndex - 1 ? "bg-primary animate-pulse" : "bg-muted"
              )}
            />
          ))}
        </div>
      </div>

      {/* Result Modal */}
      {gameState === 'ended' && (
        <GameResult
          isSuccess={isSuccess}
          score={score}
          reward={reward}
          onPlayAgain={handlePlayAgain}
          onExit={handleExit}
        />
      )}
    </div>
  );
}
