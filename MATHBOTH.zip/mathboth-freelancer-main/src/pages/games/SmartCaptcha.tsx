import { useState, useCallback, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Zap, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GameTimer } from "@/components/games/GameTimer";
import { GameResult } from "@/components/games/GameResult";
import { cn } from "@/lib/utils";
import { useStartGameSession, useCompleteGameSession, getRewardWithBonus, getEffectiveEnergyCost } from "@/hooks/useGameSession";
import { useProfile, calculateCurrentEnergy } from "@/hooks/useProfile";

const GAME_ID = "smart-captcha";
const BASE_ENERGY_COST = 8;

const ICONS = ['🔵', '🔴', '🟢', '🟡', '🟣', '🟠', '⬜', '⬛'];

interface CaptchaChallenge {
  target: string;
  grid: string[];
  correctIndices: number[];
}

function generateChallenge(): CaptchaChallenge {
  const targetIcon = ICONS[Math.floor(Math.random() * ICONS.length)];
  const grid: string[] = [];
  const correctIndices: number[] = [];
  
  // Generate a 3x3 grid (9 cells)
  const targetCount = Math.floor(Math.random() * 3) + 2; // 2-4 targets
  
  for (let i = 0; i < 9; i++) {
    if (correctIndices.length < targetCount && Math.random() > 0.5) {
      grid.push(targetIcon);
      correctIndices.push(i);
    } else {
      const otherIcons = ICONS.filter(icon => icon !== targetIcon);
      grid.push(otherIcons[Math.floor(Math.random() * otherIcons.length)]);
    }
  }
  
  // Ensure we have at least 2 targets
  while (correctIndices.length < 2) {
    const randomIndex = Math.floor(Math.random() * 9);
    if (!correctIndices.includes(randomIndex)) {
      grid[randomIndex] = targetIcon;
      correctIndices.push(randomIndex);
    }
  }
  
  return { target: targetIcon, grid, correctIndices };
}

export default function SmartCaptcha() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const startSession = useStartGameSession();
  const completeSession = useCompleteGameSession();
  const startTimeRef = useRef<Date>(new Date());
  const hasCompletedRef = useRef(false);
  const sessionIdRef = useRef<string>("");
  
  const [gameState, setGameState] = useState<'init' | 'playing' | 'ended'>('init');
  const [challenge, setChallenge] = useState<CaptchaChallenge>(() => generateChallenge());
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(1);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  
  const GAME_DURATION = 25;
  const REQUIRED_ROUNDS = 5;

  const effectiveEnergyCost = getEffectiveEnergyCost(BASE_ENERGY_COST, profile?.premium_tier || null);
  const currentEnergy = profile ? calculateCurrentEnergy(profile) : 0;

  // Initialize game session on mount
  useEffect(() => {
    const initGame = async () => {
      if (!profile) return;
      
      try {
        const result = await startSession.mutateAsync({
          gameId: GAME_ID,
          energyCost: BASE_ENERGY_COST,
        });

        if (!result.canPlay) {
          setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
          return;
        }

        sessionIdRef.current = result.sessionId;
        startTimeRef.current = new Date();
        setGameState('playing');
      } catch (error) {
        setInitError("Failed to start game. Please try again.");
      }
    };

    if (profile && gameState === 'init' && !initError) {
      initGame();
    }
  }, [profile, gameState, initError]);

  const calculateReward = useCallback((finalScore: number, success: boolean) => {
    if (!success) return 0;
    return Math.min(0.08 + (finalScore * 0.06), 0.40);
  }, []);

  const handleGameEnd = useCallback((finalScore: number, success: boolean) => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    
    const endTime = new Date();
    const timeTaken = Math.floor((endTime.getTime() - startTimeRef.current.getTime()) / 1000);
    const baseReward = calculateReward(finalScore, success);
    
    setIsSuccess(success);
    setGameState('ended');
    
    completeSession.mutate({
      sessionId: sessionIdRef.current,
      gameId: GAME_ID,
      score: finalScore,
      isSuccessful: success,
      baseReward,
      timeTakenSeconds: timeTaken,
    });
  }, [completeSession, calculateReward]);

  const handleTimeUp = useCallback(() => {
    handleGameEnd(score, score >= REQUIRED_ROUNDS);
  }, [score, handleGameEnd]);

  const handleCellClick = (index: number) => {
    if (showFeedback) return;
    
    setSelectedIndices(prev => {
      if (prev.includes(index)) {
        return prev.filter(i => i !== index);
      }
      return [...prev, index];
    });
  };

  const handleSubmit = () => {
    setShowFeedback(true);
    
    const isCorrect = 
      selectedIndices.length === challenge.correctIndices.length &&
      selectedIndices.every(i => challenge.correctIndices.includes(i));
    
    if (isCorrect) {
      setScore(prev => prev + 1);
    }
    
    setTimeout(() => {
      if (round >= REQUIRED_ROUNDS) {
        const finalSuccess = isCorrect ? score + 1 >= REQUIRED_ROUNDS : score >= REQUIRED_ROUNDS;
        handleGameEnd(isCorrect ? score + 1 : score, finalSuccess);
      } else {
        setRound(prev => prev + 1);
        setChallenge(generateChallenge());
        setSelectedIndices([]);
        setShowFeedback(false);
      }
    }, 800);
  };

  const handlePlayAgain = async () => {
    try {
      const result = await startSession.mutateAsync({
        gameId: GAME_ID,
        energyCost: BASE_ENERGY_COST,
      });

      if (!result.canPlay) {
        setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
        return;
      }

      sessionIdRef.current = result.sessionId;
      startTimeRef.current = new Date();
      hasCompletedRef.current = false;
      setGameState('playing');
      setScore(0);
      setRound(1);
      setChallenge(generateChallenge());
      setSelectedIndices([]);
      setIsSuccess(false);
      setShowFeedback(false);
    } catch {
      setInitError("Failed to start game. Please try again.");
    }
  };

  const handleExit = () => {
    navigate('/games');
  };

  const reward = getRewardWithBonus(calculateReward(score, isSuccess), profile?.premium_tier || null);

  // Show loading/error state
  if (gameState === 'init') {
    if (initError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <Card className="border-0 shadow-soft max-w-sm w-full">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-lg font-bold text-foreground mb-2">Cannot Play</h2>
              <p className="text-muted-foreground mb-4">{initError}</p>
              <Button onClick={handleExit} className="w-full">
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Starting game...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">Smart Captcha</h1>
            <p className="text-primary-foreground/80 text-sm">Round {round}/{REQUIRED_ROUNDS}</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        <GameTimer 
          duration={GAME_DURATION} 
          onTimeUp={handleTimeUp}
          isRunning={gameState === 'playing'}
        />

        {/* Stats Bar */}
        <div className="flex items-center justify-between bg-card rounded-xl p-4 shadow-soft">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Correct</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{round}</p>
            <p className="text-xs text-muted-foreground">Round</p>
          </div>
          <div className="text-center flex items-center gap-1">
            <Zap className="w-4 h-4 text-energy" fill="currentColor" />
            <p className="text-sm font-medium text-muted-foreground">{effectiveEnergyCost}</p>
          </div>
        </div>

        {/* Challenge Card */}
        <Card className="border-0 shadow-soft">
          <CardContent className="p-6">
            <div className="text-center mb-6">
              <p className="text-muted-foreground mb-2">Select all cells with</p>
              <div className="text-5xl">{challenge.target}</div>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-6">
              {challenge.grid.map((icon, index) => (
                <button
                  key={index}
                  onClick={() => handleCellClick(index)}
                  disabled={showFeedback}
                  className={cn(
                    "aspect-square text-4xl flex items-center justify-center rounded-xl transition-all",
                    "border-2 hover:scale-105 active:scale-95",
                    selectedIndices.includes(index) 
                      ? "border-primary bg-primary/10" 
                      : "border-border bg-muted/50 hover:bg-muted",
                    showFeedback && challenge.correctIndices.includes(index) && "border-success bg-success/10",
                    showFeedback && selectedIndices.includes(index) && !challenge.correctIndices.includes(index) && "border-destructive bg-destructive/10"
                  )}
                >
                  {icon}
                </button>
              ))}
            </div>

            <Button
              onClick={handleSubmit}
              disabled={selectedIndices.length === 0 || showFeedback}
              className="w-full h-12 bg-gradient-primary hover:opacity-90"
            >
              Submit
            </Button>
          </CardContent>
        </Card>

        {/* Progress indicator */}
        <div className="flex justify-center gap-2">
          {Array.from({ length: REQUIRED_ROUNDS }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-3 h-3 rounded-full transition-colors",
                i < score ? "bg-success" : i < round ? "bg-destructive" : "bg-muted"
              )}
            />
          ))}
        </div>
      </div>

      {gameState === 'ended' && (
        <GameResult
          isSuccess={isSuccess}
          score={score}
          reward={reward}
          onPlayAgain={handlePlayAgain}
          onExit={handleExit}
        />
      )}
    </div>
  );
}
