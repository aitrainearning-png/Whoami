import { useState, useCallback, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Zap, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GameTimer } from "@/components/games/GameTimer";
import { GameResult } from "@/components/games/GameResult";
import { cn } from "@/lib/utils";
import { useStartGameSession, useCompleteGameSession, getRewardWithBonus, getEffectiveEnergyCost } from "@/hooks/useGameSession";
import { useProfile, calculateCurrentEnergy } from "@/hooks/useProfile";

const GAME_ID = "pattern-puzzle";
const BASE_ENERGY_COST = 12;

interface PatternChallenge {
  sequence: (number | null)[];
  answer: number;
  options: number[];
  pattern: string;
}

function generatePattern(): PatternChallenge {
  const patterns = [
    { name: 'add', fn: (n: number, step: number) => n + step },
    { name: 'multiply', fn: (n: number, factor: number) => n * factor },
    { name: 'alternate', fn: (n: number, step: number, i: number) => n + (i % 2 === 0 ? step : step * 2) },
  ];
  
  const selectedPattern = patterns[Math.floor(Math.random() * patterns.length)];
  const startNum = Math.floor(Math.random() * 10) + 1;
  const step = Math.floor(Math.random() * 5) + 2;
  
  let sequence: number[] = [startNum];
  for (let i = 1; i < 5; i++) {
    if (selectedPattern.name === 'add') {
      sequence.push(sequence[i - 1] + step);
    } else if (selectedPattern.name === 'multiply') {
      sequence.push(sequence[i - 1] * 2);
    } else {
      sequence.push(sequence[i - 1] + (i % 2 === 0 ? step : step + 1));
    }
  }
  
  const missingIndex = Math.floor(Math.random() * 3) + 1; // 1-3
  const answer = sequence[missingIndex];
  
  const displaySequence: (number | null)[] = [...sequence];
  displaySequence[missingIndex] = null;
  
  // Generate options
  const options = new Set<number>([answer]);
  while (options.size < 4) {
    const offset = Math.floor(Math.random() * 10) - 5;
    const wrongAnswer = answer + offset;
    if (wrongAnswer > 0 && wrongAnswer !== answer) {
      options.add(wrongAnswer);
    }
  }
  
  return {
    sequence: displaySequence,
    answer,
    options: Array.from(options).sort(() => Math.random() - 0.5),
    pattern: selectedPattern.name,
  };
}

export default function PatternPuzzle() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const startSession = useStartGameSession();
  const completeSession = useCompleteGameSession();
  const startTimeRef = useRef<Date>(new Date());
  const hasCompletedRef = useRef(false);
  const sessionIdRef = useRef<string>("");
  
  const [gameState, setGameState] = useState<'init' | 'playing' | 'ended'>('init');
  const [challenge, setChallenge] = useState<PatternChallenge>(() => generatePattern());
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(1);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  
  const GAME_DURATION = 35;
  const REQUIRED_ROUNDS = 5;

  const effectiveEnergyCost = getEffectiveEnergyCost(BASE_ENERGY_COST, profile?.premium_tier || null);
  const currentEnergy = profile ? calculateCurrentEnergy(profile) : 0;

  // Initialize game session on mount
  useEffect(() => {
    const initGame = async () => {
      if (!profile) return;
      
      try {
        const result = await startSession.mutateAsync({
          gameId: GAME_ID,
          energyCost: BASE_ENERGY_COST,
        });

        if (!result.canPlay) {
          setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
          return;
        }

        sessionIdRef.current = result.sessionId;
        startTimeRef.current = new Date();
        setGameState('playing');
      } catch (error) {
        setInitError("Failed to start game. Please try again.");
      }
    };

    if (profile && gameState === 'init' && !initError) {
      initGame();
    }
  }, [profile, gameState, initError]);

  const calculateReward = useCallback((finalScore: number, success: boolean) => {
    if (!success) return 0;
    return Math.min(0.15 + (finalScore * 0.09), 0.60);
  }, []);

  const handleGameEnd = useCallback((finalScore: number, success: boolean) => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    
    const endTime = new Date();
    const timeTaken = Math.floor((endTime.getTime() - startTimeRef.current.getTime()) / 1000);
    const baseReward = calculateReward(finalScore, success);
    
    setIsSuccess(success);
    setGameState('ended');
    
    completeSession.mutate({
      sessionId: sessionIdRef.current,
      gameId: GAME_ID,
      score: finalScore,
      isSuccessful: success,
      baseReward,
      timeTakenSeconds: timeTaken,
    });
  }, [completeSession, calculateReward]);

  const handleTimeUp = useCallback(() => {
    handleGameEnd(score, score >= REQUIRED_ROUNDS);
  }, [score, handleGameEnd]);

  const handleAnswer = (answer: number) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answer);
    const correct = answer === challenge.answer;
    setIsCorrect(correct);
    
    if (correct) {
      setScore(prev => prev + 1);
    }
    
    setTimeout(() => {
      if (round >= REQUIRED_ROUNDS) {
        const finalSuccess = correct ? score + 1 >= REQUIRED_ROUNDS : score >= REQUIRED_ROUNDS;
        handleGameEnd(correct ? score + 1 : score, finalSuccess);
      } else {
        setRound(prev => prev + 1);
        setChallenge(generatePattern());
        setSelectedAnswer(null);
        setIsCorrect(null);
      }
    }, 800);
  };

  const handlePlayAgain = async () => {
    try {
      const result = await startSession.mutateAsync({
        gameId: GAME_ID,
        energyCost: BASE_ENERGY_COST,
      });

      if (!result.canPlay) {
        setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
        return;
      }

      sessionIdRef.current = result.sessionId;
      startTimeRef.current = new Date();
      hasCompletedRef.current = false;
      setGameState('playing');
      setScore(0);
      setRound(1);
      setChallenge(generatePattern());
      setSelectedAnswer(null);
      setIsCorrect(null);
      setIsSuccess(false);
    } catch {
      setInitError("Failed to start game. Please try again.");
    }
  };

  const handleExit = () => {
    navigate('/games');
  };

  const reward = getRewardWithBonus(calculateReward(score, isSuccess), profile?.premium_tier || null);

  // Show loading/error state
  if (gameState === 'init') {
    if (initError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <Card className="border-0 shadow-soft max-w-sm w-full">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-lg font-bold text-foreground mb-2">Cannot Play</h2>
              <p className="text-muted-foreground mb-4">{initError}</p>
              <Button onClick={handleExit} className="w-full">
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Starting game...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">Pattern Puzzle</h1>
            <p className="text-primary-foreground/80 text-sm">Round {round}/{REQUIRED_ROUNDS}</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        <GameTimer 
          duration={GAME_DURATION} 
          onTimeUp={handleTimeUp}
          isRunning={gameState === 'playing'}
        />

        {/* Stats Bar */}
        <div className="flex items-center justify-between bg-card rounded-xl p-4 shadow-soft">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Correct</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{round}</p>
            <p className="text-xs text-muted-foreground">Round</p>
          </div>
          <div className="text-center flex items-center gap-1">
            <Zap className="w-4 h-4 text-energy" fill="currentColor" />
            <p className="text-sm font-medium text-muted-foreground">{effectiveEnergyCost}</p>
          </div>
        </div>

        {/* Challenge Card */}
        <Card className="border-0 shadow-soft">
          <CardContent className="p-6">
            <p className="text-center text-muted-foreground mb-4">
              Find the missing number in the pattern
            </p>

            {/* Sequence Display */}
            <div className="flex items-center justify-center gap-2 mb-8">
              {challenge.sequence.map((num, index) => (
                <div key={index} className="flex items-center">
                  <div className={cn(
                    "w-14 h-14 flex items-center justify-center rounded-xl text-xl font-bold",
                    num === null 
                      ? "border-2 border-dashed border-primary bg-primary/5 text-primary" 
                      : "bg-muted text-foreground"
                  )}>
                    {num === null ? "?" : num}
                  </div>
                  {index < challenge.sequence.length - 1 && (
                    <span className="mx-1 text-muted-foreground">→</span>
                  )}
                </div>
              ))}
            </div>

            {/* Options */}
            <div className="grid grid-cols-2 gap-3">
              {challenge.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleAnswer(option)}
                  disabled={selectedAnswer !== null}
                  className={cn(
                    "h-14 text-xl font-bold transition-all",
                    selectedAnswer === option && isCorrect && "bg-success text-success-foreground border-success",
                    selectedAnswer === option && !isCorrect && "bg-destructive text-destructive-foreground border-destructive",
                    selectedAnswer !== null && option === challenge.answer && !isCorrect && "ring-2 ring-success"
                  )}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Progress indicator */}
        <div className="flex justify-center gap-2">
          {Array.from({ length: REQUIRED_ROUNDS }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-3 h-3 rounded-full transition-colors",
                i < score ? "bg-success" : i < round ? "bg-destructive" : "bg-muted"
              )}
            />
          ))}
        </div>
      </div>

      {gameState === 'ended' && (
        <GameResult
          isSuccess={isSuccess}
          score={score}
          reward={reward}
          onPlayAgain={handlePlayAgain}
          onExit={handleExit}
        />
      )}
    </div>
  );
}
