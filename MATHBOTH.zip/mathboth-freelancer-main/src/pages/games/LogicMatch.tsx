import { useState, useCallback, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Zap, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GameTimer } from "@/components/games/GameTimer";
import { GameResult } from "@/components/games/GameResult";
import { cn } from "@/lib/utils";
import { useStartGameSession, useCompleteGameSession, getRewardWithBonus, getEffectiveEnergyCost } from "@/hooks/useGameSession";
import { useProfile, calculateCurrentEnergy } from "@/hooks/useProfile";

const GAME_ID = "logic-match";
const BASE_ENERGY_COST = 15;
const SYMBOLS = ['🍎', '🍊', '🍋', '🍇', '🍓', '🍒', '🥝', '🍑'];

interface MatchCard {
  id: number;
  symbol: string;
  isFlipped: boolean;
  isMatched: boolean;
}

function generateCards(): MatchCard[] {
  const numPairs = 6;
  const selectedSymbols = SYMBOLS.slice(0, numPairs);
  const cards: MatchCard[] = [];
  
  selectedSymbols.forEach((symbol, index) => {
    cards.push({ id: index * 2, symbol, isFlipped: false, isMatched: false });
    cards.push({ id: index * 2 + 1, symbol, isFlipped: false, isMatched: false });
  });
  
  // Shuffle
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  
  return cards;
}

export default function LogicMatch() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const startSession = useStartGameSession();
  const completeSession = useCompleteGameSession();
  const startTimeRef = useRef<Date>(new Date());
  const hasCompletedRef = useRef(false);
  const sessionIdRef = useRef<string>("");
  
  const [gameState, setGameState] = useState<'init' | 'playing' | 'ended'>('init');
  const [cards, setCards] = useState<MatchCard[]>(() => generateCards());
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedPairs, setMatchedPairs] = useState(0);
  const [moves, setMoves] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  
  const GAME_DURATION = 40;
  const TOTAL_PAIRS = 6;

  const effectiveEnergyCost = getEffectiveEnergyCost(BASE_ENERGY_COST, profile?.premium_tier || null);
  const currentEnergy = profile ? calculateCurrentEnergy(profile) : 0;

  // Initialize game session on mount
  useEffect(() => {
    const initGame = async () => {
      if (!profile) return;
      
      try {
        const result = await startSession.mutateAsync({
          gameId: GAME_ID,
          energyCost: BASE_ENERGY_COST,
        });

        if (!result.canPlay) {
          setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
          return;
        }

        sessionIdRef.current = result.sessionId;
        startTimeRef.current = new Date();
        setGameState('playing');
      } catch (error) {
        setInitError("Failed to start game. Please try again.");
      }
    };

    if (profile && gameState === 'init' && !initError) {
      initGame();
    }
  }, [profile, gameState, initError]);

  const calculateReward = useCallback((finalMoves: number, success: boolean) => {
    if (!success) return 0;
    const efficiency = Math.max(1 - (finalMoves - TOTAL_PAIRS) / 20, 0.5);
    return parseFloat((0.20 + (0.55 * efficiency)).toFixed(2));
  }, []);

  const handleGameEnd = useCallback((finalPairs: number, finalMoves: number, success: boolean) => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    
    const endTime = new Date();
    const timeTaken = Math.floor((endTime.getTime() - startTimeRef.current.getTime()) / 1000);
    const baseReward = calculateReward(finalMoves, success);
    
    setIsSuccess(success);
    setGameState('ended');
    
    completeSession.mutate({
      sessionId: sessionIdRef.current,
      gameId: GAME_ID,
      score: finalPairs,
      isSuccessful: success,
      baseReward,
      timeTakenSeconds: timeTaken,
    });
  }, [completeSession, calculateReward]);

  const handleTimeUp = useCallback(() => {
    handleGameEnd(matchedPairs, moves, matchedPairs >= TOTAL_PAIRS);
  }, [matchedPairs, moves, handleGameEnd]);

  // Check for win condition
  useEffect(() => {
    if (matchedPairs >= TOTAL_PAIRS && gameState === 'playing') {
      handleGameEnd(matchedPairs, moves, true);
    }
  }, [matchedPairs, gameState, moves, handleGameEnd]);

  const handleCardClick = (cardIndex: number) => {
    if (isLocked) return;
    if (cards[cardIndex].isFlipped || cards[cardIndex].isMatched) return;
    if (flippedCards.length >= 2) return;
    
    const newCards = [...cards];
    newCards[cardIndex].isFlipped = true;
    setCards(newCards);
    
    const newFlipped = [...flippedCards, cardIndex];
    setFlippedCards(newFlipped);
    
    if (newFlipped.length === 2) {
      setMoves(prev => prev + 1);
      setIsLocked(true);
      
      const [first, second] = newFlipped;
      if (cards[first].symbol === cards[second].symbol) {
        // Match found
        setTimeout(() => {
          const matchedCards = [...cards];
          matchedCards[first].isMatched = true;
          matchedCards[second].isMatched = true;
          setCards(matchedCards);
          setMatchedPairs(prev => prev + 1);
          setFlippedCards([]);
          setIsLocked(false);
        }, 300);
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[first].isFlipped = false;
          resetCards[second].isFlipped = false;
          setCards(resetCards);
          setFlippedCards([]);
          setIsLocked(false);
        }, 800);
      }
    }
  };

  const handlePlayAgain = async () => {
    try {
      const result = await startSession.mutateAsync({
        gameId: GAME_ID,
        energyCost: BASE_ENERGY_COST,
      });

      if (!result.canPlay) {
        setInitError(`Not enough energy. You need ${effectiveEnergyCost} energy to play.`);
        return;
      }

      sessionIdRef.current = result.sessionId;
      startTimeRef.current = new Date();
      hasCompletedRef.current = false;
      setGameState('playing');
      setCards(generateCards());
      setFlippedCards([]);
      setMatchedPairs(0);
      setMoves(0);
      setIsLocked(false);
      setIsSuccess(false);
    } catch {
      setInitError("Failed to start game. Please try again.");
    }
  };

  const handleExit = () => {
    navigate('/games');
  };

  const reward = getRewardWithBonus(calculateReward(moves, isSuccess), profile?.premium_tier || null);

  // Show loading/error state
  if (gameState === 'init') {
    if (initError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <Card className="border-0 shadow-soft max-w-sm w-full">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-lg font-bold text-foreground mb-2">Cannot Play</h2>
              <p className="text-muted-foreground mb-4">{initError}</p>
              <Button onClick={handleExit} className="w-full">
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Starting game...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6">
        <div className="pt-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">Logic Match</h1>
            <p className="text-primary-foreground/80 text-sm">Match all {TOTAL_PAIRS} pairs</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        <GameTimer 
          duration={GAME_DURATION} 
          onTimeUp={handleTimeUp}
          isRunning={gameState === 'playing'}
        />

        {/* Stats Bar */}
        <div className="flex items-center justify-between bg-card rounded-xl p-4 shadow-soft">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{matchedPairs}/{TOTAL_PAIRS}</p>
            <p className="text-xs text-muted-foreground">Pairs</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{moves}</p>
            <p className="text-xs text-muted-foreground">Moves</p>
          </div>
          <div className="text-center flex items-center gap-1">
            <Zap className="w-4 h-4 text-energy" fill="currentColor" />
            <p className="text-sm font-medium text-muted-foreground">{effectiveEnergyCost}</p>
          </div>
        </div>

        {/* Card Grid */}
        <Card className="border-0 shadow-soft">
          <CardContent className="p-4">
            <div className="grid grid-cols-4 gap-2">
              {cards.map((card, index) => (
                <button
                  key={card.id}
                  onClick={() => handleCardClick(index)}
                  disabled={card.isMatched || isLocked}
                  className={cn(
                    "aspect-square rounded-xl text-3xl flex items-center justify-center transition-all duration-300 transform",
                    card.isFlipped || card.isMatched
                      ? "bg-card border-2 border-primary rotate-0"
                      : "bg-gradient-header hover:scale-105 active:scale-95",
                    card.isMatched && "opacity-50 border-success"
                  )}
                >
                  {card.isFlipped || card.isMatched ? card.symbol : '?'}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Progress indicator */}
        <div className="flex justify-center gap-2">
          {Array.from({ length: TOTAL_PAIRS }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-3 h-3 rounded-full transition-colors",
                i < matchedPairs ? "bg-success" : "bg-muted"
              )}
            />
          ))}
        </div>
      </div>

      {gameState === 'ended' && (
        <GameResult
          isSuccess={isSuccess}
          score={matchedPairs}
          reward={reward}
          onPlayAgain={handlePlayAgain}
          onExit={handleExit}
        />
      )}
    </div>
  );
}
