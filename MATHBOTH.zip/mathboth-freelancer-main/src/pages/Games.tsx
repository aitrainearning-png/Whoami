import { Calculator, ShieldCheck, Grid3X3, Puzzle, Zap, Keyboard, CircleDollarSign, ExternalLink, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { GameCard } from "@/components/games/GameCard";
import { PlaytimeTimer } from "@/components/home/PlaytimeTimer";
import { useProfile } from "@/hooks/useProfile";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const gameIcons: Record<string, typeof Calculator> = {
  "quick-math": Calculator,
  "smart-captcha": ShieldCheck,
  "pattern-puzzle": Grid3X3,
  "logic-match": Puzzle,
  "typing-test": Keyboard,
};

export default function Games() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();

  const { data: games, isLoading } = useQuery({
    queryKey: ["games"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("games")
        .select("*")
        .eq("is_active", true)
        .order("energy_cost", { ascending: true });

      if (error) throw error;
      return data;
    },
  });

  const handlePlayGame = (gameId: string) => {
    const routes: Record<string, string> = {
      "quick-math": "/play/quick-math",
      "smart-captcha": "/play/smart-captcha",
      "pattern-puzzle": "/play/pattern-puzzle",
      "logic-match": "/play/logic-match",
      "typing-test": "/play/typing-test",
    };
    navigate(routes[gameId] || `/play/${gameId}`);
  };

  // Check if user has ANY premium tier (basic, advance, or pro) - use !! to ensure boolean
  const isPremium = !!profile?.premium_tier;
  const playtimeResetAt = profile?.playtime_reset_at || new Date().toISOString();
  const premiumExpiresAt = profile?.premium_expires_at;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-6 rounded-b-3xl">
        <div className="pt-6">
          <h1 className="text-2xl font-bold text-primary-foreground">Games</h1>
          <p className="text-primary-foreground/80 text-sm mt-1">
            Play games to earn rewards
          </p>
        </div>

        <div className="mt-5">
          <PlaytimeTimer 
            playtimeResetAt={playtimeResetAt}
            isPremium={isPremium}
            premiumExpiresAt={premiumExpiresAt}
            showDetails={true}
          />
        </div>
      </header>

      {/* Games List */}
      <div className="px-4 py-6">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-5 h-5 text-energy" fill="currentColor" />
          <h2 className="text-lg font-semibold text-foreground">Available Games</h2>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {games?.map((game, index) => (
              <div 
                key={game.id}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <GameCard 
                  id={game.id}
                  name={game.name}
                  icon={gameIcons[game.id] || Calculator}
                  energyCost={game.energy_cost}
                  minReward={Number(game.min_reward)}
                  maxReward={Number(game.max_reward)}
                  onPlay={handlePlayGame} 
                />
              </div>
            ))}
            <div>
              <a
                href="https://peso-task.lovable.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Card className="border-0 shadow-soft overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent">
                        <ExternalLink className="h-7 w-7 text-primary-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground">Earn More Rewards</h3>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-xs font-medium text-success">Click here to earn more</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">Complete tasks & earn extra rewards</p>
                      </div>
                      <Button className="h-10 px-5">
                        Go
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </div>
          </div>
        )}

        {/* Community Section */}
        <div className="mt-6">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Community</h2>
          </div>
          <a
            href="https://facebook.com/groups/760736665618403/"
            target="_blank"
            rel="noopener noreferrer"
            className="block"
          >
            <Card className="border-0 shadow-soft overflow-hidden animate-fade-up">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent">
                    <Users className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground">Join our Official Facebook Group</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Connect with the community & get updates</p>
                  </div>
                  <Button className="h-10 px-5">
                    Join
                  </Button>
                </div>
              </CardContent>
            </Card>
          </a>
        </div>

        {/* Coin Toss Betting Game */}
        <div className="mt-6">
          <div className="flex items-center gap-2 mb-4">
            <CircleDollarSign className="w-5 h-5 text-gold" />
            <h2 className="text-lg font-semibold text-foreground">Betting Games</h2>
          </div>
          <Card className="border-0 shadow-soft overflow-hidden animate-fade-up">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500">
                  <span className="text-2xl">🪙</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground">Toss a Coin</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs font-medium text-muted-foreground">Odd or Even</span>
                    <span className="text-xs font-medium text-success">2x reward</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">Min bet: ₱500 • 60% win rate</p>
                </div>
                <Button
                  onClick={() => navigate("/play/coin-toss")}
                  className="h-10 px-5 bg-gradient-to-r from-yellow-500 to-orange-500 hover:opacity-90 text-white"
                >
                  Bet
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
