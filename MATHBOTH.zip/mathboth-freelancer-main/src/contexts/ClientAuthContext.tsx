import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

interface ClientProfile {
  id: string;
  user_id: string;
  email: string;
  company_name: string | null;
  display_name: string | null;
  status: "pending" | "approved" | "suspended";
}

interface ClientWallet {
  id: string;
  client_id: string;
  balance: number;
  total_deposited: number;
  total_spent: number;
}

interface ClientAuthContextType {
  user: User | null;
  session: Session | null;
  client: ClientProfile | null;
  wallet: ClientWallet | null;
  loading: boolean;
  signUp: (email: string, password: string, displayName?: string, companyName?: string) => Promise<{ error: Error | null }>;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  refreshWallet: () => Promise<void>;
}

const ClientAuthContext = createContext<ClientAuthContextType | undefined>(undefined);

export function ClientAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [client, setClient] = useState<ClientProfile | null>(null);
  const [wallet, setWallet] = useState<ClientWallet | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchClientData = async (userId: string) => {
    // Fetch client profile
    const { data: clientData } = await supabase
      .from("clients")
      .select("*")
      .eq("user_id", userId)
      .single();

    if (clientData) {
      setClient(clientData as ClientProfile);

      // Fetch wallet
      const { data: walletData } = await supabase
        .from("client_wallets")
        .select("*")
        .eq("client_id", clientData.id)
        .single();

      if (walletData) {
        setWallet(walletData as ClientWallet);
      }
    } else {
      setClient(null);
      setWallet(null);
    }
  };

  const refreshWallet = async () => {
    if (client) {
      const { data: walletData } = await supabase
        .from("client_wallets")
        .select("*")
        .eq("client_id", client.id)
        .single();

      if (walletData) {
        setWallet(walletData as ClientWallet);
      }
    }
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setTimeout(() => fetchClientData(session.user.id), 0);
        } else {
          setClient(null);
          setWallet(null);
        }
        setLoading(false);
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchClientData(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (
    email: string,
    password: string,
    displayName?: string,
    companyName?: string
  ) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin + "/client",
        },
      });

      if (error) return { error };

      // Create client profile after signup
      if (data.user) {
        const { error: profileError } = await supabase
          .from("clients")
          .insert({
            user_id: data.user.id,
            email,
            display_name: displayName || email.split("@")[0],
            company_name: companyName || null,
          });

        if (profileError) {
          return { error: new Error(profileError.message) };
        }
      }

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setClient(null);
    setWallet(null);
  };

  return (
    <ClientAuthContext.Provider
      value={{
        user,
        session,
        client,
        wallet,
        loading,
        signUp,
        signIn,
        signOut,
        refreshWallet,
      }}
    >
      {children}
    </ClientAuthContext.Provider>
  );
}

export function useClientAuth() {
  const context = useContext(ClientAuthContext);
  if (context === undefined) {
    throw new Error("useClientAuth must be used within a ClientAuthProvider");
  }
  return context;
}
