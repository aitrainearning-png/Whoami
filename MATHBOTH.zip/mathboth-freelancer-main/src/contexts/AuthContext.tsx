import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

interface BanInfo {
  is_banned: boolean;
  ban_type: string;
  reason: string;
  expires_at: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  banInfo: BanInfo | null;
  signUp: (email: string, password: string, displayName?: string, referralCode?: string) => Promise<{ error: Error | null }>;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [banInfo, setBanInfo] = useState<BanInfo | null>(null);

  const checkBanStatus = async (userId: string) => {
    const { data, error } = await supabase.rpc("is_user_banned", { check_user_id: userId });
    
    if (!error && data && data.length > 0) {
      const ban = data[0];
      // For temporary bans, check if expired
      if (ban.ban_type === "temporary" && ban.expires_at && new Date(ban.expires_at) <= new Date()) {
        setBanInfo(null);
        return false;
      }
      setBanInfo(ban);
      // Auto-logout banned user
      await supabase.auth.signOut();
      return true;
    } else {
      setBanInfo(null);
      return false;
    }
  };

  useEffect(() => {
    // Set up auth state listener BEFORE checking session
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Check ban status after login
          setTimeout(() => {
            checkBanStatus(session.user.id);
          }, 0);
        } else if (event === 'SIGNED_OUT') {
          // Don't clear banInfo on sign out so the ban message stays visible
        }
        
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        checkBanStatus(session.user.id);
      }
      
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Periodically check ban status for logged-in users
  useEffect(() => {
    if (!user) return;
    
    const interval = setInterval(() => {
      checkBanStatus(user.id);
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [user]);

  const signUp = async (
    email: string, 
    password: string, 
    displayName?: string, 
    referralCode?: string
  ) => {
    try {
      if (referralCode && referralCode.trim() !== "") {
        const { data: isValid, error: refError } = await supabase
          .rpc("validate_referral_code", { code: referralCode.trim() });

        if (refError) {
          return { error: new Error("Failed to validate referral code") };
        }

        if (!isValid) {
          return { error: new Error("Referral code doesn't exist") };
        }
      }

      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin,
          data: {
            display_name: displayName || email.split('@')[0],
            referral_code: referralCode?.trim().toUpperCase() || null,
          },
        },
      });
      return { error };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      // Clear any previous ban info
      setBanInfo(null);
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (!error && data.user) {
        // Check ban status immediately after sign in
        const isBanned = await checkBanStatus(data.user.id);
        if (isBanned) {
          return { error: new Error("Your account has been banned.") };
        }
      }
      
      return { error };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signOut = async () => {
    setBanInfo(null);
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, banInfo, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}