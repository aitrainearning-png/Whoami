import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useChatEnabled() {
  const query = useQuery({
    queryKey: ["app-settings", "chat_enabled"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("value")
        .eq("key", "chat_enabled")
        .single();

      if (error) throw error;
      return (data?.value as { enabled: boolean })?.enabled ?? true;
    },
  });

  // Subscribe to realtime changes
  useEffect(() => {
    const channel = supabase
      .channel("app-settings-changes")
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "app_settings",
          filter: "key=eq.chat_enabled",
        },
        (payload) => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query]);

  return {
    chatEnabled: query.data ?? true,
    isLoading: query.isLoading,
    refetch: query.refetch,
  };
}
