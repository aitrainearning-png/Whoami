import { useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export function useActivityTracker() {
  const { user } = useAuth();
  const lastUpdateRef = useRef<number>(0);

  useEffect(() => {
    if (!user) return;

    const updateActivity = async () => {
      const now = Date.now();
      // Only update if more than 30 seconds has passed since last update (for real-time tracking)
      if (now - lastUpdateRef.current < 30000) return;

      lastUpdateRef.current = now;

      await supabase
        .from("profiles")
        .update({ last_active_at: new Date().toISOString() })
        .eq("user_id", user.id);
    };

    // Update on mount
    updateActivity();

    // Update on user interactions
    const handleActivity = () => updateActivity();

    window.addEventListener("click", handleActivity);
    window.addEventListener("keydown", handleActivity);
    window.addEventListener("scroll", handleActivity);
    window.addEventListener("mousemove", handleActivity);
    window.addEventListener("touchstart", handleActivity);

    // Also update periodically (every 1 minute to keep showing as online)
    const interval = setInterval(updateActivity, 60000);

    return () => {
      window.removeEventListener("click", handleActivity);
      window.removeEventListener("keydown", handleActivity);
      window.removeEventListener("scroll", handleActivity);
      window.removeEventListener("mousemove", handleActivity);
      window.removeEventListener("touchstart", handleActivity);
      clearInterval(interval);
    };
  }, [user]);
}
