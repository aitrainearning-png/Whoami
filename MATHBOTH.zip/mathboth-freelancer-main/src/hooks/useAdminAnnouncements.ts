import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface Announcement {
  id: string;
  message: string;
  created_at: string;
  created_by: string;
  is_active: boolean;
}

export function useAdminAnnouncements() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Fetch active announcements
  const { data: announcements = [], isLoading } = useQuery({
    queryKey: ["admin-announcements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("admin_announcements")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Announcement[];
    },
    enabled: !!user,
  });

  // Fetch user's dismissed announcements
  const { data: dismissedIds = [] } = useQuery({
    queryKey: ["announcement-dismissals", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("announcement_dismissals")
        .select("announcement_id")
        .eq("user_id", user.id);

      if (error) throw error;
      return data.map((d) => d.announcement_id);
    },
    enabled: !!user,
  });

  // Filter out dismissed announcements
  const activeAnnouncements = announcements.filter(
    (a) => !dismissedIds.includes(a.id)
  );

  // Dismiss mutation
  const dismissMutation = useMutation({
    mutationFn: async (announcementId: string) => {
      if (!user) throw new Error("Not authenticated");
      
      const { error } = await supabase
        .from("announcement_dismissals")
        .insert({
          user_id: user.id,
          announcement_id: announcementId,
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["announcement-dismissals"] });
    },
  });

  // Send announcement mutation (admin only)
  const sendMutation = useMutation({
    mutationFn: async (message: string) => {
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("admin_announcements")
        .insert({
          message,
          created_by: user.id,
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-announcements"] });
    },
  });

  // Realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel("admin-announcements-realtime")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "admin_announcements",
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ["admin-announcements"] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  return {
    announcements: activeAnnouncements,
    isLoading,
    dismiss: dismissMutation.mutate,
    isDismissing: dismissMutation.isPending,
    sendAnnouncement: sendMutation.mutate,
    isSending: sendMutation.isPending,
  };
}
