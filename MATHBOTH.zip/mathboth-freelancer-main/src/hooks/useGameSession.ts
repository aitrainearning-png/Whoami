import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface StartSessionResult {
  sessionId: string;
  canPlay: boolean;
  currentEnergy: number;
  energySpent?: number;
  premiumTier?: string | null;
  rewardBonus?: number;
}

interface CompleteGameData {
  sessionId: string;
  gameId: string;
  score: number;
  isSuccessful: boolean;
  baseReward: number;
  timeTakenSeconds: number;
}

export function useStartGameSession() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ gameId, energyCost }: { gameId: string; energyCost: number }): Promise<StartSessionResult> => {
      if (!user) throw new Error("Not authenticated");

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No active session");

      const response = await supabase.functions.invoke("start-game-session", {
        body: { gameId, baseCost: energyCost },
      });

      if (response.error) {
        throw new Error(response.error.message || "Failed to start game");
      }

      const result = response.data;

      if (!result.canPlay) {
        return {
          sessionId: "",
          canPlay: false,
          currentEnergy: result.currentEnergy,
        };
      }

      return {
        sessionId: result.sessionId,
        canPlay: true,
        currentEnergy: result.currentEnergy,
        energySpent: result.energySpent,
        premiumTier: result.premiumTier,
        rewardBonus: result.rewardBonus,
      };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (error) => {
      console.error("Failed to start game session:", error);
      toast.error("Failed to start game. Please try again.");
    },
  });
}

export function useCompleteGameSession() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: CompleteGameData) => {
      if (!user) throw new Error("Not authenticated");

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No active session");

      const response = await supabase.functions.invoke("complete-game-session", {
        body: data,
      });

      if (response.error) {
        throw new Error(response.error.message || "Failed to complete game");
      }

      return response.data;
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      if (result.credited) {
        toast.success(`₱${result.amount.toFixed(2)} credited to your balance!`);
      }
    },
    onError: (error) => {
      console.error("Failed to complete game session:", error);
      toast.error("Failed to save game result. Please try again.");
    },
  });
}

// Get premium tier benefits (client-side for display purposes)
export function getPremiumBenefits(tier: string | null): {
  maxEnergy: number;
  regenRate: number;
  energyDiscount: number;
  rewardBonus: number;
} {
  // Premium tiers have unlimited energy (represented by high values)
  switch (tier) {
    case "pro":
      return {
        maxEnergy: 999999, // Unlimited
        regenRate: 0, // Not applicable
        energyDiscount: 1, // 100% discount = free
        rewardBonus: 0, // Fixed ₱0.50 per action
      };
    case "advance":
      return {
        maxEnergy: 999999, // Unlimited
        regenRate: 0,
        energyDiscount: 1,
        rewardBonus: 0, // Fixed ₱0.35 per action
      };
    case "basic":
      return {
        maxEnergy: 999999, // Unlimited
        regenRate: 0,
        energyDiscount: 1,
        rewardBonus: 0, // Fixed ₱0.20 per action
      };
    default:
      // Free user: ₱0.15 per action, 4 hour daily playtime limit (resets at 8 AM)
      return {
        maxEnergy: 100,
        regenRate: 1,
        energyDiscount: 0,
        rewardBonus: 0, // Fixed ₱0.15 per action
      };
  }
}

// Get reward amount for display based on tier
export function getRewardForTier(tier: string | null): number {
  switch (tier) {
    case "pro":
      return 1.40;
    case "advance":
      return 1.30;
    case "basic":
      return 1.00;
    default:
      return 1.30;
  }
}

// Calculate effective energy cost with premium discount (for display)
export function getEffectiveEnergyCost(baseCost: number, premiumTier: string | null): number {
  const { energyDiscount } = getPremiumBenefits(premiumTier);
  return Math.floor(baseCost * (1 - energyDiscount));
}

// Calculate reward with premium bonus (for display)
export function getRewardWithBonus(baseReward: number, premiumTier: string | null): number {
  const { rewardBonus } = getPremiumBenefits(premiumTier);
  return parseFloat((baseReward * (1 + rewardBonus)).toFixed(2));
}
