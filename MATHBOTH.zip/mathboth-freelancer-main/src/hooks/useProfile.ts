import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface Profile {
  id: string;
  user_id: string;
  display_name: string | null;
  email: string | null;
  avatar_url: string | null;
  energy: number;
  max_energy: number;
  energy_updated_at: string;
  balance: number;
  total_earned: number;
  games_played: number;
  premium_tier: "basic" | "advance" | "pro" | null;
  premium_expires_at: string | null;
  referral_code: string;
  referred_by: string | null;
  referral_count: number;
  referral_earnings: number;
  first_withdrawal_done: boolean;
  last_withdrawal_at: string | null;
  withdrawals_unlocked: boolean;
  playtime_seconds: number;
  playtime_reset_at: string;
  created_at: string;
  updated_at: string;
}

export function useProfile() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Subscribe to real-time profile changes
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel(`profile-realtime-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "profiles",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          // Invalidate profile query when any field (including premium_tier) changes
          queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient]);

  return useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async (): Promise<Profile | null> => {
      if (!user) return null;

      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      return data as Profile | null;
    },
    enabled: !!user,
  });
}

export function useUpdateProfile() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (updates: Partial<Profile>) => {
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("profiles")
        .update(updates)
        .eq("user_id", user.id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile", user?.id] });
    },
  });
}

// Calculate current energy based on regeneration
export function calculateCurrentEnergy(profile: Profile): number {
  const now = new Date();
  const lastUpdate = new Date(profile.energy_updated_at);
  const minutesPassed = (now.getTime() - lastUpdate.getTime()) / 60000;
  
  let regenRate = 1; // Base: 1 energy per minute
  if (profile.premium_tier === "pro") regenRate = 3;
  else if (profile.premium_tier === "advance") regenRate = 2;
  else if (profile.premium_tier === "basic") regenRate = 1.5;
  
  const energyGained = Math.floor(minutesPassed * regenRate);
  return Math.min(profile.energy + energyGained, profile.max_energy);
}

// All users have unlimited playtime
export function calculateCurrentPlaytime(_profile: Profile): number {
  return 0; // Unlimited - no tracking needed
}

export function shouldResetPlaytime(_profile: Profile): boolean {
  return false; // No resets needed - unlimited playtime
}
