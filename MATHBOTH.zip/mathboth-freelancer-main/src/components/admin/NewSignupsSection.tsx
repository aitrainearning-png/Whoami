import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { UserPlus, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function NewSignupsSection() {
  const { data: newSignups, isLoading } = useQuery({
    queryKey: ["admin", "new-signups-today"],
    queryFn: async () => {
      // Get start of today in UTC
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from("profiles")
        .select("id, display_name, email, created_at, balance, total_earned")
        .gte("created_at", today.toISOString())
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
    refetchInterval: 60000, // Refresh every minute
  });

  return (
    <Card className="border-0 shadow-soft">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <UserPlus className="w-5 h-5 text-success" />
          New Signups Today
          {newSignups && (
            <span className="ml-auto text-sm font-normal text-muted-foreground">
              {newSignups.length} new users
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : newSignups?.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No new signups today
          </p>
        ) : (
          <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">Earned</TableHead>
                  <TableHead className="text-right">Signed Up</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {newSignups?.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      {user.display_name || "Unknown"}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {user.email || "No email"}
                    </TableCell>
                    <TableCell className="text-right font-medium text-sm">
                      ₱{(user.balance || 0).toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right font-medium text-sm text-success">
                      ₱{(user.total_earned || 0).toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="flex items-center justify-end gap-1 text-sm text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {user.created_at
                          ? formatDistanceToNow(new Date(user.created_at), {
                              addSuffix: true,
                            })
                          : "Unknown"}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
