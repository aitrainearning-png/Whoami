import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Briefcase, CheckCircle2, XCircle, DollarSign, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

export function ClientManagementSection() {
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [depositDialogOpen, setDepositDialogOpen] = useState(false);

  // Fetch all clients
  const { data: clients, isLoading } = useQuery({
    queryKey: ["admin", "clients"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select(`
          *,
          client_wallets(balance, total_deposited, total_spent)
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  // Fetch pending client deposits
  const { data: pendingDeposits } = useQuery({
    queryKey: ["admin", "client-deposits"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_transactions")
        .select(`
          *,
          clients(display_name, email, company_name)
        `)
        .eq("type", "deposit")
        .eq("status", "pending")
        .order("created_at", { ascending: true });

      if (error) throw error;
      return data;
    },
  });

  // Update client status mutation
  const updateClientStatus = useMutation({
    mutationFn: async ({ clientId, status }: { clientId: string; status: "pending" | "approved" | "suspended" }) => {
      const { error } = await supabase
        .from("clients")
        .update({ status })
        .eq("id", clientId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "clients"] });
      toast.success("Client status updated!");
    },
    onError: () => {
      toast.error("Failed to update client status");
    },
  });

  // Process deposit mutation
  const processDeposit = useMutation({
    mutationFn: async ({ txId, action, clientId, amount }: { txId: string; action: "approve" | "reject"; clientId: string; amount: number }) => {
      const status = action === "approve" ? "approved" : "rejected";

      const { error: txError } = await supabase
        .from("client_transactions")
        .update({
          status,
          processed_at: new Date().toISOString(),
        })
        .eq("id", txId);

      if (txError) throw txError;

      // If approved, update wallet balance
      if (action === "approve") {
        const { data: wallet } = await supabase
          .from("client_wallets")
          .select("balance, total_deposited")
          .eq("client_id", clientId)
          .single();

        if (wallet) {
          await supabase
            .from("client_wallets")
            .update({
              balance: wallet.balance + amount,
              total_deposited: wallet.total_deposited + amount,
            })
            .eq("client_id", clientId);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "client-deposits"] });
      queryClient.invalidateQueries({ queryKey: ["admin", "clients"] });
      toast.success("Deposit processed!");
    },
    onError: () => {
      toast.error("Failed to process deposit");
    },
  });

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: "bg-yellow-500/20 text-yellow-600",
      approved: "bg-green-500/20 text-green-600",
      suspended: "bg-red-500/20 text-red-600",
    };
    return <Badge className={styles[status as keyof typeof styles]}>{status}</Badge>;
  };

  const filteredClients = clients?.filter(
    (c) =>
      c.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.company_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Pending Deposits */}
      {pendingDeposits && pendingDeposits.length > 0 && (
        <Card className="border-yellow-500/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-yellow-500" />
              Pending Client Deposits ({pendingDeposits.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingDeposits.map((deposit) => (
              <div key={deposit.id} className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <p className="font-medium">
                    {deposit.clients?.display_name || deposit.clients?.email}
                  </p>
                  {deposit.clients?.company_name && (
                    <p className="text-sm text-muted-foreground">{deposit.clients.company_name}</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(deposit.created_at), "MMM d, yyyy h:mm a")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">₱{Number(deposit.amount).toFixed(2)}</p>
                  <div className="flex gap-1 mt-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-destructive border-destructive"
                      onClick={() =>
                        processDeposit.mutate({
                          txId: deposit.id,
                          action: "reject",
                          clientId: deposit.client_id,
                          amount: Number(deposit.amount),
                        })
                      }
                    >
                      <XCircle className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      className="h-7 px-2 bg-green-600 hover:bg-green-700"
                      onClick={() =>
                        processDeposit.mutate({
                          txId: deposit.id,
                          action: "approve",
                          clientId: deposit.client_id,
                          amount: Number(deposit.amount),
                        })
                      }
                    >
                      <CheckCircle2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Client List */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Clients ({clients?.length || 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search clients..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {isLoading ? (
            <p className="text-center text-muted-foreground py-4">Loading...</p>
          ) : filteredClients?.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">No clients found</p>
          ) : (
            <div className="space-y-3">
              {filteredClients?.map((client) => (
                <div
                  key={client.id}
                  className="flex items-center justify-between rounded-lg border p-3"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{client.display_name || client.email}</p>
                      {getStatusBadge(client.status)}
                    </div>
                    {client.company_name && (
                      <p className="text-sm text-muted-foreground">{client.company_name}</p>
                    )}
                    <p className="text-xs text-muted-foreground">{client.email}</p>
                    <p className="text-sm font-medium text-primary mt-1">
                      Balance: ₱{client.client_wallets?.[0]?.balance?.toFixed(2) || "0.00"}
                    </p>
                  </div>
                  <div>
                    <Select
                      value={client.status}
                      onValueChange={(value) =>
                        updateClientStatus.mutate({
                          clientId: client.id,
                          status: value as "pending" | "approved" | "suspended",
                        })
                      }
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="suspended">Suspended</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
