import { useState } from "react";
import { Megaphone, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAdminAnnouncements } from "@/hooks/useAdminAnnouncements";
import { toast } from "sonner";

export function AnnouncementSection() {
  const [message, setMessage] = useState("");
  const { sendAnnouncement, isSending } = useAdminAnnouncements();

  const handleSend = () => {
    if (!message.trim()) {
      toast.error("Please enter a message");
      return;
    }

    sendAnnouncement(message.trim(), {
      onSuccess: () => {
        toast.success("Announcement sent to all users!");
        setMessage("");
      },
      onError: () => {
        toast.error("Failed to send announcement");
      },
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Megaphone className="w-5 h-5 text-primary" />
          Send Announcement
        </CardTitle>
        <CardDescription>
          Broadcast a message to all users. They must read it for 5 seconds before dismissing.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your announcement message here..."
          className="min-h-[120px] resize-none"
          maxLength={1000}
        />
        
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {message.length}/1000 characters
          </span>
          
          <Button
            onClick={handleSend}
            disabled={!message.trim() || isSending}
            className="gap-2"
          >
            {isSending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Send to All Users
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
