import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageCircle, MessageCircleOff, Trash2, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export function ChatControlSection() {
  const queryClient = useQueryClient();

  // Fetch chat enabled status
  const { data: chatEnabled, isLoading } = useQuery({
    queryKey: ["app-settings", "chat_enabled"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("value")
        .eq("key", "chat_enabled")
        .single();

      if (error) throw error;
      return (data?.value as { enabled: boolean })?.enabled ?? true;
    },
  });

  // Toggle chat mutation
  const toggleChat = useMutation({
    mutationFn: async (enabled: boolean) => {
      const { error } = await supabase
        .from("app_settings")
        .update({ 
          value: { enabled },
          updated_at: new Date().toISOString()
        })
        .eq("key", "chat_enabled");

      if (error) throw error;
    },
    onSuccess: (_, enabled) => {
      queryClient.invalidateQueries({ queryKey: ["app-settings", "chat_enabled"] });
      toast.success(enabled ? "Chat enabled for all users" : "Chat disabled - only admins can send messages");
    },
    onError: (error) => {
      toast.error("Failed to update chat settings: " + error.message);
    },
  });

  // Delete all chat messages mutation
  const deleteAllMessages = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("chat_messages")
        .delete()
        .gte("id", "00000000-0000-0000-0000-000000000000"); // Delete all rows

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chat-messages"] });
      toast.success("All chat messages deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete messages: " + error.message);
    },
  });

  if (isLoading) {
    return (
      <Card className="border-0 shadow-soft">
        <CardHeader className="pb-3">
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-10 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-soft">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          {chatEnabled ? (
            <MessageCircle className="w-5 h-5 text-success" />
          ) : (
            <MessageCircleOff className="w-5 h-5 text-destructive" />
          )}
          Chat Control
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="chat-toggle" className="text-sm font-medium">
              Community Chat
            </Label>
            <p className="text-xs text-muted-foreground">
              {chatEnabled 
                ? "All users can send messages" 
                : "Only admins can send messages"}
            </p>
          </div>
          <Switch
            id="chat-toggle"
            checked={chatEnabled}
            onCheckedChange={(checked) => toggleChat.mutate(checked)}
            disabled={toggleChat.isPending}
          />
        </div>

        {/* Delete All Chat Messages */}
        <div className="pt-2 border-t border-border">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                variant="destructive" 
                size="sm" 
                className="w-full"
                disabled={deleteAllMessages.isPending}
              >
                {deleteAllMessages.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4 mr-2" />
                )}
                Delete All Chat Messages
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete All Messages?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. All chat messages will be permanently deleted.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => deleteAllMessages.mutate()}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Delete All
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
}
