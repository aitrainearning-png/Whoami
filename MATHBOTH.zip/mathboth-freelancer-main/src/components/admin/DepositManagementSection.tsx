import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle2, XCircle, ArrowDownLeft, Image as ImageIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export function DepositManagementSection() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: deposits, isLoading } = useQuery({
    queryKey: ["admin", "deposits"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*, profiles!transactions_user_id_fkey(display_name, email)")
        .eq("type", "deposit")
        .eq("status", "pending")
        .order("created_at", { ascending: true });

      if (error) throw error;
      return data;
    },
    refetchInterval: 10000,
  });

  const depositMutation = useMutation({
    mutationFn: async ({ 
      id, 
      action, 
      userId, 
      amount 
    }: { 
      id: string; 
      action: "approve" | "reject"; 
      userId: string; 
      amount: number;
    }) => {
      const status = action === "approve" ? "approved" : "rejected";
      
      const { error: txError } = await supabase
        .from("transactions")
        .update({ 
          status, 
          processed_at: new Date().toISOString(),
          processed_by: user?.id 
        })
        .eq("id", id);

      if (txError) throw txError;

      // If approved, add to user balance
      if (action === "approve") {
        const { data: profile } = await supabase
          .from("profiles")
          .select("balance")
          .eq("user_id", userId)
          .single();
        
        if (profile) {
          await supabase
            .from("profiles")
            .update({ 
              balance: profile.balance + amount,
            })
            .eq("user_id", userId);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "deposits"] });
      queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      toast.success("Deposit request updated!");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  return (
    <div className="space-y-3">
      {isLoading ? (
        <>
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
        </>
      ) : deposits?.length === 0 ? (
        <Card className="border-0 shadow-soft">
          <CardContent className="p-8 text-center">
            <CheckCircle2 className="w-12 h-12 mx-auto text-success mb-3" />
            <p className="text-muted-foreground">No pending deposits</p>
          </CardContent>
        </Card>
      ) : (
        deposits?.map((tx: any) => (
          <Card key={tx.id} className="border-0 shadow-soft">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-semibold text-foreground">
                    {tx.profiles?.display_name || tx.profiles?.email || 'Unknown'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {tx.payment_method}: {tx.payment_details}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(tx.created_at), { addSuffix: true })}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-success">+₱{Number(tx.amount).toFixed(2)}</p>
                  {tx.payment_proof_url && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="mt-1">
                          <ImageIcon className="w-4 h-4 mr-1" />
                          View Proof
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Payment Proof</DialogTitle>
                        </DialogHeader>
                        <img 
                          src={tx.payment_proof_url} 
                          alt="Payment proof" 
                          className="w-full rounded-lg"
                        />
                      </DialogContent>
                    </Dialog>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => depositMutation.mutate({ 
                    id: tx.id, 
                    action: "reject",
                    userId: tx.user_id,
                    amount: Number(tx.amount)
                  })}
                  disabled={depositMutation.isPending}
                  className="flex-1 border-destructive text-destructive hover:bg-destructive/10"
                >
                  <XCircle className="w-4 h-4 mr-1" />
                  Reject
                </Button>
                <Button
                  size="sm"
                  onClick={() => depositMutation.mutate({ 
                    id: tx.id, 
                    action: "approve",
                    userId: tx.user_id,
                    amount: Number(tx.amount)
                  })}
                  disabled={depositMutation.isPending}
                  className="flex-1 bg-success hover:bg-success/90"
                >
                  <CheckCircle2 className="w-4 h-4 mr-1" />
                  Approve
                </Button>
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
}
