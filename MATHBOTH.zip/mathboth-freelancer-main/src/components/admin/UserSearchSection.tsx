import { useState } from "react";
import { Search, Copy, Crown, Ban, ShieldOff } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface UserResult {
  id: string;
  user_id: string;
  display_name: string | null;
  email: string | null;
  referral_code: string;
  premium_tier: string | null;
  is_banned?: boolean;
}

export function UserSearchSection() {
  const { user: adminUser } = useAuth();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<UserResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [updatingTier, setUpdatingTier] = useState<string | null>(null);

  // Ban dialog state
  const [banDialogUser, setBanDialogUser] = useState<UserResult | null>(null);
  const [banType, setBanType] = useState<"permanent" | "temporary">("temporary");
  const [banDuration, setBanDuration] = useState("3");
  const [banDurationUnit, setBanDurationUnit] = useState<"hours" | "days">("hours");
  const [banReason, setBanReason] = useState("");
  const [isBanning, setIsBanning] = useState(false);

  const handleSearch = async () => {
    const trimmed = query.trim();
    if (!trimmed) return;

    setIsSearching(true);
    setHasSearched(true);

    const { data, error } = await supabase
      .from("profiles")
      .select("id, user_id, display_name, email, referral_code, premium_tier")
      .or(`email.ilike.%${trimmed}%,display_name.ilike.%${trimmed}%,referral_code.ilike.%${trimmed}%`)
      .limit(20);

    if (error) {
      toast.error("Search failed");
      console.error(error);
      setIsSearching(false);
      return;
    }

    // Check ban status for each user
    const usersWithBanStatus = await Promise.all(
      (data || []).map(async (u) => {
        const { data: banData } = await supabase
          .from("user_bans")
          .select("id, ban_type, expires_at")
          .eq("user_id", u.user_id)
          .eq("is_active", true)
          .limit(1);

        const activeBan = banData?.find(
          (b) => b.ban_type === "permanent" || (b.expires_at && new Date(b.expires_at) > new Date())
        );

        return { ...u, is_banned: !!activeBan };
      })
    );

    setResults(usersWithBanStatus);
    setIsSearching(false);
  };

  const handleBanUser = async () => {
    if (!banDialogUser || !banReason.trim() || !adminUser) return;

    setIsBanning(true);

    let expiresAt: string | null = null;
    if (banType === "temporary") {
      const now = new Date();
      const durationNum = parseInt(banDuration) || 1;
      if (banDurationUnit === "hours") {
        now.setHours(now.getHours() + durationNum);
      } else {
        now.setDate(now.getDate() + durationNum);
      }
      expiresAt = now.toISOString();
    }

    const { error } = await supabase.from("user_bans").insert({
      user_id: banDialogUser.user_id,
      banned_by: adminUser.id,
      ban_type: banType,
      reason: banReason.trim(),
      expires_at: expiresAt,
    });

    if (error) {
      toast.error("Failed to ban user");
      console.error(error);
    } else {
      const durationText = banType === "permanent" 
        ? "permanently" 
        : `for ${banDuration} ${banDurationUnit}`;
      toast.success(`${banDialogUser.display_name || banDialogUser.email} banned ${durationText}`);
      setResults(prev => prev.map(u => u.id === banDialogUser.id ? { ...u, is_banned: true } : u));
    }

    setIsBanning(false);
    setBanDialogUser(null);
    setBanReason("");
    setBanType("temporary");
    setBanDuration("3");
  };

  const handleUnbanUser = async (userResult: UserResult) => {
    const { error } = await supabase
      .from("user_bans")
      .update({ is_active: false })
      .eq("user_id", userResult.user_id)
      .eq("is_active", true);

    if (error) {
      toast.error("Failed to unban user");
    } else {
      toast.success(`${userResult.display_name || userResult.email} unbanned`);
      setResults(prev => prev.map(u => u.id === userResult.id ? { ...u, is_banned: false } : u));
    }
  };

  const handleSetTier = async (userId: string, profileId: string, tier: string) => {
    setUpdatingTier(profileId);
    const tierValue = tier === "free" ? null : tier;
    
    const updateData: any = { premium_tier: tierValue };
    
    if (tier !== "free") {
      const { data: tierSettings } = await supabase
        .from("tier_settings")
        .select("duration_days")
        .eq("tier", tier as "basic" | "advance" | "pro")
        .single();

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + (tierSettings?.duration_days || 30));
      updateData.premium_expires_at = expiresAt.toISOString();
    } else {
      updateData.premium_expires_at = null;
    }

    const { error } = await supabase
      .from("profiles")
      .update(updateData)
      .eq("user_id", userId);

    if (error) {
      toast.error("Failed to update tier");
    } else {
      toast.success(`Premium tier updated to ${tier}`);
      setResults(prev => prev.map(u => u.id === profileId ? { ...u, premium_tier: tierValue } : u));
    }
    setUpdatingTier(null);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied!");
  };

  return (
    <>
      <Card className="border-0 shadow-soft">
        <CardContent className="p-4">
          <p className="text-sm font-semibold text-foreground mb-3">🔍 User Search</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch();
            }}
            className="flex gap-2 mb-3"
          >
            <Input
              placeholder="Search email, name, or referral code..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" size="sm" disabled={isSearching || !query.trim()}>
              <Search className="w-4 h-4" />
            </Button>
          </form>

          {isSearching && (
            <p className="text-sm text-muted-foreground text-center py-4">Searching...</p>
          )}

          {!isSearching && hasSearched && results.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">No users found</p>
          )}

          {results.length > 0 && (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {results.map((user) => (
                <div
                  key={user.id}
                  className={`p-3 rounded-lg space-y-2 ${user.is_banned ? "bg-destructive/10 border border-destructive/20" : "bg-muted/50"}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-foreground truncate">
                          {user.display_name || "No name"}
                        </p>
                        {user.is_banned && (
                          <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-destructive/20 text-destructive">
                            BANNED
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">{user.email || "No email"}</p>
                      <p className="text-xs font-mono text-primary mt-0.5">{user.referral_code}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0"
                      onClick={() =>
                        copyToClipboard(
                          `${user.display_name || ""} | ${user.email || ""} | ${user.referral_code}`
                        )
                      }
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <Crown className="w-3.5 h-3.5 text-gold shrink-0" />
                    <Select
                      value={user.premium_tier || "free"}
                      onValueChange={(val) => handleSetTier(user.user_id, user.id, val)}
                      disabled={updatingTier === user.id}
                    >
                      <SelectTrigger className="h-7 text-xs flex-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="free">Free</SelectItem>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="advance">Advance</SelectItem>
                        <SelectItem value="pro">Pro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2">
                    {user.is_banned ? (
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 h-7 text-xs text-success border-success hover:bg-success/10"
                        onClick={() => handleUnbanUser(user)}
                      >
                        <ShieldOff className="w-3 h-3 mr-1" />
                        Unban
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 h-7 text-xs text-destructive border-destructive hover:bg-destructive/10"
                        onClick={() => setBanDialogUser(user)}
                      >
                        <Ban className="w-3 h-3 mr-1" />
                        Ban User
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Ban Dialog */}
      <Dialog open={!!banDialogUser} onOpenChange={() => setBanDialogUser(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Ban className="w-5 h-5 text-destructive" />
              Ban User
            </DialogTitle>
            <DialogDescription>
              Ban {banDialogUser?.display_name || banDialogUser?.email}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label>Ban Type</Label>
              <Select value={banType} onValueChange={(v) => setBanType(v as "permanent" | "temporary")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="temporary">Temporary</SelectItem>
                  <SelectItem value="permanent">Permanent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {banType === "temporary" && (
              <div className="space-y-2">
                <Label>Duration</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min="1"
                    value={banDuration}
                    onChange={(e) => setBanDuration(e.target.value)}
                    className="flex-1"
                  />
                  <Select value={banDurationUnit} onValueChange={(v) => setBanDurationUnit(v as "hours" | "days")}>
                    <SelectTrigger className="w-28">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hours">Hours</SelectItem>
                      <SelectItem value="days">Days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>Reason</Label>
              <Textarea
                placeholder="Enter the reason for banning this user..."
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                rows={3}
              />
            </div>

            <Button
              onClick={handleBanUser}
              disabled={isBanning || !banReason.trim()}
              className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              {isBanning ? "Banning..." : banType === "permanent" ? "Ban Permanently" : `Ban for ${banDuration} ${banDurationUnit}`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
