import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { MessageSquare, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { formatDistanceToNow } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AdminMessageDialog } from "./AdminMessageDialog";

function isUserOnline(lastActiveAt: string | null): boolean {
  if (!lastActiveAt) return false;
  const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);
  return new Date(lastActiveAt) > twoMinutesAgo;
}

interface ConversationUser {
  user_id: string;
  profile_id: string;
  display_name: string | null;
  email: string | null;
  last_active_at: string | null;
  last_message: string;
  last_message_at: string;
  unread_count: number;
}

export function ConversationListSection() {
  const { user } = useAuth();
  const [messageTarget, setMessageTarget] = useState<{
    id: string;
    user_id: string;
    display_name: string | null;
    email: string | null;
  } | null>(null);
  const [messageOpen, setMessageOpen] = useState(false);

  const { data: conversations, isLoading } = useQuery({
    queryKey: ["admin", "conversations"],
    queryFn: async () => {
      if (!user) return [];

      // Get all DMs involving this admin
      const { data: dms, error } = await supabase
        .from("direct_messages")
        .select("*")
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order("created_at", { ascending: false });

      if (error) throw error;
      if (!dms || dms.length === 0) return [];

      // Extract unique user IDs (the other party)
      const userMap = new Map<string, { lastMsg: typeof dms[0]; unread: number }>();
      for (const dm of dms) {
        const otherId = dm.sender_id === user.id ? dm.receiver_id : dm.sender_id;
        if (!userMap.has(otherId)) {
          userMap.set(otherId, { lastMsg: dm, unread: 0 });
        }
        if (dm.receiver_id === user.id && !dm.is_read) {
          const entry = userMap.get(otherId)!;
          entry.unread++;
        }
      }

      // Fetch profiles for these users
      const userIds = Array.from(userMap.keys());
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, user_id, display_name, email, last_active_at")
        .in("user_id", userIds);

      const result: ConversationUser[] = [];
      for (const [uid, info] of userMap) {
        const profile = profiles?.find(p => p.user_id === uid);
        result.push({
          user_id: uid,
          profile_id: profile?.id || "",
          display_name: profile?.display_name || null,
          email: profile?.email || null,
          last_active_at: profile?.last_active_at || null,
          last_message: info.lastMsg.message,
          last_message_at: info.lastMsg.created_at,
          unread_count: info.unread,
        });
      }

      // Sort by last message time (newest first)
      result.sort((a, b) => new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime());
      return result;
    },
    enabled: !!user,
    refetchInterval: 5000,
  });

  return (
    <Card className="border-0 shadow-soft">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <MessageSquare className="w-5 h-5 text-primary" />
          My Conversations
          {conversations && conversations.length > 0 && (
            <span className="ml-auto text-sm font-normal text-muted-foreground">
              {conversations.length} users
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : !conversations || conversations.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No conversations yet. Message a user from the Active Users section.
          </p>
        ) : (
          <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Last Message</TableHead>
                  <TableHead className="text-right">Time</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {conversations.map((conv) => {
                  const online = isUserOnline(conv.last_active_at);
                  return (
                    <TableRow key={conv.user_id}>
                      <TableCell>
                        <span className={`relative flex h-3 w-3 ${online ? '' : 'opacity-40'}`}>
                          {online && (
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                          )}
                          <span className={`relative inline-flex rounded-full h-3 w-3 ${
                            online ? 'bg-success' : 'bg-muted-foreground'
                          }`}></span>
                        </span>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium text-sm">
                            {conv.display_name || "Unknown"}
                          </p>
                          <p className="text-xs text-muted-foreground">{conv.email || ""}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm text-muted-foreground truncate max-w-[150px]">
                          {conv.last_message}
                        </p>
                        {conv.unread_count > 0 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-bold text-primary-foreground bg-destructive rounded-full">
                            {conv.unread_count}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow(new Date(conv.last_message_at), { addSuffix: true })}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-primary"
                          onClick={() => {
                            setMessageTarget({
                              id: conv.profile_id,
                              user_id: conv.user_id,
                              display_name: conv.display_name,
                              email: conv.email,
                            });
                            setMessageOpen(true);
                          }}
                        >
                          Reply
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <AdminMessageDialog
        open={messageOpen}
        onOpenChange={setMessageOpen}
        targetUser={messageTarget}
      />
    </Card>
  );
}
