import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Users, Clock, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AdminMessageDialog } from "./AdminMessageDialog";

// Helper function to check if user is online (active within last 2 minutes)
function isUserOnline(lastActiveAt: string | null): boolean {
  if (!lastActiveAt) return false;
  const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);
  return new Date(lastActiveAt) > twoMinutesAgo;
}

export function ActiveUsersSection() {
  const [messageTarget, setMessageTarget] = useState<{
    id: string;
    user_id: string;
    display_name: string | null;
    email: string | null;
  } | null>(null);
  const [messageOpen, setMessageOpen] = useState(false);

  const { data: activeUsers, isLoading } = useQuery({
    queryKey: ["admin", "active-users-today"],
    queryFn: async () => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from("profiles")
        .select("id, user_id, display_name, email, last_active_at")
        .gte("last_active_at", today.toISOString())
        .order("last_active_at", { ascending: false });

      if (error) throw error;
      return data;
    },
    refetchInterval: 10000, // Refresh every 10 seconds for real-time feel
  });

  // Count online users (active in last 2 minutes)
  const onlineCount = activeUsers?.filter((user) => 
    isUserOnline(user.last_active_at)
  ).length || 0;

  return (
    <Card className="border-0 shadow-soft">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Users className="w-5 h-5 text-primary" />
          Active Users Today
          <span className="flex items-center gap-1 ml-2 text-sm font-normal text-success">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
            </span>
            {onlineCount} online
          </span>
          {activeUsers && (
            <span className="ml-auto text-sm font-normal text-muted-foreground">
              {activeUsers.length} total today
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : activeUsers?.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No active users today
          </p>
        ) : (
          <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Username</TableHead>
                  <TableHead>Email</TableHead>
                   <TableHead className="text-right">Last Active</TableHead>
                   <TableHead className="text-right">Msg</TableHead>
                 </TableRow>
              </TableHeader>
              <TableBody>
                {activeUsers?.map((user) => {
                  const online = isUserOnline(user.last_active_at);
                  return (
                    <TableRow key={user.id}>
                      <TableCell>
                        <span className="flex items-center gap-2">
                          <span 
                            className={`relative flex h-3 w-3 ${online ? '' : 'opacity-40'}`}
                            title={online ? "Online" : "Offline"}
                          >
                            {online && (
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                            )}
                            <span className={`relative inline-flex rounded-full h-3 w-3 ${
                              online ? 'bg-success' : 'bg-muted-foreground'
                            }`}></span>
                          </span>
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">
                        {user.display_name || "Unknown"}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {user.email || "No email"}
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="flex items-center justify-end gap-1 text-sm text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {user.last_active_at
                            ? formatDistanceToNow(new Date(user.last_active_at), {
                                addSuffix: true,
                              })
                            : "Never"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => {
                            setMessageTarget({
                              id: user.id,
                              user_id: user.user_id,
                              display_name: user.display_name,
                              email: user.email,
                            });
                            setMessageOpen(true);
                          }}
                        >
                          <MessageCircle className="w-4 h-4 text-primary" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <AdminMessageDialog
        open={messageOpen}
        onOpenChange={setMessageOpen}
        targetUser={messageTarget}
      />
    </Card>
  );
}
