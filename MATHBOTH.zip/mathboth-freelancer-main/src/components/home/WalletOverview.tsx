import { ArrowUpRight, Plus, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

interface WalletOverviewProps {
  balance: number;
  totalEarned: number;
  onWithdraw: () => void;
  onDeposit: () => void;
}

export function WalletOverview({ balance, totalEarned, onWithdraw, onDeposit }: WalletOverviewProps) {
  return (
    <div className="rounded-2xl bg-gradient-primary p-5 text-primary-foreground shadow-glow animate-fade-up">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-xs font-medium opacity-80 tracking-wide uppercase">Total Balance</p>
          <p className="text-3xl font-extrabold mt-1 tracking-tight">₱{balance.toFixed(2)}</p>
        </div>
        <div className="flex items-center gap-1.5 bg-primary-foreground/15 rounded-full px-2.5 py-1">
          <TrendingUp className="w-3 h-3" />
          <span className="text-[11px] font-semibold">₱{totalEarned.toFixed(2)} earned</span>
        </div>
      </div>

      <div className="flex gap-2.5">
        <Button
          onClick={onWithdraw}
          size="sm"
          className="flex-1 bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground border-0 backdrop-blur-sm h-9 text-xs font-semibold"
        >
          <ArrowUpRight className="w-3.5 h-3.5 mr-1.5" />
          Withdraw
        </Button>
        <Button
          onClick={onDeposit}
          size="sm"
          className="flex-1 bg-primary-foreground text-primary hover:bg-primary-foreground/90 border-0 h-9 text-xs font-semibold"
        >
          <Plus className="w-3.5 h-3.5 mr-1.5" />
          Upgrade
        </Button>
      </div>
    </div>
  );
}
