import { useState, useEffect } from "react";
import { Clock, Crown, Infinity as InfinityIcon } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface PlaytimeTimerProps {
  playtimeResetAt: string;
  isPremium: boolean;
  premiumExpiresAt?: string | null;
  showDetails?: boolean;
}

export function PlaytimeTimer({ 
  playtimeResetAt, 
  isPremium,
  premiumExpiresAt,
  showDetails = false 
}: PlaytimeTimerProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Premium users: Show days remaining until expiration
  if (isPremium) {
    const getDaysRemaining = (): { days: number; hours: number; minutes: number } => {
      if (!premiumExpiresAt) {
        return { days: 0, hours: 0, minutes: 0 };
      }
      const expiresAt = new Date(premiumExpiresAt);
      const msRemaining = expiresAt.getTime() - currentTime.getTime();
      if (msRemaining <= 0) {
        return { days: 0, hours: 0, minutes: 0 };
      }
      const days = Math.floor(msRemaining / (1000 * 60 * 60 * 24));
      const hours = Math.floor((msRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((msRemaining % (1000 * 60 * 60)) / (1000 * 60));
      return { days, hours, minutes };
    };

    const { days, hours, minutes } = getDaysRemaining();
    const isExpired = days === 0 && hours === 0 && minutes === 0 && premiumExpiresAt;
    const isExpiringSoon = days <= 3 && !isExpired;

    const formatTimeRemaining = (): string => {
      if (isExpired) return "Expired";
      if (days > 0) return `${days}d ${hours}h left`;
      return `${hours}h ${minutes}m left`;
    };

    return (
      <div className="bg-card/80 backdrop-blur-sm rounded-xl px-4 py-3 shadow-soft">
        <div className="flex items-center gap-3">
          <div className={cn(
            "flex items-center justify-center w-10 h-10 rounded-full",
            isExpired ? "bg-destructive/10" : isExpiringSoon ? "bg-warning/10" : "bg-gradient-to-br from-primary/20 to-success/20"
          )}>
            <Crown className={cn("w-5 h-5", isExpired ? "text-destructive" : isExpiringSoon ? "text-warning" : "text-primary")} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-foreground">Premium</span>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 h-4", isExpired ? "border-destructive/50 text-destructive" : isExpiringSoon ? "border-warning/50 text-warning" : "border-primary/50 text-primary")}>
                  {isExpired ? "Expired" : "Unlimited Play"}
                </Badge>
              </div>
              <span className={cn("text-sm font-semibold", isExpired ? "text-destructive" : isExpiringSoon ? "text-warning" : "text-primary")}>
                {formatTimeRemaining()}
              </span>
            </div>
            <Progress value={isExpired ? 0 : 100} className={cn("h-2 bg-muted", isExpired ? "[&>div]:bg-destructive" : isExpiringSoon ? "[&>div]:bg-gradient-to-r [&>div]:from-warning [&>div]:to-destructive" : "[&>div]:bg-gradient-to-r [&>div]:from-primary [&>div]:to-success")} />
          </div>
        </div>
        {showDetails && premiumExpiresAt && !isExpired && (
          <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border/50">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Crown className="w-3.5 h-3.5" />
              <span>Expires: {new Date(premiumExpiresAt).toLocaleDateString()}</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Free users: Unlimited playtime
  return (
    <div className="bg-card/80 backdrop-blur-sm rounded-xl px-4 py-3 shadow-soft">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
          <InfinityIcon className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-foreground">Playtime</span>
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-primary/50 text-primary">
                Unlimited
              </Badge>
            </div>
            <span className="text-sm font-semibold text-primary">
              Play anytime
            </span>
          </div>
          <Progress value={100} className="h-2 bg-muted [&>div]:bg-gradient-to-r [&>div]:from-primary [&>div]:to-success" />
        </div>
      </div>
    </div>
  );
}
