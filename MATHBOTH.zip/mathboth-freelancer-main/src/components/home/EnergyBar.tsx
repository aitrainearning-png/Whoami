import { Zap, Clock, TrendingUp } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { getPremiumBenefits } from "@/hooks/useGameSession";
import { cn } from "@/lib/utils";

interface EnergyBarProps {
  current: number;
  max: number;
  premiumTier?: string | null;
  showDetails?: boolean;
}

export function EnergyBar({ current, max, premiumTier, showDetails = false }: EnergyBarProps) {
  const percentage = Math.round((current / max) * 100);
  const benefits = getPremiumBenefits(premiumTier || null);
  
  // Calculate time to full energy
  const energyNeeded = max - current;
  const minutesToFull = energyNeeded > 0 ? Math.ceil(energyNeeded / benefits.regenRate) : 0;
  const hoursToFull = Math.floor(minutesToFull / 60);
  const remainingMins = minutesToFull % 60;

  return (
    <div className="bg-card/80 backdrop-blur-sm rounded-xl px-4 py-3 shadow-soft">
      <div className="flex items-center gap-3">
        <div className={cn(
          "flex items-center justify-center w-10 h-10 rounded-full",
          premiumTier ? "bg-gradient-to-br from-energy/20 to-primary/20" : "bg-energy/10"
        )}>
          <Zap className="w-5 h-5 text-energy" fill="currentColor" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-foreground">Energy</span>
              {premiumTier && (
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-primary/50 text-primary">
                  {benefits.regenRate}x regen
                </Badge>
              )}
            </div>
            <span className="text-sm font-semibold text-energy">
              {current}/{max}
            </span>
          </div>
          <Progress 
            value={percentage} 
            className="h-2 bg-muted [&>div]:bg-gradient-to-r [&>div]:from-energy [&>div]:to-primary"
          />
        </div>
      </div>
      
      {showDetails && current < max && (
        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border/50">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Clock className="w-3.5 h-3.5" />
            <span>
              Full in {hoursToFull > 0 ? `${hoursToFull}h ` : ''}{remainingMins}m
            </span>
          </div>
          {premiumTier && benefits.energyDiscount > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-success">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{Math.round(benefits.energyDiscount * 100)}% less energy cost</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
