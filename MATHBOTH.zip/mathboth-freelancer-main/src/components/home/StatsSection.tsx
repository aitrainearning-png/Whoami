import { Gamepad2, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatsSectionProps {
  gamesPlayed: number;
  totalEarned: number;
}

export function StatsSection({ gamesPlayed, totalEarned }: StatsSectionProps) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <Card className="border-0 shadow-soft">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10">
              <Gamepad2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{gamesPlayed}</p>
              <p className="text-xs text-muted-foreground">Games Played</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-soft">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gold/10">
              <TrendingUp className="w-5 h-5 text-gold" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">₱{totalEarned.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">Total Earned</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
