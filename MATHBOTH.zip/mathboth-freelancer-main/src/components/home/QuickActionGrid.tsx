import { useNavigate } from "react-router-dom";
import { Gamepad2, ListTodo, Wallet } from "lucide-react";

const actions = [
  { icon: Gamepad2, label: "Games", path: "/games", color: "text-primary", bg: "bg-primary/10" },
  { icon: ListTodo, label: "Tasks", path: "/games", color: "text-accent", bg: "bg-accent/10" },
  { icon: Wallet, label: "Wallet", path: "/wallet", color: "text-gold", bg: "bg-gold/10" },
];

export function QuickActionGrid() {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-3 gap-2.5 animate-fade-up" style={{ animationDelay: "100ms" }}>
      {actions.map((a) => (
        <button
          key={a.label}
          onClick={() => navigate(a.path)}
          className="flex flex-col items-center gap-1.5 rounded-2xl bg-card py-3.5 shadow-soft hover:shadow-md transition-shadow active:scale-95"
        >
          <div className={`w-10 h-10 rounded-xl ${a.bg} flex items-center justify-center`}>
            <a.icon className={`w-5 h-5 ${a.color}`} />
          </div>
          <span className="text-[11px] font-medium text-foreground">{a.label}</span>
        </button>
      ))}
    </div>
  );
}
