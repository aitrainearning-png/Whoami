import { Coins, ArrowUpRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface BalanceCardProps {
  balance: number;
  onWithdraw: () => void;
  onUpgrade: () => void;
}

export function BalanceCard({ balance, onWithdraw, onUpgrade }: BalanceCardProps) {
  return (
    <Card className="overflow-hidden border-0 shadow-soft">
      <div className="bg-gradient-header p-6 text-primary-foreground">
        <div className="flex items-center gap-2 mb-2">
          <Coins className="w-5 h-5" />
          <span className="text-sm font-medium opacity-90">Available Balance</span>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-bold">₱{balance.toFixed(2)}</span>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Button 
            onClick={onWithdraw}
            className="flex-1 h-11 bg-primary hover:bg-primary/90"
          >
            <ArrowUpRight className="w-4 h-4 mr-2" />
            Withdraw
          </Button>
          <Button 
            onClick={onUpgrade}
            variant="outline"
            className="flex-1 h-11 border-gold text-gold hover:bg-gold/10"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Upgrade
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
