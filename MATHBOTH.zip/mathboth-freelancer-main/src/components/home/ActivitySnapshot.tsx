import { Gamepad2, Users, Zap } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ActivitySnapshotProps {
  gamesPlayed: number;
  referrals: number;
  energy: number;
  maxEnergy: number;
}

export function ActivitySnapshot({ gamesPlayed, referrals, energy, maxEnergy }: ActivitySnapshotProps) {
  const energyPct = Math.round((energy / maxEnergy) * 100);

  return (
    <div className="animate-fade-up" style={{ animationDelay: "200ms" }}>
      <h2 className="text-base font-semibold text-foreground mb-2">Your Activity</h2>
      <div className="grid grid-cols-3 gap-2.5">
        {/* Games */}
        <div className="rounded-2xl bg-card p-3 shadow-soft text-center">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-1.5">
            <Gamepad2 className="w-4 h-4 text-primary" />
          </div>
          <p className="text-lg font-bold text-foreground leading-tight">{gamesPlayed}</p>
          <p className="text-[10px] text-muted-foreground">Games</p>
        </div>

        {/* Referrals */}
        <div className="rounded-2xl bg-card p-3 shadow-soft text-center">
          <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-1.5">
            <Users className="w-4 h-4 text-accent" />
          </div>
          <p className="text-lg font-bold text-foreground leading-tight">{referrals}</p>
          <p className="text-[10px] text-muted-foreground">Referrals</p>
        </div>

        {/* Energy */}
        <div className="rounded-2xl bg-card p-3 shadow-soft text-center">
          <div className="w-8 h-8 rounded-lg bg-energy/10 flex items-center justify-center mx-auto mb-1.5">
            <Zap className="w-4 h-4 text-energy" />
          </div>
          <p className="text-lg font-bold text-foreground leading-tight">{energy}</p>
          <p className="text-[10px] text-muted-foreground mb-1.5">Energy</p>
          <Progress value={energyPct} className="h-1.5 bg-muted [&>div]:bg-energy" />
        </div>
      </div>
    </div>
  );
}
