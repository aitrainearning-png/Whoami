import { Target, Clock, Coins } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface DailyChallengeCardProps {
  title: string;
  description: string;
  progress: number;
  target: number;
  reward: number;
  timeRemaining: string;
  onStart: () => void;
  isCompleted?: boolean;
}

export function DailyChallengeCard({
  title,
  description,
  progress,
  target,
  reward,
  timeRemaining,
  onStart,
  isCompleted = false,
}: DailyChallengeCardProps) {
  const progressPercentage = Math.min((progress / target) * 100, 100);

  return (
    <Card className="border-0 shadow-soft overflow-hidden">
      <div className="h-1 bg-gradient-primary" />
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-accent/10">
              <Target className="w-4 h-4 text-accent" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground text-sm">{title}</h3>
              <p className="text-xs text-muted-foreground">{description}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-gold">
            <Coins className="w-4 h-4" />
            <span className="text-sm font-semibold">+₱{reward.toFixed(2)}</span>
          </div>
        </div>

        <div className="mb-3">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium text-foreground">{progress}/{target}</span>
          </div>
          <Progress 
            value={progressPercentage} 
            className="h-2 bg-muted [&>div]:bg-gradient-primary"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span className="text-xs">{timeRemaining}</span>
          </div>
          <Button 
            size="sm" 
            onClick={onStart}
            disabled={isCompleted}
            className={isCompleted ? "bg-success hover:bg-success" : "bg-gradient-header hover:opacity-90"}
          >
            {isCompleted ? "Completed" : "Start"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
