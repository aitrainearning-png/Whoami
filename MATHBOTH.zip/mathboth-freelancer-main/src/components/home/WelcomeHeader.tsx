import { Crown, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import mathbotLogo from "@/assets/mathbot-logo.png";

interface WelcomeHeaderProps {
  displayName: string;
  premiumTier: string | null;
  premiumExpiresAt: string | null;
}

export function WelcomeHeader({ displayName, premiumTier, premiumExpiresAt }: WelcomeHeaderProps) {
  const tierLabel = premiumTier && premiumTier !== "free"
    ? premiumTier.charAt(0).toUpperCase() + premiumTier.slice(1)
    : null;

  const getDaysLeft = () => {
    if (!premiumExpiresAt) return null;
    const ms = new Date(premiumExpiresAt).getTime() - Date.now();
    if (ms <= 0) return 0;
    return Math.ceil(ms / (1000 * 60 * 60 * 24));
  };

  const daysLeft = getDaysLeft();

  return (
    <div className="px-4 pt-6 pb-4">
      <div className="flex items-center gap-3">
        <img
          src={mathbotLogo}
          alt="MathBot"
          className="w-11 h-11 rounded-full object-cover ring-2 ring-primary/20"
        />
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground">Good {getGreeting()},</p>
          <h1 className="text-lg font-bold text-foreground truncate">{displayName} 👋</h1>
        </div>
        {tierLabel ? (
          <Badge className="bg-gradient-gold text-gold-foreground border-0 gap-1 text-xs font-semibold px-2.5 py-1 shadow-sm">
            <Crown className="w-3 h-3" />
            {tierLabel}
            {daysLeft !== null && daysLeft > 0 && (
              <span className="opacity-80 ml-0.5">· {daysLeft}d</span>
            )}
          </Badge>
        ) : (
          <Badge variant="outline" className="border-muted-foreground/30 text-muted-foreground gap-1 text-xs px-2.5 py-1">
            <Sparkles className="w-3 h-3" />
            Free
          </Badge>
        )}
      </div>
    </div>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}
