import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Send, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { formatDistanceToNow } from "date-fns";
import { useNavigate } from "react-router-dom";

export default function UserInbox() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [reply, setReply] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch all DMs for current user (conversations with admin)
  const { data: messages, isLoading } = useQuery({
    queryKey: ["user-inbox", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("direct_messages")
        .select("*")
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
    refetchInterval: 3000,
  });

  // Mark received messages as read
  useEffect(() => {
    if (!messages || !user) return;
    const unread = messages.filter(m => m.receiver_id === user.id && !m.is_read);
    if (unread.length > 0) {
      supabase
        .from("direct_messages")
        .update({ is_read: true })
        .in("id", unread.map(m => m.id))
        .then();
    }
  }, [messages, user]);

  // Scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Get the admin user id from messages (the other party)
  const adminId = messages?.find(m => m.sender_id !== user?.id)?.sender_id 
    || messages?.find(m => m.receiver_id !== user?.id)?.receiver_id;

  const sendMutation = useMutation({
    mutationFn: async (msg: string) => {
      if (!user || !adminId) throw new Error("Cannot reply - no conversation started");
      const { error } = await supabase.from("direct_messages").insert({
        sender_id: user.id,
        receiver_id: adminId,
        message: msg,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setReply("");
      queryClient.invalidateQueries({ queryKey: ["user-inbox", user?.id] });
    },
  });

  const handleSend = () => {
    const trimmed = reply.trim();
    if (!trimmed) return;
    sendMutation.mutate(trimmed);
  };

  // Count unread
  const unreadCount = messages?.filter(m => m.receiver_id === user?.id && !m.is_read).length || 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-header pt-safe px-4 pb-4">
        <div className="pt-6 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-primary-foreground hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary-foreground">Inbox</h1>
            <p className="text-primary-foreground/80 text-sm">Messages from Admin</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-4 flex flex-col" style={{ height: "calc(100vh - 120px)" }}>
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : !messages || messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <MessageCircle className="w-16 h-16 text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground">No messages yet</p>
            <p className="text-sm text-muted-foreground/70">Messages from admin will appear here</p>
          </div>
        ) : (
          <>
            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-2 mb-4">
              {messages.map((msg) => {
                const isMe = msg.sender_id === user?.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                      isMe
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-foreground"
                    }`}>
                      <p className="text-xs font-medium mb-1 opacity-70">
                        {isMe ? "You" : "Admin"}
                      </p>
                      <p className="whitespace-pre-wrap break-words">{msg.message}</p>
                      <p className={`text-xs mt-1 ${isMe ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                        {formatDistanceToNow(new Date(msg.created_at), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Reply input */}
            {adminId && (
              <div className="flex gap-2 border-t pt-3">
                <Textarea
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  placeholder="Reply to admin..."
                  className="min-h-[50px] max-h-[80px] resize-none"
                  onKeyDown={(e) => {
                    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                />
                <Button
                  size="icon"
                  onClick={handleSend}
                  disabled={!reply.trim() || sendMutation.isPending}
                  className="shrink-0 self-end"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
