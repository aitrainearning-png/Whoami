import { useEffect, useState } from "react";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface GameTimerProps {
  duration: number; // in seconds
  onTimeUp: () => void;
  isRunning: boolean;
}

export function GameTimer({ duration, onTimeUp, isRunning }: GameTimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    setTimeLeft(duration);
  }, [duration]);

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, onTimeUp, timeLeft]);

  const percentage = (timeLeft / duration) * 100;
  const isLow = timeLeft <= 10;
  const isCritical = timeLeft <= 5;

  return (
    <div className="relative">
      <div className="flex items-center gap-2 bg-card rounded-xl px-4 py-3 shadow-soft">
        <Clock className={cn(
          "w-5 h-5 transition-colors",
          isCritical ? "text-destructive animate-pulse" : 
          isLow ? "text-gold" : "text-muted-foreground"
        )} />
        <div className="flex-1">
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className={cn(
                "h-full transition-all duration-1000 ease-linear rounded-full",
                isCritical ? "bg-destructive" :
                isLow ? "bg-gold" : "bg-gradient-to-r from-primary to-accent"
              )}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
        <span className={cn(
          "text-lg font-bold tabular-nums min-w-[3ch]",
          isCritical ? "text-destructive" :
          isLow ? "text-gold" : "text-foreground"
        )}>
          {timeLeft}s
        </span>
      </div>
    </div>
  );
}
