import { Zap, Coins, Calculator } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface GameCardProps {
  id: string;
  name: string;
  icon: typeof Calculator;
  energyCost: number;
  minReward: number;
  maxReward: number;
  onPlay: (gameId: string) => void;
}

export function GameCard({ 
  id, 
  name, 
  icon: Icon, 
  energyCost, 
  minReward, 
  maxReward, 
  onPlay 
}: GameCardProps) {
  return (
    <Card className="border-0 shadow-soft overflow-hidden animate-fade-up">
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          {/* Game Icon */}
          <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-header">
            <Icon className="w-7 h-7 text-primary-foreground" />
          </div>

          {/* Game Info */}
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-foreground truncate">{name}</h3>
            
            <div className="flex items-center gap-3 mt-1">
              <div className="flex items-center gap-1 text-energy">
                <Zap className="w-3.5 h-3.5" fill="currentColor" />
                <span className="text-xs font-medium">{energyCost}</span>
              </div>
              <div className="flex items-center gap-1 text-gold">
                <Coins className="w-3.5 h-3.5" />
                <span className="text-xs font-medium">
                  ₱{minReward.toFixed(2)} - ₱{maxReward.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Play Button */}
          <Button 
            onClick={() => onPlay(id)}
            className="h-10 px-5 bg-primary hover:bg-primary/90"
          >
            Play
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
