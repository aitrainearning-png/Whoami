import { CheckCircle2, XCircle, Coins, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface GameResultProps {
  isSuccess: boolean;
  score: number;
  reward: number;
  onPlayAgain: () => void;
  onExit: () => void;
}

export function GameResult({ isSuccess, score, reward, onPlayAgain, onExit }: GameResultProps) {
  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <Card className={cn(
        "w-full max-w-sm border-0 shadow-glow animate-scale-in",
        isSuccess ? "ring-2 ring-success" : "ring-2 ring-destructive"
      )}>
        <CardContent className="p-6 text-center">
          <div className={cn(
            "w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center",
            isSuccess ? "bg-success/10" : "bg-destructive/10"
          )}>
            {isSuccess ? (
              <CheckCircle2 className="w-10 h-10 text-success" />
            ) : (
              <XCircle className="w-10 h-10 text-destructive" />
            )}
          </div>

          <h2 className={cn(
            "text-2xl font-bold mb-2",
            isSuccess ? "text-success" : "text-destructive"
          )}>
            {isSuccess ? "Great Job!" : "Time's Up!"}
          </h2>

          <p className="text-muted-foreground mb-6">
            {isSuccess 
              ? "You completed the challenge successfully!" 
              : "Better luck next time. Keep practicing!"}
          </p>

          {isSuccess && (
            <div className="flex items-center justify-center gap-6 mb-6 p-4 bg-muted/50 rounded-xl">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-primary mb-1">
                  <Trophy className="w-5 h-5" />
                </div>
                <p className="text-2xl font-bold">{score}</p>
                <p className="text-xs text-muted-foreground">Score</p>
              </div>
              <div className="h-12 w-px bg-border" />
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-gold mb-1">
                  <Coins className="w-5 h-5" />
                </div>
                <p className="text-2xl font-bold">+₱{reward.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground">Earned</p>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onExit}
              className="flex-1"
            >
              Exit
            </Button>
            <Button
              onClick={onPlayAgain}
              className="flex-1 bg-gradient-primary hover:opacity-90"
            >
              Play Again
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
