import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
  avatarUrl?: string | null;
  displayName?: string | null;
  size?: "sm" | "md" | "lg";
  showOnlineIndicator?: boolean;
  isOnline?: boolean;
  className?: string;
}

const sizeClasses = {
  sm: "w-8 h-8 text-xs",
  md: "w-10 h-10 text-sm",
  lg: "w-16 h-16 text-xl",
};

// Generate consistent background color based on first letter
const getAvatarColor = (letter: string): string => {
  const colors = [
    "from-primary to-primary/80",
    "from-purple-500 to-purple-400",
    "from-pink-500 to-pink-400",
    "from-indigo-500 to-indigo-400",
    "from-blue-500 to-blue-400",
    "from-emerald-500 to-emerald-400",
    "from-orange-500 to-orange-400",
    "from-rose-500 to-rose-400",
  ];
  const index = letter.toUpperCase().charCodeAt(0) % colors.length;
  return colors[index];
};

export function UserAvatar({
  avatarUrl,
  displayName,
  size = "md",
  showOnlineIndicator = false,
  isOnline = false,
  className,
}: UserAvatarProps) {
  const firstLetter = displayName?.charAt(0)?.toUpperCase() || "?";
  const colorClass = getAvatarColor(firstLetter);

  return (
    <div className="relative shrink-0">
      <Avatar className={cn(sizeClasses[size], className)}>
        {avatarUrl && (
          <AvatarImage src={avatarUrl} alt={displayName || "User"} />
        )}
        <AvatarFallback
          className={cn(
            "bg-gradient-to-br font-bold text-white",
            colorClass
          )}
        >
          {firstLetter}
        </AvatarFallback>
      </Avatar>
      
      {showOnlineIndicator && isOnline && (
        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
      )}
    </div>
  );
}
