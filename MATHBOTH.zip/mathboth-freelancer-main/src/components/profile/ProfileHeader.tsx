import { Crown, Copy } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Profile } from "@/hooks/useProfile";
import { AvatarUpload } from "./AvatarUpload";
import { toast } from "sonner";

interface ProfileHeaderProps {
  profile: Profile | null | undefined;
  email: string | undefined;
  isLoading: boolean;
  onAvatarUpdate?: (url: string) => void;
}

function getShortId(id: string | undefined): string {
  if (!id) return "000000";
  // Extract digits from UUID and take first 6
  const digits = id.replace(/\D/g, "");
  return digits.slice(0, 6).padStart(6, "0");
}

export function ProfileHeader({ profile, email, isLoading, onAvatarUpdate }: ProfileHeaderProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center gap-3 p-4">
        <Skeleton className="w-16 h-16 rounded-full bg-white/20" />
        <div className="text-center">
          <Skeleton className="h-5 w-28 mb-1 mx-auto bg-white/20" />
          <Skeleton className="h-3 w-40 mx-auto bg-white/20" />
        </div>
      </div>
    );
  }

  const premiumLabel = profile?.premium_tier
    ? `${profile.premium_tier.charAt(0).toUpperCase()}${profile.premium_tier.slice(1)}`
    : null;

  const displayName = profile?.display_name || email?.split("@")[0] || "User";
  const shortId = getShortId(profile?.id);

  const handleCopyId = () => {
    navigator.clipboard.writeText(shortId);
    toast.success("ID copied!");
  };

  return (
    <div className="flex flex-col items-center gap-3 p-4">
      {/* Avatar with Upload */}
      <AvatarUpload
        currentAvatarUrl={profile?.avatar_url}
        displayName={displayName}
        onUploadSuccess={(url) => onAvatarUpdate?.(url)}
      />

      {/* User Info */}
      <div className="text-center">
        <h2 className="text-base font-bold text-primary-foreground drop-shadow-sm">
          {displayName}
        </h2>
        <button
          onClick={handleCopyId}
          className="inline-flex items-center gap-1.5 mt-1 px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm text-sm font-semibold text-white hover:bg-white/30 transition-colors drop-shadow-sm"
        >
          <span>ID: {shortId}</span>
          <Copy className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Membership Badge */}
      <div
        className={`px-3 py-1.5 rounded-full flex items-center gap-1.5 ${
          premiumLabel ? "bg-gold/20 backdrop-blur-sm" : "bg-white/15 backdrop-blur-sm"
        }`}
      >
        {premiumLabel ? (
          <>
            <Crown className="w-3.5 h-3.5 text-gold" />
            <span className="text-xs font-semibold text-gold">{premiumLabel}</span>
          </>
        ) : (
          <span className="text-xs font-medium text-primary-foreground/90">Free Member</span>
        )}
      </div>
    </div>
  );
}
