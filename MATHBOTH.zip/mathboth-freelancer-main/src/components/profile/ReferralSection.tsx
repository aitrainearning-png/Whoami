import { Copy, Share2, Users, Coins } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Profile } from "@/hooks/useProfile";

interface ReferralSectionProps {
  profile: Profile | null | undefined;
}

export function ReferralSection({ profile }: ReferralSectionProps) {
  const handleCopyReferral = () => {
    if (profile?.referral_code) {
      navigator.clipboard.writeText(profile.referral_code);
      toast.success("Referral code copied!");
    }
  };

  const handleShare = () => {
    if (navigator.share && profile?.referral_code) {
      navigator.share({
        title: "Join MathBot",
        text: `Use my referral code ${profile.referral_code} to join MathBot and start earning!`,
        url: `${window.location.origin}/signup?ref=${profile.referral_code}`,
      });
    } else {
      handleCopyReferral();
    }
  };

  return (
    <Card className="border-0 shadow-soft">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">Your Referral Code</p>
            <p className="text-lg font-bold text-foreground tracking-wider">
              {profile?.referral_code || "N/A"}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleCopyReferral}
              className="h-9 w-9"
            >
              <Copy className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              onClick={handleShare}
              className="h-9 w-9 bg-primary"
            >
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <Users className="w-3.5 h-3.5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">{profile?.referral_count || 0}</p>
              <p className="text-xs text-muted-foreground">Referred</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gold/10 flex items-center justify-center">
              <Coins className="w-3.5 h-3.5 text-gold" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">₱{(profile?.referral_earnings || 0).toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">10% Lifetime</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
