import { Wallet, TrendingUp, ArrowDownToLine, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Profile } from "@/hooks/useProfile";

interface AccountStatsProps {
  profile: Profile | null | undefined;
}

export function AccountStats({ profile }: AccountStatsProps) {
  const stats = [
    {
      label: "Balance",
      value: `₱${(profile?.balance || 0).toFixed(2)}`,
      icon: Wallet,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      label: "Total Earned",
      value: `₱${(profile?.total_earned || 0).toFixed(2)}`,
      icon: TrendingUp,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      label: "Withdrawals",
      value: profile?.first_withdrawal_done ? "1+" : "0",
      icon: ArrowDownToLine,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      label: "Referrals",
      value: String(profile?.referral_count || 0),
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3">
      {stats.map((stat) => (
        <Card key={stat.label} className="border-0 shadow-soft">
          <CardContent className="p-3 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg ${stat.bgColor} flex items-center justify-center shrink-0`}>
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
            </div>
            <div className="min-w-0">
              <p className="text-base font-bold text-foreground truncate">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
