import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Mail } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function InboxNotification() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: unreadCount } = useQuery({
    queryKey: ["inbox-unread", user?.id],
    queryFn: async () => {
      if (!user) return 0;
      const { count, error } = await supabase
        .from("direct_messages")
        .select("id", { count: "exact", head: true })
        .eq("receiver_id", user.id)
        .eq("is_read", false);
      if (error) return 0;
      return count || 0;
    },
    enabled: !!user,
    refetchInterval: 5000,
  });

  if (!unreadCount || unreadCount === 0) return null;

  return (
    <button
      onClick={() => navigate("/inbox")}
      className="fixed top-4 right-4 z-50 bg-primary text-primary-foreground rounded-full p-3 shadow-lg animate-bounce"
      aria-label="Unread messages"
    >
      <Mail className="w-5 h-5" />
      <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
        {unreadCount}
      </span>
    </button>
  );
}
