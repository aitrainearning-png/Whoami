import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, Wallet, ListTodo, ClipboardCheck, BarChart3, LogOut } from "lucide-react";
import { useClientAuth } from "@/contexts/ClientAuthContext";
import { cn } from "@/lib/utils";

interface ClientLayoutProps {
  children: ReactNode;
}

const navItems = [
  { path: "/client/dashboard", icon: Home, label: "Dashboard" },
  { path: "/client/wallet", icon: Wallet, label: "Wallet" },
  { path: "/client/tasks", icon: ListTodo, label: "Tasks" },
  { path: "/client/submissions", icon: ClipboardCheck, label: "Submissions" },
  { path: "/client/analytics", icon: BarChart3, label: "Analytics" },
];

export function ClientLayout({ children }: ClientLayoutProps) {
  const location = useLocation();
  const { signOut, client } = useClientAuth();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-card">
        <div className="container flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-primary">Client Portal</span>
            {client?.status === "pending" && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-600">
                Pending Approval
              </span>
            )}
            {client?.status === "suspended" && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/20 text-destructive">
                Suspended
              </span>
            )}
          </div>
          <button
            onClick={signOut}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-20">{children}</main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card">
        <div className="container flex items-center justify-around py-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex flex-col items-center gap-1 px-3 py-1.5 text-xs transition-colors",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
