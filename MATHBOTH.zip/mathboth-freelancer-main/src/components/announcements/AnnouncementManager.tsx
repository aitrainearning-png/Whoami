import { useAdminAnnouncements } from "@/hooks/useAdminAnnouncements";
import { AnnouncementPopup } from "./AnnouncementPopup";
import { useAuth } from "@/contexts/AuthContext";

export function AnnouncementManager() {
  const { user } = useAuth();
  const { announcements, dismiss } = useAdminAnnouncements();

  // Don't show if not logged in or no announcements
  if (!user || announcements.length === 0) {
    return null;
  }

  // Show the most recent announcement first
  const currentAnnouncement = announcements[0];

  return (
    <AnnouncementPopup
      key={currentAnnouncement.id}
      id={currentAnnouncement.id}
      message={currentAnnouncement.message}
      onDismiss={dismiss}
    />
  );
}
