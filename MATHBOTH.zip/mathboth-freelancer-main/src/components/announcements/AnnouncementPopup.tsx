import { useState, useEffect } from "react";
import { Copy, Check, Megaphone, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface AnnouncementPopupProps {
  id: string;
  message: string;
  onDismiss: (id: string) => void;
}

const COUNTDOWN_SECONDS = 5;

export function AnnouncementPopup({ id, message, onDismiss }: AnnouncementPopupProps) {
  const [countdown, setCountdown] = useState(COUNTDOWN_SECONDS);
  const [copied, setCopied] = useState(false);
  const canDismiss = countdown <= 0;

  useEffect(() => {
    if (countdown <= 0) return;

    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      toast.success("Message copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy message");
    }
  };

  const handleDismiss = () => {
    if (canDismiss) {
      onDismiss(id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-card border-2 border-primary/30 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
        {/* Header */}
        <div className="bg-primary/10 px-4 py-3 flex items-center justify-between border-b border-primary/20">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-primary/20 rounded-full">
              <Megaphone className="w-4 h-4 text-primary" />
            </div>
            <span className="font-semibold text-sm text-primary">Admin Announcement</span>
          </div>
          
          {/* Countdown or Close button */}
          {canDismiss ? (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleDismiss}
              className="h-8 w-8 rounded-full hover:bg-destructive/10 hover:text-destructive"
            >
              <X className="w-4 h-4" />
            </Button>
          ) : (
            <div className="flex items-center gap-1.5 bg-muted px-2.5 py-1 rounded-full">
              <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
              <span className="text-xs font-medium text-muted-foreground">
                Wait {countdown}s
              </span>
            </div>
          )}
        </div>

        {/* Message Content */}
        <div className="p-4">
          <div className="bg-muted/50 rounded-xl p-4 border border-border">
            <p className="text-sm leading-relaxed whitespace-pre-wrap break-words text-foreground">
              {message}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="px-4 pb-4 flex gap-2">
          <Button
            onClick={handleCopy}
            variant="outline"
            className="flex-1 gap-2"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-green-500" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Copy Message
              </>
            )}
          </Button>
          
          <Button
            onClick={handleDismiss}
            disabled={!canDismiss}
            className="flex-1"
          >
            {canDismiss ? "Got it!" : `Wait ${countdown}s...`}
          </Button>
        </div>
      </div>
    </div>
  );
}
