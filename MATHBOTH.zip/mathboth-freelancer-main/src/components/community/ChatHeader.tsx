import { useState, useEffect } from "react";
import { MessageCircle } from "lucide-react";

// Generate smooth random online count between 350-420
const generateOnlineCount = (currentCount: number): number => {
  const MIN = 350;
  const MAX = 420;
  
  // Small random change: -2 to +2
  const change = Math.floor(Math.random() * 5) - 2;
  let newCount = currentCount + change;
  
  // Keep within bounds
  if (newCount < MIN) newCount = MIN + Math.floor(Math.random() * 5);
  if (newCount > MAX) newCount = MAX - Math.floor(Math.random() * 5);
  
  return newCount;
};

export function ChatHeader() {
  const [onlineCount, setOnlineCount] = useState(() => 
    350 + Math.floor(Math.random() * 70) // Initial: 350-420
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setOnlineCount(prev => generateOnlineCount(prev));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-gradient-header pt-safe px-4 pb-4 shrink-0">
      <div className="pt-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-6 h-6 text-primary-foreground" />
          <h1 className="text-xl font-bold text-primary-foreground">Community</h1>
        </div>
        <div className="flex items-center gap-2 bg-white/20 rounded-full px-3 py-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-green-400 animate-pulse" />
          <span className="text-sm font-medium text-primary-foreground">
            {onlineCount} online
          </span>
        </div>
      </div>
    </header>
  );
}
