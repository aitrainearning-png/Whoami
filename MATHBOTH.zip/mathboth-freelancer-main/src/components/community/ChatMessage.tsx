import { UserAvatar } from "@/components/ui/user-avatar";
import { formatDistanceToNow } from "date-fns";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChatMessageProps {
  message: {
    id: string;
    user_id: string;
    display_name: string;
    message: string;
    created_at: string;
    avatar_url?: string | null;
    image_url?: string | null;
  };
  isOwn: boolean;
  isAdmin?: boolean;
  onDelete?: (id: string) => void;
}

export function ChatMessage({ message, isOwn, isAdmin, onDelete }: ChatMessageProps) {
  return (
    <div className={`group flex gap-2 ${isOwn ? "flex-row-reverse" : "flex-row"}`}>
      <UserAvatar
        avatarUrl={message.avatar_url}
        displayName={message.display_name}
        size="sm"
      />
      
      <div className={`max-w-[75%] ${isOwn ? "items-end" : "items-start"}`}>
        <div className={`flex items-center gap-2 mb-1 ${isOwn ? "flex-row-reverse" : "flex-row"}`}>
          <span className="text-xs font-medium text-foreground">
            {isOwn ? "You" : message.display_name}
          </span>
          <span className="text-[10px] text-muted-foreground">
            {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
          </span>
        </div>
        <div
          className={`rounded-2xl overflow-hidden ${
            isOwn
              ? "bg-primary text-primary-foreground rounded-br-md"
              : "bg-muted text-foreground rounded-bl-md"
          }`}
        >
          {/* Image display */}
          {message.image_url && (
            <a href={message.image_url} target="_blank" rel="noopener noreferrer">
              <img 
                src={message.image_url} 
                alt="Shared image" 
                className="max-w-full max-h-60 object-contain"
              />
            </a>
          )}
          
          {/* Text message - preserve whitespace and line breaks */}
          {message.message && (
            <p className="text-sm leading-relaxed break-words px-4 py-2.5 whitespace-pre-wrap">{message.message}</p>
          )}
        </div>
        {isAdmin && onDelete && (
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive shrink-0 self-center"
            onClick={() => onDelete(message.id)}
            title="Delete message"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        )}
      </div>
    </div>
  );
}