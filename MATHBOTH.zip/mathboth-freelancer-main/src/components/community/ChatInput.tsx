import { useState, useRef } from "react";
import { Send, MessageCircleOff, Image, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const MAX_WORDS = 500;

// Count words in text
const countWords = (text: string): number => {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).filter(word => word.length > 0).length;
};

interface ChatInputProps {
  onSend: (message: string, imageUrl?: string) => void;
  isSending: boolean;
  lastSentTime: React.MutableRefObject<number>;
  disabled?: boolean;
  disabledMessage?: string;
  isAdmin?: boolean;
}

export function ChatInput({ onSend, isSending, lastSentTime, disabled, disabledMessage, isAdmin }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const wordCount = countWords(message);
  const wordsRemaining = MAX_WORDS - wordCount;

  // Check if message contains a link
  const containsLink = (text: string) => {
    return /https?:\/\/|www\./i.test(text);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be less than 5MB");
      return;
    }

    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    const fileExt = file.name.split(".").pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `chat-images/${fileName}`;

    const { data, error } = await supabase.storage
      .from("avatars")
      .upload(filePath, file);

    if (error) {
      console.error("Upload error:", error);
      return null;
    }

    const { data: urlData } = supabase.storage
      .from("avatars")
      .getPublicUrl(filePath);

    return urlData.publicUrl;
  };

  const handleSend = async () => {
    if ((!message.trim() && !imageFile) || disabled) return;

    // Check for links in message (only admins can send links)
    if (message.trim() && containsLink(message) && !isAdmin) {
      toast.error("Only admins can send links in messages");
      return;
    }

    // Rate limiting (2 second cooldown - reduced for better UX)
    const now = Date.now();
    if (now - lastSentTime.current < 2000) {
      toast.error("Please wait a moment before sending another message");
      return;
    }

    // Word limit check
    if (wordCount > MAX_WORDS) {
      toast.error(`Message exceeds ${MAX_WORDS} word limit`);
      return;
    }

    let imageUrl: string | undefined;

    // Upload image if present
    if (imageFile) {
      setIsUploading(true);
      const uploadedUrl = await uploadImage(imageFile);
      setIsUploading(false);

      if (!uploadedUrl) {
        toast.error("Failed to upload image");
        return;
      }
      imageUrl = uploadedUrl;
    }

    lastSentTime.current = now;
    onSend(message.trim(), imageUrl);
    setMessage("");
    removeImage();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Ctrl+Enter or Cmd+Enter to send
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSend();
    }
    // Regular Enter allows line breaks (default textarea behavior)
  };

  // Show disabled state - prominent centered notice
  if (disabled) {
    return (
      <div className="flex flex-col items-center justify-center py-6 px-4">
        <div className="flex flex-col items-center gap-3 p-6 bg-destructive/10 border-2 border-destructive/30 rounded-xl">
          <div className="p-3 bg-destructive/20 rounded-full">
            <MessageCircleOff className="w-8 h-8 text-destructive" />
          </div>
          <p className="text-base font-semibold text-destructive text-center uppercase tracking-wide">
            Community Chat is Currently Disabled
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {/* Image Preview */}
      {imagePreview && (
        <div className="relative inline-block">
          <img 
            src={imagePreview} 
            alt="Preview" 
            className="h-20 w-20 object-cover rounded-lg"
          />
          <button
            onClick={removeImage}
            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageSelect}
        className="hidden"
      />

      <div className="flex gap-2 items-end">
        {/* Image upload button */}
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          className="h-10 w-10 rounded-full shrink-0 border-2 hover:bg-accent"
          disabled={isUploading}
          title="Upload image"
        >
          <Image className="w-5 h-5" />
        </Button>

        <div className="flex-1 space-y-1">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            className="min-h-[44px] max-h-[120px] resize-none rounded-2xl bg-muted border-0 text-base py-2.5 px-4"
            rows={1}
          />
        </div>

        <Button
          onClick={handleSend}
          disabled={(!message.trim() && !imageFile) || isSending || isUploading || wordCount > MAX_WORDS}
          size="icon"
          className="h-10 w-10 rounded-full bg-primary shrink-0"
        >
          {isUploading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Send className="w-5 h-5" />
          )}
        </Button>
      </div>
    </div>
  );
}