import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ClientAuthProvider, useClientAuth } from "@/contexts/ClientAuthContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { AnnouncementManager } from "@/components/announcements/AnnouncementManager";
import { useActivityTracker } from "@/hooks/useActivityTracker";
import Home from "./pages/Home";
import Games from "./pages/Games";
import Wallet from "./pages/Wallet";
import Community from "./pages/Community";
import Profile from "./pages/Profile";
import Premium from "./pages/Premium";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import RecoverPassword from "./pages/RecoverPassword";
import QuickMath from "./pages/games/QuickMath";
import SmartCaptcha from "./pages/games/SmartCaptcha";
import PatternPuzzle from "./pages/games/PatternPuzzle";
import LogicMatch from "./pages/games/LogicMatch";
import TypingTest from "./pages/games/TypingTest";
import CoinToss from "./pages/games/CoinToss";
import Admin from "./pages/Admin";
import UserInbox from "./components/inbox/UserInbox";
import NotFound from "./pages/NotFound";

// Client pages
import ClientLogin from "./pages/client/ClientLogin";
import ClientRegister from "./pages/client/ClientRegister";
import ClientDashboard from "./pages/client/ClientDashboard";
import ClientWallet from "./pages/client/ClientWallet";
import ClientTasks from "./pages/client/ClientTasks";
import CreateTask from "./pages/client/CreateTask";
import TaskDetail from "./pages/client/TaskDetail";
import ClientSubmissions from "./pages/client/ClientSubmissions";
import ClientAnalytics from "./pages/client/ClientAnalytics";

const queryClient = new QueryClient();

// Protected route wrapper
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, banInfo } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  
  if (!user || banInfo) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
}

// Public route wrapper (redirects to home if logged in)
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, banInfo } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  
  if (user && !banInfo) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
}

function ActivityTracker() {
  useActivityTracker();
  return null;
}

// Client protected route wrapper
function ClientProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, client, loading } = useClientAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  
  if (!user || !client) {
    return <Navigate to="/client" replace />;
  }
  
  return <>{children}</>;
}

// Client public route wrapper
function ClientPublicRoute({ children }: { children: React.ReactNode }) {
  const { user, client, loading } = useClientAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  
  if (user && client) {
    return <Navigate to="/client/dashboard" replace />;
  }
  
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <>
      <ActivityTracker />
      <Routes>
        {/* Public Auth Routes */}
        <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
        <Route path="/signup" element={<PublicRoute><Signup /></PublicRoute>} />
        <Route path="/recover-password" element={<PublicRoute><RecoverPassword /></PublicRoute>} />
        
        {/* Protected Main App Routes with Bottom Navigation */}
        <Route path="/" element={<ProtectedRoute><AppLayout><Home /></AppLayout></ProtectedRoute>} />
        <Route path="/games" element={<ProtectedRoute><AppLayout><Games /></AppLayout></ProtectedRoute>} />
        <Route path="/wallet" element={<ProtectedRoute><AppLayout><Wallet /></AppLayout></ProtectedRoute>} />
        <Route path="/community" element={<ProtectedRoute><AppLayout><Community /></AppLayout></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><AppLayout><Profile /></AppLayout></ProtectedRoute>} />
        
        {/* Protected Routes without Bottom Navigation */}
        <Route path="/premium" element={<ProtectedRoute><Premium /></ProtectedRoute>} />
        <Route path="/inbox" element={<ProtectedRoute><UserInbox /></ProtectedRoute>} />
        
        {/* Game Play Routes */}
        <Route path="/play/quick-math" element={<ProtectedRoute><QuickMath /></ProtectedRoute>} />
        <Route path="/play/smart-captcha" element={<ProtectedRoute><SmartCaptcha /></ProtectedRoute>} />
        <Route path="/play/pattern-puzzle" element={<ProtectedRoute><PatternPuzzle /></ProtectedRoute>} />
        <Route path="/play/logic-match" element={<ProtectedRoute><LogicMatch /></ProtectedRoute>} />
        <Route path="/play/typing-test" element={<ProtectedRoute><TypingTest /></ProtectedRoute>} />
        <Route path="/play/coin-toss" element={<ProtectedRoute><CoinToss /></ProtectedRoute>} />
        
        {/* Admin Route */}
        <Route path="/admin" element={<ProtectedRoute><Admin /></ProtectedRoute>} />
        
        {/* Catch-all */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

function ClientRoutes() {
  return (
    <Routes>
      {/* Client Public Routes */}
      <Route path="/client" element={<ClientPublicRoute><ClientLogin /></ClientPublicRoute>} />
      <Route path="/client/register" element={<ClientPublicRoute><ClientRegister /></ClientPublicRoute>} />
      
      {/* Client Protected Routes */}
      <Route path="/client/dashboard" element={<ClientProtectedRoute><ClientDashboard /></ClientProtectedRoute>} />
      <Route path="/client/wallet" element={<ClientProtectedRoute><ClientWallet /></ClientProtectedRoute>} />
      <Route path="/client/tasks" element={<ClientProtectedRoute><ClientTasks /></ClientProtectedRoute>} />
      <Route path="/client/tasks/create" element={<ClientProtectedRoute><CreateTask /></ClientProtectedRoute>} />
      <Route path="/client/tasks/:id" element={<ClientProtectedRoute><TaskDetail /></ClientProtectedRoute>} />
      <Route path="/client/submissions" element={<ClientProtectedRoute><ClientSubmissions /></ClientProtectedRoute>} />
      <Route path="/client/analytics" element={<ClientProtectedRoute><ClientAnalytics /></ClientProtectedRoute>} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <ClientAuthProvider>
            <AnnouncementManager />
            <AppRoutes />
            <ClientRoutes />
          </ClientAuthProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
