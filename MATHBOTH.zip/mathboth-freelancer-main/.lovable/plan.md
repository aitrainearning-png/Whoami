

# MathBot - Mobile Earning App

## Overview
A modern, premium mobile earning app where users play logic-based games to earn rewards. Built with a professional, mature design aesthetic featuring colorful gradients while maintaining trustworthiness.

---

## Phase 1: Core Foundation

### 1. App Shell & Navigation
- Fixed bottom navigation bar with 4 tabs: Home, Games, Wallet, Profile
- Each tab as a dedicated full-screen page
- Smooth tab transitions with mobile-optimized touch targets
- Professional gradient header design (purple → pink → indigo palette)

### 2. Authentication System
- Clean login and signup screens with email & password
- Optional referral code field during signup (validated on entry)
- Modern form design with proper validation feedback
- Secure session management

### 3. Home Screen
- Gradient hero header with user greeting
- Energy bar (visual progress indicator)
- Balance card displaying current earnings with Withdraw & Upgrade buttons
- Stats section: Games Played, Total Earned
- Daily Challenge card with clean professional styling

---

## Phase 2: Games & Earning Engine

### 4. Games Screen
- Grid layout displaying all available games
- Each game card shows: icon, name, energy cost, reward range, Play button
- Professional minimal icons (no cartoons)

### 5. Playable Games (4 games)
- **Quick Math**: Solve arithmetic problems against a timer
- **Smart Captcha**: Visual matching/selection puzzles
- **Pattern Puzzle**: Complete sequences and patterns
- **Logic Match**: Pair matching and logic challenges

### 6. Game Mechanics
- Dynamic timer system (adjusts by difficulty)
- Energy consumption per game
- Reward calculation with diminishing returns
- Fail state: timer expires = no reward
- Success animations (subtle, professional)

---

## Phase 3: Economy & Wallet

### 7. Wallet Screen
- Current balance display with transaction history
- Withdrawal request form
- First withdrawal: ₱3 minimum (welcome bonus)
- Subsequent withdrawals: Higher minimum threshold
- Pending/Approved/Rejected status indicators

### 8. Energy System
- Energy regenerates over time
- Visual energy meter on home and games screens
- Energy refill notifications

### 9. Referral System
- Unique referral code per user
- 10% lifetime commission from referral earnings only
- Referral stats in Profile section

---

## Phase 4: Premium & Admin

### 10. Premium Tiers
- Three tiers: Basic (₱99), Advance (₱199), Pro (₱299)
- Benefits: faster energy regen, higher efficiency, priority withdrawals
- Manual payment flow: user submits payment proof (screenshot/reference)
- Admin reviews and activates premium status

### 11. Profile Screen
- User info and avatar
- Current premium tier status
- Referral code display and sharing
- Settings and logout

### 12. Admin Dashboard (Hidden /admin route)
- User management panel
- Withdrawal request queue with approve/reject actions
- Reward rate controls and energy settings
- Premium activation controls
- Fraud/suspicious activity flags

---

## Technical Architecture

### Database (Supabase)
- **Users**: profile data, energy, balance
- **User Roles**: admin role management (separate table)
- **Games**: game configs, reward rates, energy costs
- **Transactions**: earnings, withdrawals, status
- **Referrals**: referrer/referee relationships, commission tracking
- **Premium Orders**: payment proofs, tier, approval status

### Security
- Row-level security on all user data
- Admin-only access for sensitive controls
- Rate limiting on game submissions
- Server-side reward calculation (prevent cheating)

---

## Design System
- **Colors**: Purple/Pink/Indigo gradients with gold accents for rewards
- **Typography**: Inter font family - clean and professional
- **Cards**: Rounded corners, soft shadows, white backgrounds
- **Icons**: Lucide icons (professional outline style)
- **Animations**: Subtle fade and slide only - no bouncing effects

