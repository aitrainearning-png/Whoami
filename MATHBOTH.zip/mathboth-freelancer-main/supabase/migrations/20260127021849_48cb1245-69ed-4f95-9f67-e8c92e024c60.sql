-- Add playtime tracking columns for free users
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS playtime_seconds INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS playtime_reset_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now();

-- Add comment for clarity
COMMENT ON COLUMN public.profiles.playtime_seconds IS 'Total playtime in seconds for current period (resets after 8 hours for free users)';
COMMENT ON COLUMN public.profiles.playtime_reset_at IS 'When the playtime counter was last reset';