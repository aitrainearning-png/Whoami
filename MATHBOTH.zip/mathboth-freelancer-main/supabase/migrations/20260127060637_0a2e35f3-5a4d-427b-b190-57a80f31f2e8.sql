-- Enable realtime for profiles table so users get instant updates when their premium_tier changes
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
-- Enable realtime for premium_orders so users see status updates instantly
ALTER PUBLICATION supabase_realtime ADD TABLE public.premium_orders;
-- Enable realtime for transactions so wallet history updates instantly
ALTER PUBLICATION supabase_realtime ADD TABLE public.transactions;