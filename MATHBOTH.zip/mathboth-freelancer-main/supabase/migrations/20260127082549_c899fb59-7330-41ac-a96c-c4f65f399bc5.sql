-- Create tier_settings table to store duration and earning rate per tier
CREATE TABLE public.tier_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier premium_tier NOT NULL UNIQUE,
  duration_days integer NOT NULL DEFAULT 30,
  earning_rate numeric NOT NULL DEFAULT 0.15,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tier_settings ENABLE ROW LEVEL SECURITY;

-- Admins can manage tier settings
CREATE POLICY "Admins can manage tier settings"
ON public.tier_settings
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- All authenticated users can view tier settings (needed for client-side display)
CREATE POLICY "Authenticated users can view tier settings"
ON public.tier_settings
FOR SELECT
TO authenticated
USING (true);

-- Insert default tier settings
INSERT INTO public.tier_settings (tier, duration_days, earning_rate) VALUES
  ('basic', 30, 0.20),
  ('advance', 30, 0.35),
  ('pro', 30, 0.50);

-- Add trigger for updated_at
CREATE TRIGGER update_tier_settings_updated_at
BEFORE UPDATE ON public.tier_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();