-- Add image_url column to chat_messages for image support
ALTER TABLE public.chat_messages ADD COLUMN IF NOT EXISTS image_url text;

-- Update the RLS policy to check for links in messages (only admins can send links)
-- First drop the existing insert policy
DROP POLICY IF EXISTS "Users can insert messages when chat enabled or admin" ON public.chat_messages;

-- Recreate with link restriction for non-admins
CREATE POLICY "Users can insert messages when chat enabled or admin" 
ON public.chat_messages 
FOR INSERT 
WITH CHECK (
  auth.uid() = user_id 
  AND (
    has_role(auth.uid(), 'admin'::app_role) 
    OR (
      -- Chat must be enabled for non-admins
      (SELECT ((app_settings.value ->> 'enabled'::text))::boolean FROM app_settings WHERE app_settings.key = 'chat_enabled')
      -- Non-admins cannot send links (http://, https://, www.)
      AND message !~* '(https?://|www\.)'
    )
  )
);