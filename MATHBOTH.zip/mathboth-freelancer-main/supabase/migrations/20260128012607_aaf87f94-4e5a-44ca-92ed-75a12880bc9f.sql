-- Insert free tier into tier_settings
INSERT INTO public.tier_settings (tier, earning_rate, duration_days)
VALUES ('free', 0.65, 0)
ON CONFLICT (tier) DO UPDATE SET earning_rate = 0.65, duration_days = 0;

-- Update existing tiers with new earning rates
UPDATE public.tier_settings SET earning_rate = 0.90 WHERE tier = 'basic';
UPDATE public.tier_settings SET earning_rate = 1.20 WHERE tier = 'advance';
UPDATE public.tier_settings SET earning_rate = 1.30 WHERE tier = 'pro';