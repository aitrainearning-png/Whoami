-- =============================================
-- MathBot Database Schema
-- =============================================

-- Create enum for app roles (admin role management)
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

-- Create enum for premium tiers
CREATE TYPE public.premium_tier AS ENUM ('basic', 'advance', 'pro');

-- Create enum for transaction types
CREATE TYPE public.transaction_type AS ENUM ('earning', 'withdrawal', 'referral_commission', 'bonus');

-- Create enum for transaction/order status
CREATE TYPE public.status_type AS ENUM ('pending', 'approved', 'rejected', 'completed');

-- =============================================
-- User Roles Table (separate from profiles for security)
-- =============================================
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Security Definer Function for Role Checking
-- =============================================
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- =============================================
-- Profiles Table
-- =============================================
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    display_name TEXT,
    email TEXT,
    
    -- Energy system
    energy INTEGER NOT NULL DEFAULT 100,
    max_energy INTEGER NOT NULL DEFAULT 100,
    energy_updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    
    -- Balance & stats
    balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_earned DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    games_played INTEGER NOT NULL DEFAULT 0,
    
    -- Premium status
    premium_tier premium_tier DEFAULT NULL,
    premium_expires_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    -- Referral system
    referral_code TEXT UNIQUE NOT NULL,
    referred_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    referral_count INTEGER NOT NULL DEFAULT 0,
    referral_earnings DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    
    -- Withdrawal tracking
    first_withdrawal_done BOOLEAN NOT NULL DEFAULT FALSE,
    last_withdrawal_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Game Configurations Table
-- =============================================
CREATE TABLE public.games (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    energy_cost INTEGER NOT NULL DEFAULT 10,
    min_reward DECIMAL(10,2) NOT NULL DEFAULT 0.10,
    max_reward DECIMAL(10,2) NOT NULL DEFAULT 0.50,
    base_time_seconds INTEGER NOT NULL DEFAULT 30,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    difficulty_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Transactions Table
-- =============================================
CREATE TABLE public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    type transaction_type NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status status_type NOT NULL DEFAULT 'pending',
    description TEXT,
    game_id TEXT REFERENCES public.games(id) ON DELETE SET NULL,
    reference_id UUID DEFAULT NULL, -- For linking referral commissions to original transactions
    
    -- Withdrawal specific
    payment_method TEXT DEFAULT NULL,
    payment_details TEXT DEFAULT NULL,
    
    processed_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    processed_by UUID DEFAULT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Premium Orders Table
-- =============================================
CREATE TABLE public.premium_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    tier premium_tier NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_reference TEXT,
    payment_proof_url TEXT,
    status status_type NOT NULL DEFAULT 'pending',
    
    processed_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    processed_by UUID DEFAULT NULL,
    rejection_reason TEXT DEFAULT NULL,
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.premium_orders ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Daily Challenges Table
-- =============================================
CREATE TABLE public.daily_challenges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    challenge_date DATE NOT NULL DEFAULT CURRENT_DATE,
    game_id TEXT REFERENCES public.games(id) ON DELETE SET NULL,
    target_count INTEGER NOT NULL DEFAULT 5,
    current_count INTEGER NOT NULL DEFAULT 0,
    reward DECIMAL(10,2) NOT NULL DEFAULT 2.50,
    is_completed BOOLEAN NOT NULL DEFAULT FALSE,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, challenge_date)
);

ALTER TABLE public.daily_challenges ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Game Sessions Table (for anti-cheat tracking)
-- =============================================
CREATE TABLE public.game_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    game_id TEXT REFERENCES public.games(id) ON DELETE CASCADE NOT NULL,
    started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    score INTEGER DEFAULT NULL,
    is_successful BOOLEAN DEFAULT NULL,
    reward_earned DECIMAL(10,2) DEFAULT NULL,
    energy_spent INTEGER NOT NULL,
    time_taken_seconds INTEGER DEFAULT NULL
);

ALTER TABLE public.game_sessions ENABLE ROW LEVEL SECURITY;

-- =============================================
-- RLS Policies
-- =============================================

-- User Roles: Only admins can view, users can see their own
CREATE POLICY "Users can view their own role" 
ON public.user_roles FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles" 
ON public.user_roles FOR ALL 
USING (public.has_role(auth.uid(), 'admin'));

-- Profiles: Users can view/update their own
CREATE POLICY "Users can view their own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles" 
ON public.profiles FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all profiles" 
ON public.profiles FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- Games: Everyone can view active games
CREATE POLICY "Anyone can view active games" 
ON public.games FOR SELECT 
USING (is_active = TRUE);

CREATE POLICY "Admins can manage games" 
ON public.games FOR ALL 
USING (public.has_role(auth.uid(), 'admin'));

-- Transactions: Users can view their own, admins can view all
CREATE POLICY "Users can view their own transactions" 
ON public.transactions FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own transactions" 
ON public.transactions FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all transactions" 
ON public.transactions FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update transactions" 
ON public.transactions FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- Premium Orders: Users can view/insert their own, admins can manage all
CREATE POLICY "Users can view their own premium orders" 
ON public.premium_orders FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own premium orders" 
ON public.premium_orders FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all premium orders" 
ON public.premium_orders FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update premium orders" 
ON public.premium_orders FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- Daily Challenges: Users can view/update their own
CREATE POLICY "Users can view their own challenges" 
ON public.daily_challenges FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own challenges" 
ON public.daily_challenges FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own challenges" 
ON public.daily_challenges FOR UPDATE 
USING (auth.uid() = user_id);

-- Game Sessions: Users can manage their own
CREATE POLICY "Users can view their own sessions" 
ON public.game_sessions FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own sessions" 
ON public.game_sessions FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own sessions" 
ON public.game_sessions FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all sessions" 
ON public.game_sessions FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

-- =============================================
-- Helper Functions
-- =============================================

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
    chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    code TEXT := '';
    i INTEGER;
BEGIN
    FOR i IN 1..8 LOOP
        code := code || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    RETURN code;
END;
$$;

-- Function to create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_referral_code TEXT;
    referrer_id UUID;
    ref_code TEXT;
BEGIN
    -- Generate unique referral code
    LOOP
        new_referral_code := public.generate_referral_code();
        EXIT WHEN NOT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = new_referral_code);
    END LOOP;
    
    -- Check for referral code in metadata
    ref_code := NEW.raw_user_meta_data->>'referral_code';
    IF ref_code IS NOT NULL AND ref_code != '' THEN
        SELECT id INTO referrer_id FROM public.profiles WHERE referral_code = ref_code;
        -- Update referrer's count
        IF referrer_id IS NOT NULL THEN
            UPDATE public.profiles SET referral_count = referral_count + 1 WHERE id = referrer_id;
        END IF;
    END IF;
    
    -- Create profile
    INSERT INTO public.profiles (user_id, email, display_name, referral_code, referred_by)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
        new_referral_code,
        referrer_id
    );
    
    -- Create default user role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user');
    
    RETURN NEW;
END;
$$;

-- Trigger for new user
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

-- Trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Function to calculate energy regeneration
CREATE OR REPLACE FUNCTION public.calculate_energy(
    current_energy INTEGER,
    max_energy INTEGER,
    energy_updated_at TIMESTAMP WITH TIME ZONE,
    premium_tier premium_tier DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
AS $$
DECLARE
    minutes_passed INTEGER;
    regen_rate INTEGER := 1; -- Base: 1 energy per minute
    energy_gained INTEGER;
    new_energy INTEGER;
BEGIN
    -- Premium users get faster regen
    IF premium_tier = 'pro' THEN
        regen_rate := 3;
    ELSIF premium_tier = 'advance' THEN
        regen_rate := 2;
    ELSIF premium_tier = 'basic' THEN
        regen_rate := 1.5;
    END IF;
    
    minutes_passed := EXTRACT(EPOCH FROM (now() - energy_updated_at)) / 60;
    energy_gained := minutes_passed * regen_rate;
    new_energy := LEAST(current_energy + energy_gained, max_energy);
    
    RETURN new_energy;
END;
$$;

-- =============================================
-- Seed Game Data
-- =============================================
INSERT INTO public.games (id, name, description, energy_cost, min_reward, max_reward, base_time_seconds, difficulty_multiplier) VALUES
    ('quick-math', 'Quick Math', 'Solve arithmetic problems against a timer', 10, 0.10, 0.50, 30, 1.00),
    ('smart-captcha', 'Smart Captcha', 'Visual matching and selection puzzles', 8, 0.08, 0.40, 25, 1.00),
    ('pattern-puzzle', 'Pattern Puzzle', 'Complete sequences and patterns', 12, 0.15, 0.60, 35, 1.00),
    ('logic-match', 'Logic Match', 'Pair matching and logic challenges', 15, 0.20, 0.75, 40, 1.00);