
-- Create user_bans table
CREATE TABLE public.user_bans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  banned_by uuid NOT NULL,
  ban_type text NOT NULL CHECK (ban_type IN ('permanent', 'temporary')),
  reason text NOT NULL,
  expires_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  is_active boolean NOT NULL DEFAULT true
);

-- Enable RLS
ALTER TABLE public.user_bans ENABLE ROW LEVEL SECURITY;

-- Admins can manage all bans
CREATE POLICY "Admins can manage all bans"
ON public.user_bans
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Users can view their own active bans
CREATE POLICY "Users can view their own bans"
ON public.user_bans
FOR SELECT
USING (auth.uid() = user_id);

-- Create index for fast lookups
CREATE INDEX idx_user_bans_user_id_active ON public.user_bans (user_id, is_active);

-- Function to check if a user is currently banned
CREATE OR REPLACE FUNCTION public.is_user_banned(check_user_id uuid)
RETURNS TABLE(is_banned boolean, ban_type text, reason text, expires_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    true as is_banned,
    ub.ban_type,
    ub.reason,
    ub.expires_at
  FROM public.user_bans ub
  WHERE ub.user_id = check_user_id
    AND ub.is_active = true
    AND (
      ub.ban_type = 'permanent' 
      OR (ub.ban_type = 'temporary' AND ub.expires_at > now())
    )
  ORDER BY ub.created_at DESC
  LIMIT 1;
$$;
