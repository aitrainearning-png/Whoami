-- Allow admins to insert transactions for other users (e.g., premium approval records)
DO $$ BEGIN
  -- Ensure RLS is enabled (should already be on)
  IF NOT EXISTS (
    SELECT 1
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'transactions'
      AND policyname = 'Admins can insert transactions'
  ) THEN
    CREATE POLICY "Admins can insert transactions"
    ON public.transactions
    FOR INSERT
    TO authenticated
    WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));
  END IF;
END $$;
