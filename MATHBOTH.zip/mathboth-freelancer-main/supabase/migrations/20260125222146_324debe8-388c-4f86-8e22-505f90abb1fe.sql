-- Fix Function Search Path Mutable warnings

-- Fix generate_referral_code function
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
    chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    code TEXT := '';
    i INTEGER;
BEGIN
    FOR i IN 1..8 LOOP
        code := code || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    RETURN code;
END;
$$;

-- Fix update_updated_at_column function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

-- Fix calculate_energy function
CREATE OR REPLACE FUNCTION public.calculate_energy(
    current_energy INTEGER,
    max_energy INTEGER,
    energy_updated_at TIMESTAMP WITH TIME ZONE,
    premium_tier premium_tier DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
    minutes_passed INTEGER;
    regen_rate INTEGER := 1;
    energy_gained INTEGER;
    new_energy INTEGER;
BEGIN
    IF premium_tier = 'pro' THEN
        regen_rate := 3;
    ELSIF premium_tier = 'advance' THEN
        regen_rate := 2;
    ELSIF premium_tier = 'basic' THEN
        regen_rate := 1.5;
    END IF;
    
    minutes_passed := EXTRACT(EPOCH FROM (now() - energy_updated_at)) / 60;
    energy_gained := minutes_passed * regen_rate;
    new_energy := LEAST(current_energy + energy_gained, max_energy);
    
    RETURN new_energy;
END;
$$;