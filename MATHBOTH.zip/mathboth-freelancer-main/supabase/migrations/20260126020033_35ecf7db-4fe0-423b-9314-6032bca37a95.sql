-- Add withdrawals_unlocked field to profiles
ALTER TABLE public.profiles 
ADD COLUMN withdrawals_unlocked boolean NOT NULL DEFAULT false;

-- Create function to count referrals with successful premium purchases
CREATE OR REPLACE FUNCTION public.count_referrals_with_premium(user_profile_id uuid)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COUNT(DISTINCT p.id)::integer
  FROM public.profiles p
  INNER JOIN public.premium_orders po ON po.user_id = p.user_id
  WHERE p.referred_by = user_profile_id
    AND po.status = 'approved'
$$;

-- Create function to check if user can withdraw (for premium users)
CREATE OR REPLACE FUNCTION public.can_premium_user_withdraw(user_profile_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    CASE 
      -- Already unlocked
      WHEN (SELECT withdrawals_unlocked FROM public.profiles WHERE id = user_profile_id) = true THEN true
      -- Check if has 2+ referrals with paid plans
      WHEN public.count_referrals_with_premium(user_profile_id) >= 2 THEN true
      ELSE false
    END
$$;