-- Create app_settings table for global settings like chat control
CREATE TABLE public.app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Anyone can read settings
CREATE POLICY "Anyone can view app settings"
ON public.app_settings FOR SELECT
USING (true);

-- Only admins can update settings
CREATE POLICY "Admins can update app settings"
ON public.app_settings FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- Only admins can insert settings
CREATE POLICY "Admins can insert app settings"
ON public.app_settings FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'));

-- Insert default chat setting (enabled by default)
INSERT INTO public.app_settings (key, value) 
VALUES ('chat_enabled', '{"enabled": true}'::jsonb);

-- Update chat_messages INSERT policy to check if chat is enabled OR user is admin
DROP POLICY IF EXISTS "Users can insert their own messages" ON public.chat_messages;

CREATE POLICY "Users can insert messages when chat enabled or admin"
ON public.chat_messages FOR INSERT
WITH CHECK (
  auth.uid() = user_id 
  AND (
    -- Allow if user is admin
    has_role(auth.uid(), 'admin')
    OR
    -- Allow if chat is enabled
    (SELECT (value->>'enabled')::boolean FROM public.app_settings WHERE key = 'chat_enabled')
  )
);