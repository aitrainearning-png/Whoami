-- Add 'deposit' to the transaction_type enum
ALTER TYPE transaction_type ADD VALUE IF NOT EXISTS 'deposit';

-- Add payment_proof_url column to transactions for deposit proof images
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS payment_proof_url text;