-- Create admin announcements table
CREATE TABLE public.admin_announcements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true
);

-- Enable RLS
ALTER TABLE public.admin_announcements ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage announcements"
ON public.admin_announcements
FOR ALL
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can view active announcements"
ON public.admin_announcements
FOR SELECT
USING (is_active = true);

-- Table to track which users have dismissed which announcements
CREATE TABLE public.announcement_dismissals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    announcement_id UUID NOT NULL REFERENCES public.admin_announcements(id) ON DELETE CASCADE,
    dismissed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(user_id, announcement_id)
);

-- Enable RLS
ALTER TABLE public.announcement_dismissals ENABLE ROW LEVEL SECURITY;

-- Users can insert their own dismissals
CREATE POLICY "Users can dismiss announcements"
ON public.announcement_dismissals
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can view their own dismissals
CREATE POLICY "Users can view own dismissals"
ON public.announcement_dismissals
FOR SELECT
USING (auth.uid() = user_id);

-- Enable realtime for announcements
ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_announcements;