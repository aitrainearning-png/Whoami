-- Add 'free' value to the premium_tier enum
ALTER TYPE public.premium_tier ADD VALUE IF NOT EXISTS 'free';