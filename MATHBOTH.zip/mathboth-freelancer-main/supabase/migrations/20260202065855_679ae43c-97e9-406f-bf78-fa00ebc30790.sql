-- Update the can_premium_user_withdraw function to require only 1 referral instead of 2
CREATE OR REPLACE FUNCTION public.can_premium_user_withdraw(user_profile_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT 
    CASE 
      -- Already unlocked
      WHEN (SELECT withdrawals_unlocked FROM public.profiles WHERE id = user_profile_id) = true THEN true
      -- Check if has 1+ referrals with paid plans (changed from 2 to 1)
      WHEN public.count_referrals_with_premium(user_profile_id) >= 1 THEN true
      ELSE false
    END
$function$;