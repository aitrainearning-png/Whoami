-- Create client account status enum
CREATE TYPE public.client_status AS ENUM ('pending', 'approved', 'suspended');

-- Create task status enum
CREATE TYPE public.task_status AS ENUM ('draft', 'active', 'paused', 'completed');

-- Create submission status enum
CREATE TYPE public.submission_status AS ENUM ('pending', 'approved', 'rejected');

-- Create proof type enum
CREATE TYPE public.proof_type AS ENUM ('image', 'text', 'link');

-- Create clients table (separate from user profiles)
CREATE TABLE public.clients (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL UNIQUE,
    email TEXT NOT NULL,
    company_name TEXT,
    display_name TEXT,
    status client_status NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create client wallets table
CREATE TABLE public.client_wallets (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE UNIQUE,
    balance NUMERIC NOT NULL DEFAULT 0.00,
    total_deposited NUMERIC NOT NULL DEFAULT 0.00,
    total_spent NUMERIC NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create client transaction type enum
CREATE TYPE public.client_transaction_type AS ENUM ('deposit', 'task_spend', 'refund');

-- Create client transactions table
CREATE TABLE public.client_transactions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
    type client_transaction_type NOT NULL,
    amount NUMERIC NOT NULL,
    status status_type NOT NULL DEFAULT 'pending',
    description TEXT,
    reference_id UUID,
    payment_proof_url TEXT,
    processed_by UUID,
    processed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create task categories table
CREATE TABLE public.task_categories (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Insert default categories
INSERT INTO public.task_categories (name, description) VALUES
    ('Social Media', 'Tasks related to social media engagement'),
    ('Survey', 'Complete surveys and questionnaires'),
    ('App Testing', 'Test mobile or web applications'),
    ('Content Creation', 'Create written or visual content'),
    ('Data Entry', 'Data input and verification tasks'),
    ('Review', 'Write reviews for products or services'),
    ('Other', 'Miscellaneous tasks');

-- Create client tasks table
CREATE TABLE public.client_tasks (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    category_id UUID REFERENCES public.task_categories(id),
    instructions TEXT NOT NULL,
    reward_per_user NUMERIC NOT NULL,
    max_workers INTEGER NOT NULL,
    total_budget NUMERIC NOT NULL,
    remaining_budget NUMERIC NOT NULL,
    deadline TIMESTAMP WITH TIME ZONE NOT NULL,
    proof_type proof_type NOT NULL DEFAULT 'text',
    status task_status NOT NULL DEFAULT 'draft',
    approved_count INTEGER NOT NULL DEFAULT 0,
    rejected_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create task submissions table
CREATE TABLE public.task_submissions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES public.client_tasks(id) ON DELETE CASCADE,
    user_id UUID NOT NULL,
    proof_content TEXT NOT NULL,
    proof_image_url TEXT,
    status submission_status NOT NULL DEFAULT 'pending',
    rejection_reason TEXT,
    reward_amount NUMERIC,
    reviewed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_submissions ENABLE ROW LEVEL SECURITY;

-- RLS policies for clients
CREATE POLICY "Clients can view their own profile" ON public.clients
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Clients can update their own profile" ON public.clients
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Anyone can insert client profile" ON public.clients
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all clients" ON public.clients
    FOR ALL USING (has_role(auth.uid(), 'admin'));

-- RLS policies for client wallets
CREATE POLICY "Clients can view their own wallet" ON public.client_wallets
    FOR SELECT USING (client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid()));

CREATE POLICY "Admins can manage all wallets" ON public.client_wallets
    FOR ALL USING (has_role(auth.uid(), 'admin'));

-- RLS policies for client transactions
CREATE POLICY "Clients can view their own transactions" ON public.client_transactions
    FOR SELECT USING (client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid()));

CREATE POLICY "Clients can insert their own transactions" ON public.client_transactions
    FOR INSERT WITH CHECK (client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid()));

CREATE POLICY "Admins can manage all transactions" ON public.client_transactions
    FOR ALL USING (has_role(auth.uid(), 'admin'));

-- RLS policies for task categories
CREATE POLICY "Anyone can view active categories" ON public.task_categories
    FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage categories" ON public.task_categories
    FOR ALL USING (has_role(auth.uid(), 'admin'));

-- RLS policies for client tasks
CREATE POLICY "Clients can manage their own tasks" ON public.client_tasks
    FOR ALL USING (client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid()));

CREATE POLICY "Admins can manage all tasks" ON public.client_tasks
    FOR ALL USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view active tasks" ON public.client_tasks
    FOR SELECT USING (status = 'active');

-- RLS policies for task submissions
CREATE POLICY "Users can view their own submissions" ON public.task_submissions
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create submissions" ON public.task_submissions
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Clients can view submissions for their tasks" ON public.task_submissions
    FOR SELECT USING (task_id IN (SELECT id FROM public.client_tasks WHERE client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid())));

CREATE POLICY "Clients can update submissions for their tasks" ON public.task_submissions
    FOR UPDATE USING (task_id IN (SELECT id FROM public.client_tasks WHERE client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid())));

CREATE POLICY "Admins can manage all submissions" ON public.task_submissions
    FOR ALL USING (has_role(auth.uid(), 'admin'));

-- Create function to auto-create wallet when client is created
CREATE OR REPLACE FUNCTION public.handle_new_client()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.client_wallets (client_id)
    VALUES (NEW.id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for new client
CREATE TRIGGER on_client_created
    AFTER INSERT ON public.clients
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_client();

-- Create trigger for updated_at
CREATE TRIGGER update_clients_updated_at
    BEFORE UPDATE ON public.clients
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_client_wallets_updated_at
    BEFORE UPDATE ON public.client_wallets
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_client_tasks_updated_at
    BEFORE UPDATE ON public.client_tasks
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for performance
CREATE INDEX idx_clients_user_id ON public.clients(user_id);
CREATE INDEX idx_clients_status ON public.clients(status);
CREATE INDEX idx_client_tasks_client_id ON public.client_tasks(client_id);
CREATE INDEX idx_client_tasks_status ON public.client_tasks(status);
CREATE INDEX idx_task_submissions_task_id ON public.task_submissions(task_id);
CREATE INDEX idx_task_submissions_user_id ON public.task_submissions(user_id);
CREATE INDEX idx_task_submissions_status ON public.task_submissions(status);

-- Function to check if user is a client
CREATE OR REPLACE FUNCTION public.is_client(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.clients
    WHERE user_id = _user_id
      AND status = 'approved'
  )
$$;