import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CompleteGameRequest {
  sessionId: string;
  gameId: string;
  score: number;
  isSuccessful: boolean;
  baseReward: number;
  timeTakenSeconds: number;
}

// All users have unlimited playtime

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get user from JWT
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { sessionId, gameId, score, isSuccessful, baseReward, timeTakenSeconds }: CompleteGameRequest = await req.json();

    // Get user profile with referrer info
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id, balance, total_earned, games_played, referred_by, premium_tier, premium_expires_at, playtime_seconds, playtime_reset_at")
      .eq("user_id", user.id)
      .single();

    if (profileError || !profile) {
      return new Response(
        JSON.stringify({ error: "Profile not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if premium is still valid (not expired)
    const now = new Date();
    let effectivePremiumTier = profile.premium_tier;
    
    if (profile.premium_tier && profile.premium_expires_at) {
      const expiresAt = new Date(profile.premium_expires_at);
      if (now > expiresAt) {
        // Premium has expired - reset tier
        effectivePremiumTier = null;
        await supabase
          .from("profiles")
          .update({ premium_tier: null, premium_expires_at: null })
          .eq("user_id", user.id);
      }
    }

    // Calculate reward based on premium tier - fetch from tier_settings
    let finalReward = 0;
    if (isSuccessful) {
      // Fetch earning rate from tier_settings based on user's tier
      const tierToFetch = effectivePremiumTier || "free";
      const { data: tierSetting } = await supabase
        .from("tier_settings")
        .select("earning_rate")
        .eq("tier", tierToFetch)
        .single();
      
      // Default to 0.65 if tier_settings not found (fallback for free users)
      finalReward = tierSetting ? Number(tierSetting.earning_rate) : 0.65;
    }

    const nowIso = now.toISOString();

    // All users have unlimited playtime - no playtime tracking needed
    // Update game session
    if (sessionId) {
      await supabase
        .from("game_sessions")
        .update({
          completed_at: nowIso,
          score,
          is_successful: isSuccessful,
          reward_earned: finalReward,
          time_taken_seconds: timeTakenSeconds,
        })
        .eq("id", sessionId)
        .eq("user_id", user.id); // Security: ensure session belongs to user
    }

    // Update profile - always increment games_played
    // Note: playtime_seconds is now derived from wall-clock time, so we don't increment it
    const updateData: Record<string, number> = {
      games_played: profile.games_played + 1,
    };

    if (isSuccessful && finalReward > 0) {
      updateData.balance = profile.balance + finalReward;
      updateData.total_earned = profile.total_earned + finalReward;
    }

    await supabase
      .from("profiles")
      .update(updateData)
      .eq("user_id", user.id);

    // Create earning transaction if successful
    if (isSuccessful && finalReward > 0) {
      await supabase
        .from("transactions")
        .insert({
          user_id: user.id,
          type: "earning",
          amount: finalReward,
          status: "completed",
          description: `Game reward - ${gameId}`,
          game_id: gameId,
        });

      // Process 10% referral bonus if user has a referrer
      if (profile.referred_by) {
        const referralBonus = parseFloat((finalReward * 0.10).toFixed(2));
        
        if (referralBonus > 0) {
          // Get referrer's profile using their profile ID
          const { data: referrer } = await supabase
            .from("profiles")
            .select("user_id, balance, referral_earnings")
            .eq("id", profile.referred_by)
            .single();

          if (referrer) {
            // Credit referral bonus to referrer
            await supabase
              .from("profiles")
              .update({
                balance: referrer.balance + referralBonus,
                referral_earnings: referrer.referral_earnings + referralBonus,
              })
              .eq("id", profile.referred_by);

            // Create referral commission transaction for referrer
            await supabase
              .from("transactions")
              .insert({
                user_id: referrer.user_id,
                type: "referral_commission",
                amount: referralBonus,
                status: "completed",
                description: `10% referral bonus from referred user's game`,
                game_id: gameId,
              });
          }
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        credited: isSuccessful && finalReward > 0,
        amount: finalReward,
        newBalance: isSuccessful ? profile.balance + finalReward : profile.balance,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});